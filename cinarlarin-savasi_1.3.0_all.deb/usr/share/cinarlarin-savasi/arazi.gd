extends Reference
# Çınarların Savaşı: dünya üreticisi
# Bütün dünya (100 x 250 km) bir tohumdan hesaplanır. Her bilgisayar aynı tohumla
# aynı dünyayı üretir; bu yüzden dünya ağdan gönderilmez.
#
#   kuzey (z=0)
#     AVRUPA      : tepeler, ormanlar, nehirler, Alpler (geçitlerle), şehirler, köyler, üsler, limanlar
#     AKDENİZ     : deniz, ortada kara köprüsü (boğaz)
#     BÜYÜK ÇÖL   : kumullar, kayalık dağlar, terk edilmiş şehirler, petrol tesisleri, vahalar
#     TROPİKAL    : yağmur ormanı, nehirler, bataklıklar, sahil kasabaları, limanlar, adalar
#   güney (z=250000)

const V = preload("res://veri.gd")
const HUCRE = 5000.0

var n_tepe
var n_dag
var n_kiyi
var n_nehir
var n_kum
var n_orman
var n_detay
var hucreler = {}
var bina_onbellek = {}
var ozel = []          # düzleştirilmiş özel yerler: çınarlar, üsler, limanlar


func _init(tohum: int = 9879):
	n_tepe = _gurultu(tohum, 4, 6000.0, 0.5)
	n_dag = _gurultu(tohum + 1, 4, 9000.0, 0.5)
	n_kiyi = _gurultu(tohum + 2, 3, 8000.0, 0.5)
	n_nehir = _gurultu(tohum + 3, 2, 9000.0, 0.4)
	n_kum = _gurultu(tohum + 4, 2, 650.0, 0.5)
	n_orman = _gurultu(tohum + 5, 2, 2500.0, 0.5)
	n_detay = _gurultu(tohum + 6, 2, 160.0, 0.5)
	_ozel_yerleri_kur()


func _gurultu(s, o, p, k):
	var n = OpenSimplexNoise.new()
	n.seed = s
	n.octaves = o
	n.period = p
	n.persistence = k
	return n


func agirliklar(z: float) -> Array:
	var wa = 1.0 - smoothstep(76000.0, 86000.0, z)
	var wt = smoothstep(176000.0, 186000.0, z)
	return [wa, max(0.0, 1.0 - wa - wt), wt]


# ---------------------------------------------------------------- yükseklik
func kara_skoru(x: float, z: float, w: Array) -> float:
	# > 0 kara, < 0 deniz (yaklaşık metre)
	var kiyi_n = n_kiyi.get_noise_2d(x, z)
	var kenar = min(min(x, V.DUNYA_EN - x), min(z, V.DUNYA_BOY - z))
	var skor = kenar + kiyi_n * 2500.0 - 1800.0
	if z > 68000.0 and z < 90000.0:
		var akdeniz = -min(z - 72500.0, 85500.0 - z) + kiyi_n * 1500.0
		akdeniz = max(akdeniz, 6000.0 - abs(x - 50000.0) + kiyi_n * 1500.0)   # kara köprüsü
		skor = min(skor, akdeniz)
	if w[2] > 0.3:   # tropikal dağlık adalar
		var ada = n_dag.get_noise_2d(x * 1.7 + 900.0, z * 1.7) - 0.42
		if ada > 0.0:
			skor = max(skor, ada * 9000.0 - 300.0)
	return skor


func ham_yukseklik(x: float, z: float) -> float:
	var w = agirliklar(z)
	var tepe = n_tepe.get_noise_2d(x, z)
	var h = 0.0
	var alp = 0.0
	if w[0] > 0.0:
		var ha = 25.0 + 70.0 * (tepe * 0.5 + 0.5)
		var sirt = 1.0 - abs(n_dag.get_noise_2d(x, z))
		alp = smoothstep(54000.0, 60000.0, z) * (1.0 - smoothstep(67000.0, 71500.0, z))
		if alp > 0.0:
			var gecit = max(1.0 - smoothstep(1500.0, 4500.0, abs(x - 50000.0)),
				max(1.0 - smoothstep(1000.0, 3000.0, abs(x - 20000.0)), 1.0 - smoothstep(1000.0, 3000.0, abs(x - 80000.0))))
			ha += alp * sirt * sirt * 1400.0 * (1.0 - gecit * 0.9)
		ha += max(0.0, sirt - 0.80) * 2200.0 * (1.0 - alp)     # dağınık dağlar ve vadiler
		h += ha * w[0]
	if w[1] > 0.0:
		var kum = 1.0 - abs(n_kum.get_noise_2d(x, z))
		var hc = 40.0 + 22.0 * tepe + 14.0 * kum * kum
		hc += max(0.0, n_dag.get_noise_2d(x + 7000.0, z) - 0.20) * 1100.0   # kayalık dağlar
		h += hc * w[1]
	if w[2] > 0.0:
		var ht = 14.0 + 40.0 * (tepe * 0.5 + 0.5) + max(0.0, n_dag.get_noise_2d(x, z + 5000.0) - 0.25) * 700.0
		var bat = smoothstep(0.3, 0.5, n_orman.get_noise_2d(x + 3000.0, z)) * (1.0 - smoothstep(60.0, 120.0, ht))
		ht = lerp(ht, 0.35 + n_detay.get_noise_2d(x, z) * 0.9, bat)      # bataklık
		h += ht * w[2]
	var nw = w[0] + w[2]
	if nw > 0.0:   # nehirler
		var r = abs(n_nehir.get_noise_2d(x, z))
		if r < 0.034:
			var nehir = (1.0 - smoothstep(0.010, 0.032, r)) * nw * (1.0 - smoothstep(150.0, 450.0, h))
			h = lerp(h, -2.5, nehir)
	h += n_detay.get_noise_2d(x, z) * 1.5
	var skor = kara_skoru(x, z, w)
	h = lerp(1.2, h, smoothstep(0.0, 2500.0, skor))       # kıyıya doğru alçalan ova
	return lerp(-25.0, h, smoothstep(-250.0, 250.0, skor))


func yukseklik(x: float, z: float) -> float:
	var h = ham_yukseklik(x, z)
	for o in ozel:
		var dx = x - o.x
		var dz = z - o.z
		var s = o.r + 300.0
		if abs(dx) < s and abs(dz) < s:
			var d = sqrt(dx * dx + dz * dz)
			if d < s:
				h = lerp(h, o.h, 1.0 - smoothstep(o.r, s, d))
	var y = yerlesim_at(x, z)
	if y != null:
		var d = Vector2(x - y.x, z - y.z).length()
		var t = 1.0 - smoothstep(y.r, y.r + 250.0, d)
		var hedef = y.h
		if y.tip == "vaha":
			hedef = lerp(-1.6, y.h, smoothstep(38.0, 60.0, d))
		h = lerp(h, hedef, t)
	return h


# ---------------------------------------------------------------- renk
func renk(x: float, z: float, h: float, egim: float) -> Color:
	var w = agirliklar(z)
	var d = n_detay.get_noise_2d(x * 3.0, z * 3.0) * 0.06
	var orman = n_orman.get_noise_2d(x, z)
	var c = Color(0, 0, 0)
	if w[0] > 0.0:
		var a = Color(0.33 + d, 0.52 + d, 0.22)
		if orman > 0.1 and h < 900.0:
			a = a.linear_interpolate(Color(0.20, 0.38, 0.15), 0.7)
		if egim > 0.45 or h > 700.0:
			a = a.linear_interpolate(Color(0.47, 0.45, 0.42), clamp(max((egim - 0.45) * 4.0, (h - 700.0) / 150.0), 0.0, 1.0))
		if h > 950.0:
			a = a.linear_interpolate(Color(0.94, 0.95, 0.97), clamp((h - 950.0) / 120.0, 0.0, 1.0))
		c += a * w[0]
	if w[1] > 0.0:
		var b = Color(0.86 + d, 0.72 + d, 0.48 + d * 0.5)
		if egim > 0.35 or h > 160.0:
			b = b.linear_interpolate(Color(0.62, 0.46, 0.33), clamp(max((egim - 0.35) * 4.0, (h - 160.0) / 60.0), 0.0, 1.0))
		c += b * w[1]
	if w[2] > 0.0:
		var t = Color(0.18 + d, 0.48 + d, 0.15)
		if orman > -0.2:
			t = t.linear_interpolate(Color(0.10, 0.34, 0.10), 0.6)
		if h < 2.0 and h > -0.5:
			t = t.linear_interpolate(Color(0.32, 0.33, 0.18), 0.7)   # bataklık çamuru
		if egim > 0.5:
			t = t.linear_interpolate(Color(0.42, 0.40, 0.33), clamp((egim - 0.5) * 4.0, 0.0, 1.0))
		c += t * w[2]
	if h < 2.5 and h > 0.3 and w[2] < 0.9:
		c = c.linear_interpolate(Color(0.84, 0.78, 0.58), 0.75)   # kumsal
	if h <= 0.3:
		c = c.linear_interpolate(Color(0.40, 0.37, 0.28), 0.8)    # su altı
	var y = yerlesim_at(x, z)
	if y != null and Vector2(x - y.x, z - y.z).length() < y.r:
		var zemin = {"sehir": Color(0.45, 0.45, 0.45), "kasaba": Color(0.5, 0.47, 0.4), "askeri": Color(0.42, 0.42, 0.33),
			"terk": Color(0.72, 0.62, 0.45), "petrol": Color(0.4, 0.37, 0.33), "tkasaba": Color(0.55, 0.5, 0.38)}
		if zemin.has(y.tip):
			c = c.linear_interpolate(zemin[y.tip], 0.7)
	return c


# ---------------------------------------------------------------- yerleşimler
func _ozel_yerleri_kur():
	for b in 3:
		var a = V.AGAC_YERI[b]
		ozel.append({"tip": "cinar", "x": a.x, "z": a.y, "r": 130.0, "h": max(ham_yukseklik(a.x, a.y), 6.0)})
		for t in 2:
			var u = V.us_yeri(t, b)
			ozel.append({"tip": "us", "takim": t, "x": u.x, "z": u.y, "r": 70.0, "h": max(ham_yukseklik(u.x, u.y), 6.0)})
	# limanlar: kıyıyı bul, iskeleyi denize doğru uzat
	for l in [[Vector2(30000, 66000), Vector2(0, 1)], [Vector2(70000, 92000), Vector2(0, -1)],
			[Vector2(9000, 228000), Vector2(-1, 0)], [Vector2(91000, 200000), Vector2(1, 0)], [Vector2(50000, 9000), Vector2(0, -1)]]:
		var p = l[0]
		for i in 200:
			if ham_yukseklik(p.x, p.y) < 0.0:
				break
			p += l[1] * 50.0
		p -= l[1] * 140.0
		ozel.append({"tip": "liman", "x": p.x, "z": p.y, "r": 60.0, "h": 3.0, "yon": l[1]})


func hucre(cx: int, cz: int):
	var k = cx * 1000 + cz
	if hucreler.has(k):
		return hucreler[k]
	var y = _hucre_uret(cx, cz)
	hucreler[k] = y
	return y


func _hucre_uret(cx: int, cz: int):
	if cx < 0 or cz < 0 or cx >= int(V.DUNYA_EN / HUCRE) or cz >= int(V.DUNYA_BOY / HUCRE):
		return null
	var u = float(V.karistir(cx, cz, 5) % 10000) / 10000.0
	var px = cx * HUCRE + 1300.0 + float(V.karistir(cx, cz, 6) % 2400)
	var pz = cz * HUCRE + 1300.0 + float(V.karistir(cx, cz, 7) % 2400)
	for o in ozel:
		if Vector2(px - o.x, pz - o.z).length() < 3800.0:
			return null
	var b = V.bolge(pz)
	var tip = ""
	if b == 0:
		tip = "sehir" if u < 0.11 else ("kasaba" if u < 0.25 else ("koy" if u < 0.45 else ("ciftlik" if u < 0.57 else ("askeri" if u < 0.63 else ""))))
	elif b == 1:
		tip = "terk" if u < 0.10 else ("petrol" if u < 0.20 else ("yerlesim" if u < 0.30 else ("vaha" if u < 0.39 else "")))
	else:
		tip = "tkasaba" if u < 0.12 else ("tkoy" if u < 0.37 else "")
	if tip == "":
		return null
	var r = {"sehir": 650.0, "kasaba": 320.0, "koy": 160.0, "ciftlik": 90.0, "askeri": 260.0, "terk": 450.0,
		"petrol": 300.0, "yerlesim": 140.0, "vaha": 110.0, "tkasaba": 300.0, "tkoy": 150.0}[tip]
	var h = ham_yukseklik(px, pz)
	if h < 4.0 or h > 450.0:
		return null
	var en_az = h
	var en_cok = h
	for a in 8:
		var hh = ham_yukseklik(px + cos(a * PI / 4.0) * r, pz + sin(a * PI / 4.0) * r)
		en_az = min(en_az, hh)
		en_cok = max(en_cok, hh)
	if en_az < 1.5 or en_cok - en_az > 90.0:
		return null
	return {"tip": tip, "x": px, "z": pz, "r": r, "h": h, "tohum": V.karistir(cx, cz, 8)}


func yerlesim_at(x: float, z: float):
	var y = hucre(int(x / HUCRE), int(z / HUCRE))
	if y == null:
		return null
	if abs(x - y.x) > y.r + 250.0 or abs(z - y.z) > y.r + 250.0:
		return null
	return y


func yerlesim_adi(x: float, z: float) -> String:
	var y = yerlesim_at(x, z)
	for o in ozel:
		if Vector2(x - o.x, z - o.z).length() < o.r + 60.0:
			if o.tip == "cinar":
				return V.AGAC_ADI[V.bolge(o.z)]
			if o.tip == "us":
				return V.TAKIM_KISA[o.takim] + " üssü"
			if o.tip == "liman":
				return "Liman"
	if y != null and Vector2(x - y.x, z - y.z).length() < y.r + 40.0:
		return {"sehir": "Şehir", "kasaba": "Kasaba", "koy": "Köy", "ciftlik": "Çiftlik", "askeri": "Askerî üs",
			"terk": "Terk edilmiş şehir", "petrol": "Petrol tesisi", "yerlesim": "Çöl yerleşimi", "vaha": "Vaha",
			"tkasaba": "Sahil kasabası", "tkoy": "Orman köyü"}[y.tip]
	return ""


# ---------------------------------------------------------------- binalar
# Her yapı: {"t": "kutu"/"cati"/"silindir", "x","z" (dünya), "y" (taban), "en","boy","yuk","aci","renk", "r"}
func yapilar_yerlesim(y) -> Array:
	var k = int(y.x) * 100000 + int(y.z)
	if bina_onbellek.has(k):
		return bina_onbellek[k]
	var l = []
	var rng = RandomNumberGenerator.new()
	rng.seed = y.tohum
	match y.tip:
		"sehir", "terk":
			var adim = 46.0 if y.tip == "sehir" else 40.0
			var gx = -y.r
			while gx < y.r:
				var gz = -y.r
				while gz < y.r:
					var d = Vector2(gx, gz).length()
					if d < y.r - 15.0 and d > 40.0 and rng.randf() < (0.85 if y.tip == "sehir" else 0.6):
						var en = rng.randf_range(14.0, 30.0)
						var boy = rng.randf_range(14.0, 30.0)
						var yuk
						var c
						if y.tip == "sehir":
							yuk = rng.randf_range(8.0, 22.0) * (1.8 - d / y.r)
							if rng.randf() < 0.08:
								yuk *= 2.5
							c = [Color(0.62, 0.62, 0.64), Color(0.75, 0.70, 0.60), Color(0.62, 0.40, 0.32), Color(0.85, 0.83, 0.78), Color(0.5, 0.55, 0.6)][rng.randi() % 5]
						else:
							yuk = rng.randf_range(2.5, 13.0)
							c = [Color(0.80, 0.68, 0.50), Color(0.72, 0.60, 0.44), Color(0.66, 0.55, 0.42)][rng.randi() % 3]
						l.append({"t": "kutu", "x": y.x + gx + rng.randf_range(-3, 3), "z": y.z + gz + rng.randf_range(-3, 3), "en": en, "boy": boy, "yuk": yuk, "aci": 0.0, "renk": c})
					gz += adim
				gx += adim
		"kasaba", "tkasaba", "koy":
			var adim = 22.0 if y.tip != "koy" else 26.0
			var oran = 0.55 if y.tip != "koy" else 0.32
			var gx = -y.r
			while gx < y.r:
				var gz = -y.r
				while gz < y.r:
					if Vector2(gx, gz).length() < y.r - 8.0 and Vector2(gx, gz).length() > 18.0 and rng.randf() < oran:
						_ev(l, rng, y.x + gx + rng.randf_range(-4, 4), y.z + gz + rng.randf_range(-4, 4), y.tip == "tkasaba")
					gz += adim
				gx += adim
			if y.tip == "koy" or y.tip == "kasaba":
				# cami: kubbe yerine kutu + minare
				l.append({"t": "kutu", "x": y.x, "z": y.z, "en": 14.0, "boy": 14.0, "yuk": 8.0, "aci": 0.0, "renk": Color(0.9, 0.9, 0.86)})
				l.append({"t": "silindir", "x": y.x + 9.0, "z": y.z + 9.0, "r": 1.3, "yuk": 26.0, "renk": Color(0.92, 0.92, 0.9)})
		"ciftlik":
			_ev(l, rng, y.x, y.z, false)
			l.append({"t": "kutu", "x": y.x + 30.0, "z": y.z + 5.0, "en": 20.0, "boy": 12.0, "yuk": 8.0, "aci": 0.0, "renk": Color(0.62, 0.18, 0.15)})
			l.append({"t": "cati", "x": y.x + 30.0, "z": y.z + 5.0, "y": 8.0, "en": 20.0, "boy": 12.0, "yuk": 4.0, "aci": 0.0, "renk": Color(0.35, 0.3, 0.28)})
			l.append({"t": "silindir", "x": y.x + 45.0, "z": y.z - 10.0, "r": 4.0, "yuk": 14.0, "renk": Color(0.7, 0.7, 0.72)})
		"askeri":
			var s = y.r * 0.8
			var i = -s
			while i < s:
				for duvar in [[i, -s, 12.0, 0.4], [i, s, 12.0, 0.4], [-s, i, 0.4, 12.0], [s, i, 0.4, 12.0]]:
					l.append({"t": "kutu", "x": y.x + duvar[0] + (6.0 if duvar[2] > 1 else 0.0), "z": y.z + duvar[1] + (6.0 if duvar[3] > 1 else 0.0), "en": duvar[2], "boy": duvar[3], "yuk": 2.8, "aci": 0.0, "renk": Color(0.45, 0.45, 0.4)})
				i += 12.0
			for kose in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
				l.append({"t": "kutu", "x": y.x + kose.x * (s - 4), "z": y.z + kose.y * (s - 4), "en": 3.0, "boy": 3.0, "yuk": 10.0, "aci": 0.0, "renk": Color(0.38, 0.4, 0.3)})
				l.append({"t": "kutu", "x": y.x + kose.x * (s - 4), "z": y.z + kose.y * (s - 4), "y": 10.0, "en": 5.0, "boy": 5.0, "yuk": 2.5, "aci": 0.0, "renk": Color(0.35, 0.37, 0.28)})
			for h in 3:
				l.append({"t": "kutu", "x": y.x - 80.0 + h * 55.0, "z": y.z - 60.0, "en": 32.0, "boy": 22.0, "yuk": 11.0, "aci": 0.0, "renk": Color(0.42, 0.45, 0.36)})
			for h in 4:
				l.append({"t": "kutu", "x": y.x - 60.0 + h * 40.0, "z": y.z + 60.0, "en": 24.0, "boy": 9.0, "yuk": 4.5, "aci": 0.0, "renk": Color(0.5, 0.5, 0.4)})
		"petrol":
			for t in 6:
				l.append({"t": "silindir", "x": y.x - 80.0 + (t % 3) * 40.0, "z": y.z - 40.0 + (t / 3) * 45.0, "r": 12.0, "yuk": 13.0, "renk": Color(0.85, 0.85, 0.82)})
			for t in 3:
				l.append({"t": "kutu", "x": y.x + 70.0 + t * 25.0, "z": y.z + rng.randf_range(-30, 30), "en": 3.0, "boy": 3.0, "yuk": 30.0, "aci": 0.0, "renk": Color(0.55, 0.3, 0.2)})
			l.append({"t": "silindir", "x": y.x + 20.0, "z": y.z + 90.0, "r": 1.2, "yuk": 45.0, "renk": Color(0.3, 0.3, 0.3)})
			l.append({"t": "kutu", "x": y.x, "z": y.z + 30.0, "en": 200.0, "boy": 1.4, "yuk": 1.4, "aci": 0.0, "renk": Color(0.45, 0.42, 0.38)})
			l.append({"t": "kutu", "x": y.x - 30.0, "z": y.z + 70.0, "en": 25.0, "boy": 15.0, "yuk": 6.0, "aci": 0.0, "renk": Color(0.75, 0.72, 0.65)})
		"yerlesim":
			for t in 14:
				var a = rng.randf() * TAU
				var d = rng.randf_range(15.0, y.r - 15.0)
				l.append({"t": "kutu", "x": y.x + cos(a) * d, "z": y.z + sin(a) * d, "en": rng.randf_range(6, 11), "boy": rng.randf_range(6, 11), "yuk": rng.randf_range(3.0, 4.5), "aci": rng.randf() * PI, "renk": Color(0.78, 0.65, 0.48)})
		"vaha":
			for t in 3:
				var a = t * TAU / 3.0 + 0.4
				l.append({"t": "cati", "x": y.x + cos(a) * 75.0, "z": y.z + sin(a) * 75.0, "y": 0.0, "en": 5.0, "boy": 4.0, "yuk": 3.0, "aci": a, "renk": Color(0.85, 0.80, 0.70)})
		"tkoy":
			for t in 12:
				var a = rng.randf() * TAU
				var d = rng.randf_range(15.0, y.r - 15.0)
				var hx = y.x + cos(a) * d
				var hz = y.z + sin(a) * d
				for ayak in [Vector2(-2.5, -2.5), Vector2(2.5, -2.5), Vector2(-2.5, 2.5), Vector2(2.5, 2.5)]:
					l.append({"t": "kutu", "x": hx + ayak.x, "z": hz + ayak.y, "en": 0.35, "boy": 0.35, "yuk": 2.0, "aci": 0.0, "renk": Color(0.4, 0.3, 0.2)})
				l.append({"t": "kutu", "x": hx, "z": hz, "y": 2.0, "en": 6.5, "boy": 6.5, "yuk": 3.0, "aci": 0.0, "renk": Color(0.58, 0.45, 0.30)})
				l.append({"t": "cati", "x": hx, "z": hz, "y": 5.0, "en": 7.5, "boy": 7.5, "yuk": 2.5, "aci": 0.0, "renk": Color(0.72, 0.62, 0.38)})
	bina_onbellek[k] = l
	return l


func _ev(l: Array, rng: RandomNumberGenerator, x: float, z: float, renkli: bool):
	var en = rng.randf_range(7.0, 12.0)
	var boy = rng.randf_range(7.0, 11.0)
	var yuk = rng.randf_range(4.5, 7.5)
	var aci = rng.randf() * PI
	var c = Color(0.88, 0.85, 0.78)
	if renkli:
		c = [Color(0.95, 0.75, 0.55), Color(0.55, 0.80, 0.85), Color(0.95, 0.90, 0.55), Color(0.85, 0.60, 0.70), Color(0.9, 0.9, 0.9)][rng.randi() % 5]
	else:
		c = [Color(0.88, 0.85, 0.78), Color(0.80, 0.74, 0.62), Color(0.92, 0.90, 0.86)][rng.randi() % 3]
	l.append({"t": "kutu", "x": x, "z": z, "en": en, "boy": boy, "yuk": yuk, "aci": aci, "renk": c})
	l.append({"t": "cati", "x": x, "z": z, "y": yuk, "en": en + 0.8, "boy": boy + 0.8, "yuk": 2.6, "aci": aci, "renk": Color(0.70, 0.28, 0.20)})


func yapilar_ozel(o) -> Array:
	var l = []
	if o.tip == "us":
		var c = V.TAKIM_RENK[o.takim]
		for a in 16:
			var aci = a * TAU / 16.0
			if a == 0 or a == 8:
				continue   # giriş (doğu ve batı)
			l.append({"t": "kutu", "x": o.x + cos(aci) * 45.0, "z": o.z + sin(aci) * 45.0, "en": 16.0, "boy": 1.4, "yuk": 1.4, "aci": -aci + PI / 2.0, "renk": Color(0.62, 0.56, 0.42)})
		for t in 4:
			var aci = t * TAU / 4.0 + PI / 4.0
			l.append({"t": "cati", "x": o.x + cos(aci) * 25.0, "z": o.z + sin(aci) * 25.0, "y": 0.0, "en": 6.0, "boy": 8.0, "yuk": 3.2, "aci": aci, "renk": Color(0.40, 0.44, 0.32)})
		l.append({"t": "silindir", "x": o.x, "z": o.z, "r": 0.15, "yuk": 12.0, "renk": Color(0.8, 0.8, 0.8)})
		l.append({"t": "kutu", "x": o.x + 1.6, "z": o.z, "y": 9.5, "en": 3.0, "boy": 0.1, "yuk": 2.0, "aci": 0.0, "renk": c})
	elif o.tip == "liman":
		var yon = o.yon
		var yan = Vector2(-yon.y, yon.x)
		for i in 3:
			var merkez = Vector2(o.x, o.z) + yan * (i - 1) * 45.0 + yon * 205.0
			l.append({"t": "kutu", "x": merkez.x, "z": merkez.y, "y": -6.0, "en": 10.0 if yon.x == 0 else 110.0, "boy": 110.0 if yon.x == 0 else 10.0, "yuk": 7.0, "aci": 0.0, "renk": Color(0.5, 0.48, 0.45)})
		for i in 2:
			var p = Vector2(o.x, o.z) + yan * (i * 60.0 - 30.0) - yon * 40.0
			l.append({"t": "kutu", "x": p.x, "z": p.y, "en": 30.0, "boy": 18.0, "yuk": 10.0, "aci": 0.0, "renk": Color(0.55, 0.58, 0.62)})
		var rng = RandomNumberGenerator.new()
		rng.seed = int(o.x) + int(o.z)
		for i in 24:
			var p = Vector2(o.x, o.z) + yan * rng.randf_range(-70, 70) + yon * rng.randf_range(10, 60)
			l.append({"t": "kutu", "x": p.x, "z": p.y, "y": float(i % 2) * 2.6, "en": 6.0, "boy": 2.5, "yuk": 2.6, "aci": 0.0,
				"renk": [Color(0.8, 0.25, 0.2), Color(0.2, 0.4, 0.75), Color(0.85, 0.6, 0.15), Color(0.25, 0.6, 0.3)][rng.randi() % 4]})
		var vinc = Vector2(o.x, o.z) + yon * 90.0
		l.append({"t": "kutu", "x": vinc.x, "z": vinc.y, "en": 2.0, "boy": 2.0, "yuk": 28.0, "aci": 0.0, "renk": Color(0.9, 0.7, 0.1)})
		l.append({"t": "kutu", "x": vinc.x + yon.x * 12.0, "z": vinc.y + yon.y * 12.0, "y": 26.0, "en": 2.0 if yon.x == 0 else 30.0, "boy": 30.0 if yon.x == 0 else 2.0, "yuk": 1.5, "aci": 0.0, "renk": Color(0.9, 0.7, 0.1)})
	return l


# ---------------------------------------------------------------- ağaçlar
# 0 yapraklı, 1 kozalaklı, 2 palmiye, 3 tropik ağaç; -1 yok
func agac_tipi(x: float, z: float, h: float, egim: float, rnd: float) -> int:
	if h < 0.8 or egim > 0.6:
		return -1
	var y = yerlesim_at(x, z)
	if y != null:
		var d = Vector2(x - y.x, z - y.z).length()
		if y.tip == "vaha" and d > 45.0 and d < 100.0:
			return 2 if rnd < 0.25 else -1
		if d < y.r + 20.0:
			return -1
	for o in ozel:
		if abs(x - o.x) < o.r + 30.0 and abs(z - o.z) < o.r + 30.0:
			return -1
	var w = agirliklar(z)
	var orman = n_orman.get_noise_2d(x, z)
	if w[1] > 0.6:
		return -1
	if w[2] > 0.5:
		if h < 6.0:
			return 2 if rnd < 0.10 else -1
		if orman > -0.2:
			return 3 if rnd < 0.55 else -1
		return 3 if rnd < 0.12 else -1
	if h > 1250.0:
		return -1
	if orman > 0.1:
		if rnd < 0.45:
			return 1 if h > 450.0 or orman > 0.45 else 0
		return -1
	return 0 if rnd < 0.025 else -1
