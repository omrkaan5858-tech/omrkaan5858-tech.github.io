extends KinematicBody
# Çınarların Savaşı: senin askerin (birinci şahıs)

const V = preload("res://veri.gd")
const Ses = preload("res://ses.gd")

signal vurdu(oldurdu)

var dunya
var aktif = false
var arac = null
var hiz = Vector3()
var kafa: Spatial
var kamera: Camera
var silah_tutucu: Spatial
var silah_modelleri = []
var fener: SpotLight
var silah = 0
var mermi = []
var yedek = []
var bekleme = 0.0
var atis_butcesi = 1.0     # saniyede en çok 9 gerçek atış
var biriken = 0            # son gerçek atıştan beri ekranda atılan mermi
var dolduruluyor = 0.0
var nisan = false
var tepme = 0.0
var hassasiyet = 0.12
var gonder_zaman = 0.0
var ses_atis: AudioStreamPlayer
var ses_dolum: AudioStreamPlayer
var ses_isabet: AudioStreamPlayer
var ses_bos: AudioStreamPlayer
var atis_akislari = []
var tetik_birakildi = true
var su_icinde = false
var sekil: CollisionShape


func _ready():
	collision_layer = 2
	collision_mask = 1 | 4
	var cs = CollisionShape.new()
	var sh = CapsuleShape.new()
	sh.radius = 0.4
	sh.height = 1.0
	cs.shape = sh
	cs.rotation_degrees = Vector3(90, 0, 0)
	cs.translation = Vector3(0, 0.9, 0)
	add_child(cs)
	sekil = cs
	kafa = Spatial.new()
	kafa.translation = Vector3(0, 1.62, 0)
	add_child(kafa)
	kamera = Camera.new()
	kamera.far = 5000.0
	kamera.near = 0.08
	kamera.fov = 75.0
	kafa.add_child(kamera)
	fener = SpotLight.new()
	fener.spot_range = 70.0
	fener.spot_angle = 26.0
	fener.spot_attenuation = 1.4
	fener.light_energy = 3.0
	fener.shadow_enabled = dunya.kalite >= 2
	fener.visible = false
	kamera.add_child(fener)
	silah_tutucu = Spatial.new()
	silah_tutucu.translation = Vector3(0.22, -0.22, -0.45)
	silah_tutucu.scale = Vector3(0.75, 0.75, 0.75)
	kamera.add_child(silah_tutucu)
	for i in V.SILAHLAR.size():
		silah_modelleri.append(dunya.gorsel.silah_modeli(i, true))
		silah_tutucu.add_child(silah_modelleri[i])
		mermi.append(V.SARJOR)
		yedek.append(V.YEDEK_SARJOR)
	for i in 5:
		atis_akislari.append(Ses.atis(i))
	ses_atis = _oynatici(null, -2.0)
	ses_dolum = _oynatici(Ses.dolum(), -4.0)
	ses_isabet = _oynatici(Ses.isabet(), -6.0)
	ses_bos = _oynatici(Ses.bos(), -6.0)
	silah_sec(0)
	visible = false


func _oynatici(akis, db):
	var s = AudioStreamPlayer.new()
	s.stream = akis
	s.volume_db = db
	add_child(s)
	return s


func silah_sec(i: int):
	if i < 0 or i >= V.SILAHLAR.size():
		return
	silah = i
	dolduruluyor = 0.0
	for j in silah_modelleri.size():
		silah_modelleri[j].visible = j == i
	ses_atis.stream = atis_akislari[i]


func dogdu(l: Vector3):
	translation = l
	hiz = Vector3()
	aktif = true
	visible = true
	arac = null
	sekil.disabled = false
	for i in V.SILAHLAR.size():
		mermi[i] = V.SARJOR
		yedek[i] = V.YEDEK_SARJOR
	kamera.current = true
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func oldu():
	if arac != null:
		_aractan_in()
	aktif = false
	visible = false
	nisan = false
	kamera.fov = 75.0


func _input(ev):
	if not aktif or Input.get_mouse_mode() != Input.MOUSE_MODE_CAPTURED:
		return
	if ev is InputEventMouseMotion:
		var k = hassasiyet * (0.35 if nisan and silah == 1 else (0.7 if nisan else 1.0))
		if arac != null:
			arac.kamera_dondur(-ev.relative.x * k * 0.01, -ev.relative.y * k * 0.01)
			return
		rotate_y(deg2rad(-ev.relative.x * k))
		kafa.rotation.x = clamp(kafa.rotation.x - deg2rad(ev.relative.y * k), deg2rad(-87), deg2rad(87))
	elif ev is InputEventMouseButton and ev.pressed and arac == null:
		if ev.button_index == BUTTON_WHEEL_UP:
			silah_sec((silah + V.SILAHLAR.size() - 1) % V.SILAHLAR.size())
		elif ev.button_index == BUTTON_WHEEL_DOWN:
			silah_sec((silah + 1) % V.SILAHLAR.size())


func _physics_process(delta):
	if not aktif:
		return
	if arac != null:
		translation = arac.translation + Vector3(0, 0.5, 0)
		if Input.is_action_just_pressed("etkiles"):
			_aractan_in()
		_gonder(delta)
		return
	var yakalandi = Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED
	var giris = Vector2()
	if yakalandi:
		giris = Vector2(Input.get_action_strength("sag") - Input.get_action_strength("sol"),
			Input.get_action_strength("geri") - Input.get_action_strength("ileri"))
	var yon = (transform.basis.x * giris.x + transform.basis.z * giris.y)
	yon.y = 0
	if yon.length() > 1.0:
		yon = yon.normalized()
	su_icinde = translation.y < -1.1
	var hedef_hiz = 4.2
	if yakalandi and Input.is_action_pressed("kos") and giris.y < 0 and not nisan:
		hedef_hiz = 7.5
	if su_icinde:
		hedef_hiz = 2.5
	var yatay = Vector3(hiz.x, 0, hiz.z).linear_interpolate(yon * hedef_hiz, min(1.0, delta * (10.0 if is_on_floor() else 2.5)))
	hiz.x = yatay.x
	hiz.z = yatay.z
	if su_icinde:
		hiz.y = lerp(hiz.y, 1.2 if (yakalandi and Input.is_action_pressed("zipla")) else 0.4, delta * 3.0)
	else:
		hiz.y -= 20.0 * delta
		if is_on_floor() and yakalandi and Input.is_action_just_pressed("zipla"):
			hiz.y = 6.0
	hiz = move_and_slide(hiz, Vector3.UP, true, 4, deg2rad(50))
	# araziden düşmeyi önle
	var g = dunya.kuresel(translation)
	var zemin = dunya.arazi.yukseklik(g.x, g.z)
	if translation.y < zemin - 2.0:
		translation.y = zemin + 0.5
		hiz.y = 0
	if yakalandi:
		_silah_isle(delta)
		if Input.is_action_just_pressed("fener"):
			fener.visible = not fener.visible
		if Input.is_action_just_pressed("etkiles"):
			var a = dunya.en_yakin_arac(translation, 4.5)
			if a != null:
				Ag.sunucuya("arac_bin", [a.numara])
		for i in 5:
			if Input.is_action_just_pressed("silah%d" % (i + 1)):
				silah_sec(i)
	_gonder(delta)


func araca_bindir(a):
	arac = a
	nisan = false
	kamera.fov = 75.0
	sekil.disabled = true
	visible = false
	a.surucu_ol(self)


func _aractan_in():
	var a = arac
	arac = null
	sekil.disabled = false
	visible = true
	kamera.current = true
	if a != null:
		var yan = a.global_transform.basis.x * 2.6
		translation = a.translation + yan + Vector3(0, 1.0, 0)
		a.surucu_birak()
		Ag.sunucuya("arac_in", [a.numara, dunya.kuresel(a.translation), a.global_transform.basis.get_rotation_quat()])


func _gonder(delta):
	gonder_zaman -= delta
	if gonder_zaman > 0.0:
		return
	gonder_zaman = 1.0 / 15.0
	var arac_veri = []
	if arac != null:
		arac_veri = [arac.numara, dunya.kuresel(arac.translation), arac.global_transform.basis.get_rotation_quat()]
	Ag.hareket_gonder(dunya.kuresel(translation), rotation.y, kafa.rotation.x, silah, arac_veri)


func _silah_isle(delta):
	var w = V.SILAHLAR[silah]
	bekleme -= delta
	atis_butcesi = min(1.0, atis_butcesi + delta * V.GERCEK_ATIS_SINIRI)
	tepme = lerp(tepme, 0.0, min(1.0, delta * 10.0))
	var hedef_konum = Vector3(0.0, -0.048, -0.3) if nisan else Vector3(0.17, -0.17, -0.36)
	silah_tutucu.translation = silah_tutucu.translation.linear_interpolate(hedef_konum, min(1.0, delta * 18.0)) + Vector3(0, 0, tepme * 0.03)
	if dolduruluyor > 0.0:
		dolduruluyor -= delta
		silah_tutucu.rotation.x = -0.5
		if dolduruluyor <= 0.0:
			mermi[silah] = V.SARJOR
			yedek[silah] -= 1
			silah_tutucu.rotation.x = 0.0
		return
	silah_tutucu.rotation.x = lerp(silah_tutucu.rotation.x, 0.0, delta * 10.0)
	nisan = Input.is_action_pressed("nisan")
	var hedef_fov = w.zoom if nisan else 75.0
	kamera.fov = lerp(kamera.fov, hedef_fov, min(1.0, delta * 14.0))
	silah_tutucu.visible = not (nisan and silah == 1)
	if Input.is_action_just_pressed("dolum"):
		_doldur()
	var basili = Input.is_action_pressed("ates")
	if not basili:
		tetik_birakildi = true
	if basili and bekleme <= 0.0 and (w.otomatik or tetik_birakildi):
		tetik_birakildi = false
		if mermi[silah] <= 0:
			ses_bos.play()
			bekleme = 0.3
			_doldur()
			return
		_ates_et(w)


func _doldur():
	if mermi[silah] < V.SARJOR and yedek[silah] > 0 and dolduruluyor <= 0.0:
		dolduruluyor = V.SILAHLAR[silah].dolum
		nisan = false
		ses_dolum.play()


func _ates_et(w):
	mermi[silah] -= 1
	bekleme = w.aralik
	tepme = 1.0
	kafa.rotation.x = clamp(kafa.rotation.x + deg2rad(w.tepme * (0.4 if nisan else 1.0)), deg2rad(-87), deg2rad(87))
	ses_atis.play()
	# ekranda her mermi görünür; ama isabet ve ağ sadece "gerçek" atışlarda (saniyede en çok 9)
	biriken += 1
	var gercek = atis_butcesi >= 1.0
	var carpan = 1
	if gercek:
		atis_butcesi -= 1.0
		carpan = biriken
		biriken = 0
	var bas = kamera.global_transform.origin
	var namlu = silah_tutucu.global_transform.origin - kamera.global_transform.basis.z * (w.uzunluk + 0.1)
	dunya.parlama(namlu)
	var alev = silah_modelleri[silah].get_node("alev")
	alev.visible = true
	alev.rotation.z = randf() * TAU
	alev.scale = Vector3(1, 1, 1) * rand_range(0.8, 1.3)
	get_tree().create_timer(0.035).connect("timeout", alev, "set_visible", [false])
	var uzay = get_world().direct_space_state
	var vurdu_oyuncu = false
	var oldurdu = false
	var son_nokta = bas - kamera.global_transform.basis.z * w.menzil
	for s in w.sacma:
		var sapma = w.sapma * (0.35 if nisan else 1.0)
		var yon = -kamera.global_transform.basis.z
		yon = yon.rotated(kamera.global_transform.basis.x, rand_range(-sapma, sapma)).rotated(Vector3.UP, rand_range(-sapma, sapma))
		var son = bas + yon * w.menzil
		var r = uzay.intersect_ray(bas, son, [self], 1 | 2 | 4)
		if r.empty():
			if s == 0:
				son_nokta = son
			continue
		if s == 0:
			son_nokta = r.position
		var c = r.collider
		if not gercek:
			dunya.toz(r.position, Color(0.5, 0.45, 0.35))
			continue
		if c.has_meta("oyuncu_id"):
			vurdu_oyuncu = true
			var bas_vurus = r.position.y - c.global_transform.origin.y > 1.45
			var hasar = w.hasar * carpan * (2.0 if bas_vurus else 1.0)
			Ag.sunucuya("ates", [c.get_meta("oyuncu_id"), int(hasar)])
			dunya.toz(r.position, Color(0.6, 0.05, 0.05))
		elif c.has_meta("agac"):
			Ag.sunucuya("agaca_ates", [c.get_meta("agac"), int(w.hasar * carpan)])
			dunya.toz(r.position, Color(0.35, 0.5, 0.15))
		else:
			dunya.toz(r.position, Color(0.5, 0.45, 0.35))
	dunya.iz(namlu - kamera.global_transform.basis.z * 1.5, son_nokta)
	if gercek:
		Ag.atis_bildir(dunya.kuresel(namlu), dunya.kuresel(son_nokta), silah, carpan)
	if vurdu_oyuncu:
		ses_isabet.play()
		emit_signal("vurdu", oldurdu)


func konum_kuresel() -> Vector3:
	return dunya.kuresel(translation)
