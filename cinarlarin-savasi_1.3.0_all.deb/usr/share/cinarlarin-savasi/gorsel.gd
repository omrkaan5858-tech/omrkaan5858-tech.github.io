extends Reference
# Çınarların Savaşı: görüntü kalitesi, malzemeler, kodla üretilen dokular, gölgelendiriciler (shader)
# ve ayrıntılı modeller (ağaçlar, silahlar, asker). Hiçbir resim dosyası kullanılmaz.

const KALITE_ADI = ["Düşük", "Orta", "Yüksek", "Çok yüksek"]

var kalite = 2
var ayar = {}
var gles3 = true

var mat_arazi
var mat_yapi
var mat_govde
var mat_yaprak
var mat_su
var mat_cimen
var mat_metal
var mat_polimer
var mat_ahsap
var mat_cam
var mat_kumas
var mat_ten
var mat_lastik
var mat_far
var mat_alev
var agac_meshleri = []     # [gövde, tepe, gövde yarıçapı, gövde boyu]
var cimen_mesh

var doku_ince_n
var doku_kaba_n
var doku_kabuk_n
var doku_yaprak_n
var doku_su_n
var doku_ince_g
var doku_kaba_g


static func otomatik_kalite() -> int:
	var ad = VisualServer.get_video_adapter_name().to_lower()
	if OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES2:
		return 0
	for k in ["llvmpipe", "softpipe", "swrast", "svga", "virtualbox", "vmware", "virgl", "microsoft basic"]:
		if k in ad:
			return 0
	return 2


static func ayar_al(k: int) -> Dictionary:
	return [
		{"golge": 0.0, "ssao": false, "glow": false, "msaa": Viewport.MSAA_DISABLED, "fxaa": false, "cimen": 0,
		 "seg": [32, 16, 8], "halka0": 1, "halka1": 2, "agac_aralik": 16.0, "su": false, "gok": false, "doku": false, "dof": false},
		{"golge": 100.0, "ssao": false, "glow": true, "msaa": Viewport.MSAA_DISABLED, "fxaa": true, "cimen": 2500,
		 "seg": [48, 24, 12], "halka0": 1, "halka1": 2, "agac_aralik": 13.0, "su": true, "gok": true, "doku": true, "dof": false},
		{"golge": 220.0, "ssao": false, "glow": true, "msaa": Viewport.MSAA_2X, "fxaa": false, "cimen": 5000,
		 "seg": [64, 32, 16], "halka0": 1, "halka1": 3, "agac_aralik": 11.0, "su": true, "gok": true, "doku": true, "dof": true},
		{"golge": 400.0, "ssao": true, "glow": true, "msaa": Viewport.MSAA_4X, "fxaa": false, "cimen": 9000,
		 "seg": [64, 32, 16], "halka0": 1, "halka1": 4, "agac_aralik": 10.0, "su": true, "gok": true, "doku": true, "dof": true},
	][int(clamp(k, 0, 3))].duplicate()


func _init(k: int):
	gles3 = OS.get_current_video_driver() == OS.VIDEO_DRIVER_GLES3
	kalite = int(clamp(k, 0, 3))
	ayar = ayar_al(kalite)
	if not gles3:
		ayar.su = false
		ayar.ssao = false
		ayar.dof = false
	_dokular()
	_malzemeler()
	_agac_meshleri()
	_cimen_meshi()


# ---------------------------------------------------------------- dokular (kodla)
func _gurultu(tohum: int, periyot: float, oktav: int = 4) -> OpenSimplexNoise:
	var n = OpenSimplexNoise.new()
	n.seed = tohum
	n.period = periyot
	n.octaves = oktav
	n.persistence = 0.55
	return n


func _normal_doku(tohum: int, periyot: float, guc: float, boyut: int = 256) -> NoiseTexture:
	var t = NoiseTexture.new()
	t.width = boyut
	t.height = boyut
	t.seamless = true
	t.as_normalmap = true
	t.bump_strength = guc
	t.noise = _gurultu(tohum, periyot)
	return t


func _gri_doku(tohum: int, periyot: float, alt: float, ust: float, boyut: int = 128) -> ImageTexture:
	var n = _gurultu(tohum, periyot)
	var kaynak = n.get_seamless_image(boyut)
	var img = Image.new()
	img.create(boyut, boyut, true, Image.FORMAT_RGB8)
	kaynak.lock()
	img.lock()
	for y in boyut:
		for x in boyut:
			var v = lerp(alt, ust, kaynak.get_pixel(x, y).r)
			img.set_pixel(x, y, Color(v, v, v))
	img.unlock()
	kaynak.unlock()
	img.generate_mipmaps()
	var t = ImageTexture.new()
	t.create_from_image(img, Texture.FLAGS_DEFAULT)
	return t


func _dokular():
	if not ayar.doku:
		return
	doku_ince_n = _normal_doku(101, 18.0, 8.0)
	doku_kaba_n = _normal_doku(102, 64.0, 6.0)
	doku_kabuk_n = _normal_doku(103, 10.0, 14.0)
	doku_yaprak_n = _normal_doku(104, 8.0, 10.0)
	doku_su_n = _normal_doku(105, 40.0, 4.0)
	doku_ince_g = _gri_doku(106, 14.0, 0.72, 1.0)
	doku_kaba_g = _gri_doku(107, 48.0, 0.82, 1.0)


# ---------------------------------------------------------------- malzemeler
func _renkli(srgb: bool = true) -> SpatialMaterial:
	var m = SpatialMaterial.new()
	m.vertex_color_use_as_albedo = true
	m.vertex_color_is_srgb = srgb
	return m


func _ayrinti(m: SpatialMaterial, gri, normal, olcek: float, normal_guc: float = 0.6):
	# yakından bakınca görünen doku: üç yönlü (triplanar) iz düşümle her yüzeye uyar
	if not ayar.doku:
		return
	m.detail_enabled = true
	m.detail_blend_mode = SpatialMaterial.BLEND_MODE_MUL
	if m.albedo_texture == null:
		# UV1 üç yönlü: Godot teğetleri (tangent) de üretir, normal doku doğru ışıklanır
		m.detail_uv_layer = SpatialMaterial.DETAIL_UV_1
		m.uv1_triplanar = true
		m.uv1_scale = Vector3(olcek, olcek, olcek)
	else:
		m.detail_uv_layer = SpatialMaterial.DETAIL_UV_2
		m.uv2_triplanar = true
		m.uv2_scale = Vector3(olcek, olcek, olcek)
	if gri != null:
		m.detail_albedo = gri
	if normal != null:
		m.detail_normal = normal
		m.normal_enabled = true
		m.normal_scale = normal_guc


func _malzemeler():
	mat_arazi = _renkli()
	mat_arazi.roughness = 0.95
	mat_arazi.params_cull_mode = SpatialMaterial.CULL_DISABLED
	if ayar.doku:
		mat_arazi.albedo_texture = doku_kaba_g
		mat_arazi.uv1_triplanar = true
		mat_arazi.uv1_scale = Vector3(0.015, 0.015, 0.015)
	_ayrinti(mat_arazi, doku_ince_g, doku_ince_n, 0.55, 0.7)

	mat_yapi = _renkli()
	mat_yapi.roughness = 0.85
	mat_yapi.params_cull_mode = SpatialMaterial.CULL_DISABLED
	_ayrinti(mat_yapi, doku_ince_g, doku_ince_n, 0.35, 0.4)

	mat_govde = SpatialMaterial.new()
	mat_govde.albedo_color = Color(0.36, 0.27, 0.19)
	mat_govde.roughness = 1.0
	_ayrinti(mat_govde, doku_ince_g, doku_kabuk_n, 1.2, 1.0)

	mat_yaprak = _renkli()
	mat_yaprak.roughness = 0.8
	if gles3:
		mat_yaprak.transmission_enabled = true
		mat_yaprak.transmission = Color(0.18, 0.26, 0.08)
	_ayrinti(mat_yaprak, doku_ince_g, doku_yaprak_n, 0.9, 0.8)

	if ayar.su:
		mat_su = ShaderMaterial.new()
		var sh = Shader.new()
		sh.code = SU_GOLGELENDIRICI
		mat_su.shader = sh
		mat_su.set_shader_param("dalga", doku_su_n)
	else:
		mat_su = SpatialMaterial.new()
		mat_su.albedo_color = Color(0.12, 0.32, 0.45, 0.78)
		mat_su.flags_transparent = true
		mat_su.roughness = 0.08
		mat_su.metallic = 0.25
		mat_su.params_cull_mode = SpatialMaterial.CULL_DISABLED

	mat_cimen = ShaderMaterial.new()
	var cs = Shader.new()
	cs.code = CIMEN_GOLGELENDIRICI
	mat_cimen.shader = cs

	mat_metal = SpatialMaterial.new()
	mat_metal.albedo_color = Color(0.17, 0.17, 0.18)
	mat_metal.metallic = 0.2
	mat_metal.roughness = 0.5
	_ayrinti(mat_metal, null, doku_ince_n, 6.0, 0.15)
	mat_polimer = SpatialMaterial.new()
	mat_polimer.albedo_color = Color(0.14, 0.15, 0.13)
	mat_polimer.roughness = 0.75
	_ayrinti(mat_polimer, doku_ince_g, doku_ince_n, 8.0, 0.25)
	mat_ahsap = SpatialMaterial.new()
	mat_ahsap.albedo_color = Color(0.40, 0.25, 0.13)
	mat_ahsap.roughness = 0.55
	_ayrinti(mat_ahsap, doku_ince_g, doku_kabuk_n, 4.0, 0.3)
	mat_cam = SpatialMaterial.new()
	mat_cam.albedo_color = Color(0.25, 0.45, 0.6, 0.55)
	mat_cam.flags_transparent = true
	mat_cam.metallic = 0.6
	mat_cam.roughness = 0.05
	mat_kumas = SpatialMaterial.new()
	mat_kumas.albedo_color = Color(0.30, 0.32, 0.23)
	mat_kumas.roughness = 1.0
	_ayrinti(mat_kumas, doku_ince_g, doku_ince_n, 3.0, 0.5)
	mat_ten = SpatialMaterial.new()
	mat_ten.albedo_color = Color(0.80, 0.62, 0.50)
	mat_ten.roughness = 0.7
	mat_lastik = SpatialMaterial.new()
	mat_lastik.albedo_color = Color(0.07, 0.07, 0.07)
	mat_lastik.roughness = 0.95
	_ayrinti(mat_lastik, null, doku_ince_n, 2.5, 0.8)
	mat_far = SpatialMaterial.new()
	mat_far.albedo_color = Color(1.0, 0.95, 0.8)
	mat_far.emission_enabled = true
	mat_far.emission = Color(1.0, 0.92, 0.75)
	mat_far.emission_energy = 0.4
	mat_alev = SpatialMaterial.new()
	mat_alev.flags_unshaded = true
	mat_alev.flags_transparent = true
	mat_alev.params_blend_mode = SpatialMaterial.BLEND_MODE_ADD
	mat_alev.params_cull_mode = SpatialMaterial.CULL_DISABLED
	mat_alev.albedo_color = Color(1.0, 0.65, 0.25, 0.9)


func kumas(renk: Color) -> SpatialMaterial:
	var m = mat_kumas.duplicate()
	m.albedo_color = renk
	return m


# ---------------------------------------------------------------- yardımcı: birden çok parçayı tek ağa birleştir
func birlestir(parcalar: Array, malzeme: Material = null) -> ArrayMesh:
	# parcalar: [[PrimitiveMesh, Transform], ...]
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for p in parcalar:
		var m = p[0]
		var am = m
		if not (m is ArrayMesh):
			am = ArrayMesh.new()
			am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, m.get_mesh_arrays())
		st.append_from(am, 0, p[1])
	var sonuc = st.commit()
	if malzeme != null:
		sonuc.surface_set_material(0, malzeme)
	return sonuc


func silindir(alt_r: float, ust_r: float, boy: float, kenar: int = 10) -> CylinderMesh:
	var c = CylinderMesh.new()
	c.bottom_radius = alt_r
	c.top_radius = ust_r
	c.height = boy
	c.radial_segments = kenar
	c.rings = 1
	return c


func kure(r: float, boy: float = -1.0, kenar: int = 12, halka: int = 6, yarim: bool = false) -> SphereMesh:
	var s = SphereMesh.new()
	s.radius = r
	s.height = r * 2.0 if boy < 0.0 else boy
	s.radial_segments = kenar
	s.rings = halka
	s.is_hemisphere = yarim
	return s


func kutu(boyut: Vector3) -> CubeMesh:
	var c = CubeMesh.new()
	c.size = boyut
	return c


func pah(boyut: Vector3, c: float) -> ArrayMesh:
	# kenarları pahlı (kırık) kutu: Z boyunca sekizgen kesit. Kenarlar ışığı yakalar, kutu gibi durmaz.
	var hx = boyut.x * 0.5
	var hy = boyut.y * 0.5
	var hz = boyut.z * 0.5
	c = min(c, min(hx, hy) * 0.9)
	var k = [Vector2(hx - c, hy), Vector2(hx, hy - c), Vector2(hx, -hy + c), Vector2(hx - c, -hy),
		Vector2(-hx + c, -hy), Vector2(-hx, -hy + c), Vector2(-hx, hy - c), Vector2(-hx + c, hy)]
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in 8:
		var a = k[i]
		var b = k[(i + 1) % 8]
		var n = Vector3(a.y - b.y, b.x - a.x, 0).normalized()
		for v in [Vector3(b.x, b.y, -hz), Vector3(b.x, b.y, hz), Vector3(a.x, a.y, hz),
				Vector3(a.x, a.y, -hz), Vector3(b.x, b.y, -hz), Vector3(a.x, a.y, hz)]:
			st.add_normal(n)
			st.add_vertex(v)
	for yon in [1.0, -1.0]:
		for i in range(1, 7):
			var uc = [k[0], k[i], k[i + 1]] if yon > 0.0 else [k[0], k[i + 1], k[i]]
			for q in uc:
				st.add_normal(Vector3(0, 0, yon))
				st.add_vertex(Vector3(q.x, q.y, hz * yon))
	return st.commit()


func _k(ayrintili: bool, b: Vector3) -> Mesh:
	var m = min(b.x, b.y)
	if ayrintili and m > 0.012:
		return pah(b, m * 0.22)
	return kutu(b)


func dt(konum: Vector3, don: Vector3 = Vector3(), olcek: Vector3 = Vector3(1, 1, 1)) -> Transform:
	var b = Basis(Quat(don)).scaled(olcek)
	return Transform(b, konum)


# ---------------------------------------------------------------- ağaçlar
func _agac_meshleri():
	var k = 10 if kalite >= 2 else 7
	var h = 6 if kalite >= 2 else 4
	# 0 yapraklı ağaç: gövde + 2 dal; tepe 5 yaprak kümesi
	var g = birlestir([[silindir(0.42, 0.22, 5.0, 8), dt(Vector3(0, 2.5, 0))],
		[silindir(0.16, 0.08, 2.4, 6), dt(Vector3(0.55, 4.6, 0.1), Vector3(0, 0, -0.8))],
		[silindir(0.15, 0.07, 2.2, 6), dt(Vector3(-0.5, 4.8, -0.2), Vector3(0.3, 0, 0.75))]])
	var t = birlestir([[kure(2.6, 4.2, k, h), dt(Vector3(0, 6.4, 0))],
		[kure(1.9, 3.0, k, h), dt(Vector3(1.5, 5.6, 0.4))],
		[kure(2.0, 3.2, k, h), dt(Vector3(-1.3, 5.8, -0.7))],
		[kure(1.7, 2.6, k, h), dt(Vector3(0.3, 7.7, -0.4))],
		[kure(1.6, 2.4, k, h), dt(Vector3(-0.4, 6.0, 1.4))]])
	agac_meshleri.append([g, t, 0.42, 5.0])
	# 1 kozalaklı: gövde + 4 kat koni
	g = birlestir([[silindir(0.36, 0.15, 9.0, 7), dt(Vector3(0, 4.5, 0))]])
	t = birlestir([[silindir(2.9, 0.6, 3.6, k), dt(Vector3(0, 3.6, 0))],
		[silindir(2.4, 0.5, 3.2, k), dt(Vector3(0, 5.6, 0))],
		[silindir(1.8, 0.35, 2.9, k), dt(Vector3(0, 7.5, 0))],
		[silindir(1.1, 0.0, 2.6, k), dt(Vector3(0, 9.3, 0))]])
	agac_meshleri.append([g, t, 0.36, 9.0])
	# 2 palmiye: hafif eğik gövde + 8 sarkan yaprak
	g = birlestir([[silindir(0.30, 0.24, 3.0, 8), dt(Vector3(0, 1.5, 0))],
		[silindir(0.25, 0.21, 3.0, 8), dt(Vector3(0.15, 4.4, 0), Vector3(0, 0, -0.08))],
		[silindir(0.22, 0.18, 2.8, 8), dt(Vector3(0.42, 7.2, 0), Vector3(0, 0, -0.15))]])
	var yapraklar = [[kure(0.55, 0.9, 8, 4), dt(Vector3(0.6, 8.6, 0))]]
	for i in 8:
		var a = i * TAU / 8.0
		var d = Vector3(cos(a), 0, sin(a))
		yapraklar.append([kutu(Vector3(0.7, 0.05, 3.4)), Transform(Basis(Vector3.UP, -a + PI / 2.0) * Basis(Vector3.RIGHT, 0.45), Vector3(0.6, 8.3, 0) + d * 1.5)])
	agac_meshleri.append([g, birlestir(yapraklar), 0.3, 8.0])
	# 3 tropik ağaç: uzun gövde + destek kökleri + yassı geniş tepe
	g = birlestir([[silindir(0.7, 0.42, 13.0, 9), dt(Vector3(0, 6.5, 0))],
		[kutu(Vector3(0.2, 1.6, 1.4)), dt(Vector3(0.75, 0.7, 0), Vector3(0, 0, 0.35))],
		[kutu(Vector3(0.2, 1.6, 1.4)), dt(Vector3(-0.75, 0.7, 0), Vector3(0, 0, -0.35))],
		[kutu(Vector3(1.4, 1.6, 0.2)), dt(Vector3(0, 0.7, 0.75), Vector3(-0.35, 0, 0))]])
	t = birlestir([[kure(5.6, 5.0, k + 2, h), dt(Vector3(0, 14.0, 0))],
		[kure(4.0, 3.6, k, h), dt(Vector3(3.2, 12.8, 1.0))],
		[kure(3.8, 3.4, k, h), dt(Vector3(-2.8, 13.1, -1.6))],
		[kure(3.2, 3.0, k, h), dt(Vector3(0.5, 15.5, 2.4))]])
	agac_meshleri.append([g, t, 0.7, 13.0])


func _cimen_meshi():
	# her örnek: 5 ince yaprak; dipte koyu, uçta açık renk
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng = RandomNumberGenerator.new()
	rng.seed = 77
	for i in 5:
		var a = rng.randf() * TAU
		var o = Vector3(rng.randf_range(-0.15, 0.15), 0, rng.randf_range(-0.15, 0.15))
		var yan = Vector3(cos(a), 0, sin(a)) * 0.045
		var boy = rng.randf_range(0.35, 0.65)
		var egik = Vector3(sin(a), 0, -cos(a)) * rng.randf_range(0.05, 0.18)
		var n = Vector3(sin(a), 0.3, -cos(a)).normalized()
		for v in [[o - yan, 0.0], [o + yan, 0.0], [o + egik + Vector3(0, boy, 0), 1.0]]:
			st.add_color(Color(0.55, 0.6, 0.5).linear_interpolate(Color(1, 1, 1), v[1]))
			st.add_normal(n)
			st.add_uv(Vector2(0, v[1]))
			st.add_vertex(v[0])
	cimen_mesh = st.commit()


# ---------------------------------------------------------------- silahlar (birinci şahıs ve öteki askerler)
func silah_modeli(i: int, ayrintili: bool = true) -> Spatial:
	var s = Spatial.new()
	var k = 14 if ayrintili else 8
	var uz = [0.75, 1.0, 0.5, 0.7, 0.22][i]
	var p = []   # [mesh, transform, malzeme]
	var namlu_r = [0.011, 0.012, 0.010, 0.016, 0.008][i]
	var Z = Vector3(PI / 2.0, 0, 0)
	if i == 4:
		# tabanca: sürgü, gövde, kabza, namlu ucu
		p.append([_k(ayrintili, Vector3(0.032, 0.035, 0.2)), dt(Vector3(0, 0.02, -0.08)), mat_metal])
		p.append([_k(ayrintili, Vector3(0.03, 0.02, 0.17)), dt(Vector3(0, -0.005, -0.07)), mat_polimer])
		p.append([_k(ayrintili, Vector3(0.028, 0.11, 0.045)), dt(Vector3(0, -0.06, 0.0), Vector3(-0.25, 0, 0)), mat_polimer])
		p.append([silindir(namlu_r, namlu_r, 0.03, k), dt(Vector3(0, 0.02, -0.19), Z), mat_metal])
		p.append([_k(ayrintili, Vector3(0.006, 0.01, 0.01)), dt(Vector3(0, 0.042, -0.17)), mat_metal])
		p.append([_k(ayrintili, Vector3(0.02, 0.008, 0.012)), dt(Vector3(0, 0.042, 0.01)), mat_metal])
	else:
		# gövde (receiver), namlu, el kundağı + raylar, nişangâhlar, kabza, tetik korkuluğu
		p.append([_k(ayrintili, Vector3(0.05, 0.07, 0.3)), dt(Vector3(0, 0, -0.05)), mat_metal])
		p.append([silindir(namlu_r, namlu_r, uz * 0.7, k), dt(Vector3(0, 0.012, -0.2 - uz * 0.35), Z), mat_metal])
		p.append([silindir(namlu_r * 1.9, namlu_r * 1.6, 0.06, k), dt(Vector3(0, 0.012, -0.2 - uz * 0.7), Z), mat_metal])
		if i != 3:
			p.append([_k(ayrintili, Vector3(0.056, 0.06, uz * 0.35)), dt(Vector3(0, 0.004, -0.22 - uz * 0.17)), mat_polimer if i != 0 else mat_ahsap])
			for r in 4:
				p.append([_k(ayrintili, Vector3(0.02, 0.008, 0.012)), dt(Vector3(0, 0.038, -0.13 - r * 0.035)), mat_metal])
		p.append([_k(ayrintili, Vector3(0.008, 0.03, 0.01)), dt(Vector3(0, 0.05, -0.2 - uz * 0.6)), mat_metal])
		p.append([_k(ayrintili, Vector3(0.024, 0.02, 0.03)), dt(Vector3(0, 0.045, 0.06)), mat_metal])
		p.append([_k(ayrintili, Vector3(0.035, 0.1, 0.045)), dt(Vector3(0, -0.075, 0.05), Vector3(-0.3, 0, 0)), mat_polimer])
		p.append([_k(ayrintili, Vector3(0.008, 0.008, 0.06)), dt(Vector3(0, -0.045, -0.005)), mat_metal])
		# dipçik
		if i != 2:
			p.append([_k(ayrintili, Vector3(0.04, 0.07, 0.24)), dt(Vector3(0, -0.02, 0.2), Vector3(0.08, 0, 0)), mat_ahsap if i in [0, 3] else mat_polimer])
			p.append([_k(ayrintili, Vector3(0.045, 0.1, 0.02)), dt(Vector3(0, -0.03, 0.32)), mat_lastik])
		else:
			p.append([_k(ayrintili, Vector3(0.012, 0.012, 0.18)), dt(Vector3(0.018, 0.0, 0.14)), mat_metal])
			p.append([_k(ayrintili, Vector3(0.012, 0.012, 0.18)), dt(Vector3(-0.018, 0.0, 0.14)), mat_metal])
			p.append([_k(ayrintili, Vector3(0.05, 0.06, 0.02)), dt(Vector3(0, -0.01, 0.23)), mat_polimer])
		# şarjör: tüfek ve makinelide kavisli (iki parça)
		if i in [0, 2]:
			p.append([_k(ayrintili, Vector3(0.03, 0.09, 0.05)), dt(Vector3(0, -0.075, -0.1), Vector3(0.15, 0, 0)), mat_polimer])
			p.append([_k(ayrintili, Vector3(0.03, 0.08, 0.05)), dt(Vector3(0, -0.15, -0.085), Vector3(0.45, 0, 0)), mat_polimer])
		elif i == 1:
			p.append([_k(ayrintili, Vector3(0.03, 0.06, 0.07)), dt(Vector3(0, -0.06, -0.08)), mat_metal])
		if i == 1:
			# dürbün: gövde, iki halka, merceklerin camı, ayar düğmeleri
			p.append([silindir(0.018, 0.018, 0.24, k), dt(Vector3(0, 0.075, -0.07), Z), mat_metal])
			p.append([silindir(0.026, 0.02, 0.06, k), dt(Vector3(0, 0.075, -0.2), Z), mat_metal])
			p.append([silindir(0.02, 0.024, 0.05, k), dt(Vector3(0, 0.075, 0.06), Z), mat_metal])
			p.append([silindir(0.024, 0.024, 0.004, k), dt(Vector3(0, 0.075, -0.232), Z), mat_cam])
			p.append([silindir(0.012, 0.012, 0.03, k), dt(Vector3(0, 0.1, -0.07)), mat_metal])
			p.append([_k(ayrintili, Vector3(0.012, 0.035, 0.012)), dt(Vector3(0, 0.05, -0.12)), mat_metal])
			p.append([_k(ayrintili, Vector3(0.012, 0.035, 0.012)), dt(Vector3(0, 0.05, 0.0)), mat_metal])
		if i == 3:
			# pompalı: tüp şarjör ve pompa kolu
			p.append([silindir(0.013, 0.013, uz * 0.6, k), dt(Vector3(0, -0.02, -0.2 - uz * 0.3), Z), mat_metal])
			p.append([silindir(0.024, 0.024, 0.16, k), dt(Vector3(0, -0.02, -0.32), Z), mat_ahsap])
	for e in p:
		var m = MeshInstance.new()
		m.mesh = e[0]
		m.transform = e[1]
		m.material_override = e[2]
		m.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF if ayrintili else GeometryInstance.SHADOW_CASTING_SETTING_ON
		s.add_child(m)
	# namlu alevi (ateş edilince kısa süre görünür)
	var alev = MeshInstance.new()
	var am = []
	for r in 3:
		am.append([kutu(Vector3(0.22, 0.001, 0.09)), dt(Vector3(0, 0, -0.04), Vector3(0, 0, r * PI / 3.0))])
	am.append([kure(0.04, 0.08, 8, 4), dt(Vector3(0, 0, -0.01))])
	alev.mesh = birlestir(am, mat_alev)
	alev.translation = Vector3(0, 0.012, -0.2 - uz * 0.75) if i != 4 else Vector3(0, 0.02, -0.22)
	alev.name = "alev"
	alev.visible = false
	alev.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
	s.add_child(alev)
	return s


# ---------------------------------------------------------------- gölgelendiriciler
const SU_GOLGELENDIRICI = """
shader_type spatial;
render_mode blend_mix, depth_draw_always, cull_disabled, specular_schlick_ggx;
uniform vec4 sig : hint_color = vec4(0.16, 0.46, 0.50, 1.0);
uniform vec4 derin : hint_color = vec4(0.02, 0.14, 0.24, 1.0);
uniform sampler2D dalga : hint_normal;
uniform vec2 kayma = vec2(0.0);
uniform float koyuluk = 1.0;
varying vec3 dk;
void vertex() {
	dk = (WORLD_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	vec2 uv = (dk.xz + kayma) * 0.035;
	vec3 n1 = texture(dalga, uv + TIME * vec2(0.010, 0.004)).rgb;
	vec3 n2 = texture(dalga, uv * 1.9 + TIME * vec2(-0.006, 0.011)).rgb;
	NORMALMAP = mix(n1, n2, 0.5);
	NORMALMAP_DEPTH = 0.55;
	float zd = texture(DEPTH_TEXTURE, SCREEN_UV).r;
	vec3 ndc = vec3(SCREEN_UV, zd) * 2.0 - 1.0;
	vec4 v = INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
	v.xyz /= v.w;
	float fark = clamp(-v.z + VERTEX.z, 0.0, 60.0);
	float d = clamp(fark / 7.0, 0.0, 1.0);
	vec3 renk = mix(sig.rgb, derin.rgb, d) * koyuluk;
	float kopuk = (1.0 - smoothstep(0.0, 0.9, fark)) * (0.65 + 0.35 * sin(TIME * 1.4 + dk.x * 0.35 + dk.z * 0.22));
	ALBEDO = mix(renk, vec3(0.9) * koyuluk, clamp(kopuk, 0.0, 1.0));
	ALPHA = clamp(0.4 + d * 0.55 + kopuk * 0.5, 0.0, 0.96);
	ROUGHNESS = 0.03;
	METALLIC = 0.0;
	SPECULAR = 0.75;
}
"""

const CIMEN_GOLGELENDIRICI = """
shader_type spatial;
render_mode cull_disabled, diffuse_lambert_wrap, specular_disabled;
uniform float ruzgar = 1.0;
varying float uc;
void vertex() {
	vec3 dk = (WORLD_MATRIX * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
	float s = sin(TIME * 1.9 + dk.x * 0.31 + dk.z * 0.23) * 0.13 * ruzgar + sin(TIME * 4.1 + dk.x) * 0.03;
	VERTEX.x += s * VERTEX.y * 2.0;
	VERTEX.z += s * 0.6 * VERTEX.y * 2.0;
	float uzak = length((MODELVIEW_MATRIX * vec4(0.0, 0.0, 0.0, 1.0)).xyz);
	VERTEX *= 1.0 - smoothstep(42.0, 62.0, uzak);
	uc = UV.y;
}
void fragment() {
	vec3 c = pow(COLOR.rgb, vec3(2.2));
	ALBEDO = c;
	ROUGHNESS = 0.9;
	TRANSMISSION = c * 0.6 * uc;
}
"""
