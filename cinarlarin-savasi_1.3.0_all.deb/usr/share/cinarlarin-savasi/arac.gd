extends VehicleBody
# Çınarların Savaşı: cip
# Sürücünün bilgisayarı aracı fizikle sürer; ötekilerde araç ağdan gelen konuma gider.

const Ses = preload("res://ses.gd")

var numara = 0
var dunya
var surucu = null
var kamera: Camera
var kam_yaw = 0.0
var kam_pitch = -0.2
var hedef_g = null      # dünya koordinatı (orijin kaydırmadan etkilenmez)
var hedef_q = Quat()
var motor: AudioStreamPlayer3D
var ters_sure = 0.0
var farlar = []


func _ready():
	mass = 1300.0
	collision_layer = 1
	collision_mask = 1
	mode = RigidBody.MODE_KINEMATIC
	can_sleep = false
	var cs = CollisionShape.new()
	var bs = BoxShape.new()
	bs.extents = Vector3(1.0, 0.55, 2.2)
	cs.shape = bs
	cs.translation = Vector3(0, 1.05, 0)
	add_child(cs)
	var g = dunya.gorsel
	var k = 16 if dunya.kalite >= 2 else 10
	var haki = g.kumas(Color(0.34, 0.37, 0.25))
	haki.roughness = 0.6
	haki.metallic = 0.25
	var koyu = g.mat_polimer
	var metal = g.mat_metal
	# gövde: şasi, kasa, çamurluklar, kaput, ızgara, ön cam çerçevesi, koruma demiri, koltuklar
	for p in [[g.kutu(Vector3(1.7, 0.25, 4.3)), Vector3(0, 0.72, 0), koyu],
			[g.kutu(Vector3(1.95, 0.55, 4.1)), Vector3(0, 1.08, -0.05), haki],
			[g.kutu(Vector3(1.9, 0.18, 1.55)), Vector3(0, 1.43, 1.3), haki],
			[g.kutu(Vector3(1.6, 0.42, 0.1)), Vector3(0, 1.12, 2.15), koyu],
			[g.kutu(Vector3(1.75, 0.22, 0.2)), Vector3(0, 0.82, 2.25), metal],
			[g.kutu(Vector3(1.75, 0.22, 0.2)), Vector3(0, 0.82, -2.18), metal],
			[g.kutu(Vector3(1.8, 0.05, 0.62)), Vector3(0, 1.82, 0.42), g.mat_cam, Vector3(-0.25, 0, 0)],
			[g.kutu(Vector3(0.06, 0.66, 0.06)), Vector3(-0.9, 1.8, 0.45), metal, Vector3(-0.25, 0, 0)],
			[g.kutu(Vector3(0.06, 0.66, 0.06)), Vector3(0.9, 1.8, 0.45), metal, Vector3(-0.25, 0, 0)],
			[g.kutu(Vector3(1.86, 0.06, 0.06)), Vector3(0, 2.11, 0.37), metal],
			[g.kutu(Vector3(0.5, 0.5, 0.5)), Vector3(-0.45, 1.5, -0.25), koyu],
			[g.kutu(Vector3(0.5, 0.5, 0.5)), Vector3(0.45, 1.5, -0.25), koyu],
			[g.kutu(Vector3(0.3, 0.42, 0.18)), Vector3(0.75, 1.55, -1.95), haki],
			[g.kutu(Vector3(0.3, 0.42, 0.18)), Vector3(0.38, 1.55, -1.95), haki]]:
		var m = MeshInstance.new()
		m.mesh = p[0]
		m.translation = p[1]
		m.material_override = p[2]
		if p.size() > 3:
			m.rotation = p[3]
		add_child(m)
	for p in [[Vector3(-0.98, 1.05, 1.45)], [Vector3(0.98, 1.05, 1.45)], [Vector3(-0.98, 1.05, -1.45)], [Vector3(0.98, 1.05, -1.45)]]:
		var c = MeshInstance.new()
		c.mesh = g.silindir(0.6, 0.6, 0.32, k)
		c.translation = p[0]
		c.rotation = Vector3(0, 0, PI / 2.0)
		c.material_override = haki
		add_child(c)
	for x in [-0.82, 0.82]:
		var r = MeshInstance.new()
		r.mesh = g.silindir(0.045, 0.045, 1.2, 8)
		r.translation = Vector3(x, 2.05, -1.0)
		r.material_override = metal
		add_child(r)
		var f = MeshInstance.new()
		f.mesh = g.kure(0.11, 0.1, 12, 4, true)
		f.translation = Vector3(x * 0.85, 1.18, 2.2)
		f.rotation = Vector3(PI / 2.0, 0, 0)
		f.material_override = g.mat_far
		add_child(f)
		var isik = SpotLight.new()
		isik.translation = Vector3(x * 0.85, 1.18, 2.3)
		isik.rotation = Vector3(0, PI, 0)
		isik.spot_range = 60.0
		isik.spot_angle = 32.0
		isik.light_energy = 3.0
		isik.light_color = Color(1.0, 0.93, 0.78)
		isik.visible = false
		add_child(isik)
		farlar.append(isik)
	var bar = MeshInstance.new()
	bar.mesh = g.silindir(0.045, 0.045, 1.66, 8)
	bar.translation = Vector3(0, 2.6, -1.0)
	bar.rotation = Vector3(0, 0, PI / 2.0)
	bar.material_override = metal
	add_child(bar)
	var yedek = MeshInstance.new()
	yedek.mesh = g.silindir(0.42, 0.42, 0.28, k)
	yedek.translation = Vector3(0, 1.45, -2.3)
	yedek.rotation = Vector3(PI / 2.0, 0, 0)
	yedek.material_override = g.mat_lastik
	add_child(yedek)
	for t in [Vector3(-0.95, 0.55, 1.45), Vector3(0.95, 0.55, 1.45), Vector3(-0.95, 0.55, -1.45), Vector3(0.95, 0.55, -1.45)]:
		var w = VehicleWheel.new()
		w.translation = t
		w.use_as_steering = t.z > 0
		w.use_as_traction = true
		w.wheel_radius = 0.45
		w.wheel_rest_length = 0.32
		w.suspension_travel = 0.3
		w.suspension_stiffness = 45.0
		w.suspension_max_force = 14000.0
		w.damping_compression = 0.9
		w.damping_relaxation = 1.2
		w.wheel_friction_slip = 2.8
		w.wheel_roll_influence = 0.08
		var lastik = MeshInstance.new()
		lastik.mesh = g.silindir(0.45, 0.45, 0.32, k + 4)
		lastik.rotation_degrees = Vector3(0, 0, 90)
		lastik.material_override = g.mat_lastik
		w.add_child(lastik)
		var jant = MeshInstance.new()
		jant.mesh = g.silindir(0.24, 0.24, 0.34, k)
		jant.rotation_degrees = Vector3(0, 0, 90)
		jant.material_override = metal
		w.add_child(jant)
		add_child(w)
	kamera = Camera.new()
	kamera.far = 5000.0
	kamera.fov = 75.0
	add_child(kamera)
	kamera.set_as_toplevel(true)
	motor = AudioStreamPlayer3D.new()
	motor.stream = Ses.motor()
	motor.unit_db = -4.0
	motor.max_distance = 300.0
	add_child(motor)


func yerlestir(g: Vector3, q: Quat):
	global_transform = Transform(Basis(q), dunya.yerel(g))
	hedef_g = g
	hedef_q = q


func uzaktan(g: Vector3, q: Quat):
	if surucu != null:
		return
	if hedef_g == null or (hedef_g as Vector3).distance_to(g) > 40.0:
		global_transform = Transform(Basis(q), dunya.yerel(g))
	hedef_g = g
	hedef_q = q


func surucu_ol(o):
	surucu = o
	mode = RigidBody.MODE_RIGID
	sleeping = false
	kam_yaw = 0.0
	kam_pitch = -0.2
	kamera.current = true
	motor.play()


func surucu_birak():
	surucu = null
	engine_force = 0.0
	brake = 0.0
	steering = 0.0
	linear_velocity = Vector3()
	angular_velocity = Vector3()
	mode = RigidBody.MODE_KINEMATIC
	hedef_g = dunya.kuresel(translation)
	hedef_q = global_transform.basis.get_rotation_quat()
	motor.stop()


func kamera_dondur(dx: float, dy: float):
	kam_yaw += dx
	kam_pitch = clamp(kam_pitch + dy, -1.2, 0.4)


func _physics_process(delta):
	if surucu == null:
		if hedef_g != null:
			var t = global_transform
			t.origin = t.origin.linear_interpolate(dunya.yerel(hedef_g), min(1.0, delta * 10.0))
			t.basis = Basis(t.basis.get_rotation_quat().slerp(hedef_q, min(1.0, delta * 10.0)))
			global_transform = t
		return
	var yakalandi = Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED
	var gaz = 0.0
	var don = 0.0
	if yakalandi:
		gaz = Input.get_action_strength("ileri") - Input.get_action_strength("geri")
		don = Input.get_action_strength("sol") - Input.get_action_strength("sag")
	var ileri_hiz = global_transform.basis.z.dot(linear_velocity)
	steering = lerp(steering, don * 0.5, min(1.0, delta * 4.0))
	brake = 0.0
	if gaz < 0.0 and ileri_hiz > 1.5:
		engine_force = 0.0
		brake = 30.0
	elif abs(ileri_hiz) < 32.0:
		engine_force = gaz * 2800.0
	else:
		engine_force = 0.0
	if yakalandi and Input.is_action_pressed("zipla"):
		brake = 45.0
	# devrilirse kendiliğinden doğrul
	if global_transform.basis.y.y < 0.3 and linear_velocity.length() < 2.0:
		ters_sure += delta
		if ters_sure > 2.5:
			var t = global_transform
			var on = Vector3(t.basis.z.x, 0, t.basis.z.z).normalized()
			if on.length() < 0.1:
				on = Vector3.FORWARD
			t.basis = Basis(on.cross(Vector3.UP).normalized() * -1.0, Vector3.UP, on)
			t.origin.y += 2.0
			global_transform = t
			linear_velocity = Vector3()
			angular_velocity = Vector3()
			ters_sure = 0.0
	else:
		ters_sure = 0.0
	# araziden düşmeyi önle
	var g = dunya.kuresel(translation)
	var zemin = dunya.arazi.yukseklik(g.x, g.z)
	if translation.y < zemin - 3.0:
		var t = global_transform
		t.origin.y = zemin + 1.5
		global_transform = t
		linear_velocity = Vector3()
	motor.pitch_scale = 0.7 + min(abs(ileri_hiz), 30.0) / 30.0 * 1.3


func _process(_delta):
	var gece = dunya.gunluk < 0.35
	var hareketli = surucu != null or (hedef_g != null and Ag.araclar[numara].surucu != -1)
	for f in farlar:
		f.visible = gece and hareketli
	if surucu == null:
		return
	var b = global_transform.basis
	var yon = Vector3(b.z.x, 0, b.z.z).normalized()
	if yon.length() < 0.1:
		yon = Vector3.FORWARD
	var arka = -yon.rotated(Vector3.UP, kam_yaw)
	var hedef = global_transform.origin + Vector3(0, 1.6, 0)
	var konum = hedef + arka * cos(kam_pitch) * 8.0 - Vector3(0, sin(kam_pitch) * 8.0, 0)
	kamera.global_transform = Transform(Basis(), konum).looking_at(hedef, Vector3.UP)
