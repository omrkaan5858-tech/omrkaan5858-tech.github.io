extends Reference
# Çınarların Savaşı: sesler kodla üretilir (dosya gerekmez)

const HIZ = 22050


static func _ornek(veri: PoolRealArray) -> AudioStreamSample:
	var b = PoolByteArray()
	b.resize(veri.size() * 2)
	for i in veri.size():
		var v = int(clamp(veri[i], -1.0, 1.0) * 32000.0)
		if v < 0:
			v += 65536
		b[i * 2] = v & 0xff
		b[i * 2 + 1] = (v >> 8) & 0xff
	var s = AudioStreamSample.new()
	s.format = AudioStreamSample.FORMAT_16_BITS
	s.mix_rate = HIZ
	s.stereo = false
	s.data = b
	return s


static func atis(tur: int) -> AudioStreamSample:
	# tur: silah numarası. Gürültü patlaması + düşük gümbürtü
	var uzunluk = [0.35, 0.8, 0.22, 0.6, 0.25][tur]
	var guc = [0.9, 1.0, 0.7, 1.0, 0.75][tur]
	var kalin = [90.0, 60.0, 130.0, 70.0, 160.0][tur]
	var n = int(HIZ * uzunluk)
	var a = PoolRealArray()
	a.resize(n)
	var rng = RandomNumberGenerator.new()
	rng.seed = 88 + tur
	var onceki = 0.0
	for i in n:
		var t = float(i) / HIZ
		var zarf = exp(-t * (14.0 if tur != 1 else 7.0))
		var gurultu = rng.randf_range(-1.0, 1.0)
		onceki = onceki * 0.55 + gurultu * 0.45          # biraz yumuşat
		var gum = sin(t * kalin * TAU) * exp(-t * 9.0)
		a[i] = (onceki * 0.8 + gum * 0.6) * zarf * guc
	return _ornek(a)


static func dolum() -> AudioStreamSample:
	var n = int(HIZ * 0.5)
	var a = PoolRealArray()
	a.resize(n)
	for i in n:
		var t = float(i) / HIZ
		var v = 0.0
		for tik in [0.05, 0.32]:
			var d = t - tik
			if d > 0.0 and d < 0.03:
				v += sin(d * 2400.0 * TAU) * exp(-d * 160.0)
		a[i] = v * 0.7
	return _ornek(a)


static func isabet() -> AudioStreamSample:
	var n = int(HIZ * 0.08)
	var a = PoolRealArray()
	a.resize(n)
	for i in n:
		var t = float(i) / HIZ
		a[i] = sin(t * 1800.0 * TAU) * exp(-t * 50.0) * 0.5
	return _ornek(a)


static func bos() -> AudioStreamSample:
	var n = int(HIZ * 0.06)
	var a = PoolRealArray()
	a.resize(n)
	for i in n:
		var t = float(i) / HIZ
		a[i] = sin(t * 900.0 * TAU) * exp(-t * 90.0) * 0.4
	return _ornek(a)


static func motor() -> AudioStreamSample:
	# döngüye alınan motor uğultusu
	var n = int(HIZ * 0.5)
	var a = PoolRealArray()
	a.resize(n)
	for i in n:
		var t = float(i) / HIZ
		a[i] = (sin(t * 55.0 * TAU) * 0.5 + sin(t * 110.0 * TAU) * 0.25 + sin(t * 165.0 * TAU) * 0.12) * 0.5
	var s = _ornek(a)
	s.loop_mode = AudioStreamSample.LOOP_FORWARD
	s.loop_begin = 0
	s.loop_end = n
	return s
