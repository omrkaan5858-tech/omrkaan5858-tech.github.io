// Çınar OS masaüstü varsayılanları: duvar kağıdı, başlat menüsü simgesi, görev çubuğu kısayolları
var ds = desktops();
for (var i = 0; i < ds.length; i++) {
    ds[i].wallpaperPlugin = "org.kde.image";
    ds[i].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    ds[i].writeConfig("Image", "file:///usr/share/wallpapers/Cinar/");
}
var ps = panels();
for (var j = 0; j < ps.length; j++) {
    var ws = ps[j].widgets();
    for (var k = 0; k < ws.length; k++) {
        var w = ws[k];
        if (w.type == "org.kde.plasma.kickoff") {
            w.currentConfigGroup = ["General"];
            w.writeConfig("icon", "cinar-logo");
        }
        if (w.type == "org.kde.plasma.icontasks" || w.type == "org.kde.plasma.taskmanager") {
            w.currentConfigGroup = ["General"];
            w.writeConfig("launchers", ["applications:cinar-merkezi.desktop", "applications:org.kde.dolphin.desktop", "applications:firefox-esr.desktop", "applications:org.kde.konsole.desktop"]);
        }
    }
}
