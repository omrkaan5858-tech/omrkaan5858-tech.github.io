extends Reference
# Çınarların Savaşı: oyunun sabit bilgileri

const SURUM = "1.2"
const DUNYA_EN = 100000.0      # batı-doğu (metre)
const DUNYA_BOY = 250000.0     # kuzey-güney (metre)
const PARCA = 256.0            # bir arazi parçasının kenarı (metre)
const PORT = 9880              # oyun bağlantısı (UDP)
const BULMA_PORT = 9881        # yerel ağda oyun bulma (UDP yayını)
const EN_COK_OYUNCU = 40       # 20'ye 20
const TAKIM_EN_COK = 20
const YAKIN = 2000.0           # her oyuncuya sadece bu kadar yakındakiler gönderilir
const KAZANMA_PUANI = 500
const AGAC_CAN = 5000
const DUSME_SURESI = 3600.0    # bölge düşünce 1 saat kullanılamaz
const ELE_GECIRME = 30         # çınarın yanında düşmansız durma süresi (saniye)
const ELE_GECIRME_YARICAP = 45.0
const DOGMA_BEKLEME = 8.0
const GUN_UZUNLUGU = 1440.0    # 24 dakika = 1 oyun günü
const BASLANGIC_SAATI = 8.0    # oyun sabah 8'de başlar

const TAKIM_ADI = ["Yeşil Takım", "Kızıl Takım"]
const TAKIM_KISA = ["Yeşil", "Kızıl"]
const TAKIM_RENK = [Color(0.30, 0.80, 0.35), Color(0.90, 0.30, 0.25)]

const BOLGE_ADI = ["Avrupa", "Büyük Çöl", "Tropikal"]
const AGAC_ADI = ["Avrupa Çınarı", "Vaha Çınarı", "Orman Çınarı"]
# bölge çınarlarının yeri (x, z)
const AGAC_YERI = [Vector2(50000, 35000), Vector2(50000, 132000), Vector2(50000, 215000)]
const US_ARALIK = 2500.0       # takım üsleri çınarın batısında (yeşil) ve doğusunda (kızıl)
const BOLGE_SINIR = [81000.0, 181000.0]   # Avrupa | Çöl | Tropikal (z)

# Gerçek atış (isabet hesabı ve ağ) saniyede en fazla 9 kez yapılır. Daha hızlı silahlar ekranda ve seste
# hızlı ateş ediyormuş gibi görünür ("aralik"). Her gerçek atış, kendinden önceki görüntü mermilerinin
# hasarını toplu verir; böylece silahın gücü (saniyedeki hasarı) değişmez. "hasar" = mermi başına hasar.
const GERCEK_ATIS_SINIRI = 9.0
const SARJOR = 88
const YEDEK_SARJOR = 60
const SILAHLAR = [
	{"ad": "Kartal T-88", "tur": "Piyade tüfeği", "hasar": 28, "aralik": 0.10, "menzil": 800.0,
	 "sapma": 0.006, "dolum": 2.2, "otomatik": true, "zoom": 50.0, "sacma": 1, "tepme": 0.6, "uzunluk": 0.75},
	{"ad": "Atmaca K-88", "tur": "Keskin nişancı tüfeği", "hasar": 95, "aralik": 1.10, "menzil": 2000.0,
	 "sapma": 0.0, "dolum": 3.0, "otomatik": false, "zoom": 12.0, "sacma": 1, "tepme": 2.5, "uzunluk": 1.0},
	{"ad": "Arı H-88", "tur": "Hafif makineli", "hasar": 17, "aralik": 0.065, "menzil": 300.0,
	 "sapma": 0.02, "dolum": 1.8, "otomatik": true, "zoom": 60.0, "sacma": 1, "tepme": 0.35, "uzunluk": 0.5},
	{"ad": "Boğa P-88", "tur": "Pompalı tüfek", "hasar": 14, "aralik": 0.85, "menzil": 60.0,
	 "sapma": 0.06, "dolum": 2.6, "otomatik": false, "zoom": 65.0, "sacma": 8, "tepme": 3.0, "uzunluk": 0.7},
	{"ad": "Serçe S-88", "tur": "Tabanca", "hasar": 24, "aralik": 0.18, "menzil": 150.0,
	 "sapma": 0.01, "dolum": 1.4, "otomatik": false, "zoom": 65.0, "sacma": 1, "tepme": 1.0, "uzunluk": 0.22},
]


static func gercek_aralik(w: Dictionary) -> float:
	return max(w.aralik, 1.0 / GERCEK_ATIS_SINIRI)


static func gorsel_mermi(w: Dictionary) -> int:
	# bir gerçek atışın ekranda kaç mermi gibi göründüğü
	return int(max(1, round(gercek_aralik(w) / w.aralik)))


static func bolge(z: float) -> int:
	if z < BOLGE_SINIR[0]:
		return 0
	if z < BOLGE_SINIR[1]:
		return 1
	return 2


static func us_yeri(takim: int, b: int) -> Vector2:
	var a = AGAC_YERI[b]
	return Vector2(a.x - US_ARALIK if takim == 0 else a.x + US_ARALIK, a.y)


static func saat_metni(saat: float) -> String:
	var s = fmod(BASLANGIC_SAATI + saat / (GUN_UZUNLUGU / 24.0), 24.0)
	return "%02d:%02d" % [int(s), int((s - int(s)) * 60)]


static func gunun_saati(saat: float) -> float:
	return fmod(BASLANGIC_SAATI + saat / (GUN_UZUNLUGU / 24.0), 24.0)


static func karistir(a: int, b: int, c: int = 0) -> int:
	var h = (a * 73856093) ^ (b * 19349663) ^ (c * 83492791)
	h = (h ^ (h >> 13)) * 1274126177
	h = h ^ (h >> 16)
	return h & 0x7fffffff


static func hava(b: int, saat: float) -> int:
	# 0 açık, 1 bulutlu, 2 yağmur/sağanak, 3 sis, 4 kum fırtınası, 5 pus
	var r = karistir(b + 11, int(floor(saat / 600.0)), 9879) % 100
	if b == 0:
		return 0 if r < 50 else (1 if r < 70 else (2 if r < 90 else 3))
	if b == 1:
		return 0 if r < 70 else (5 if r < 85 else 4)
	return 0 if r < 40 else (1 if r < 60 else 2)


const HAVA_ADI = ["Açık", "Bulutlu", "Yağmurlu", "Sisli", "Kum fırtınası", "Puslu"]
