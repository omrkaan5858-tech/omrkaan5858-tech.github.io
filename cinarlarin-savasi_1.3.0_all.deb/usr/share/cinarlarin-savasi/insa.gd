extends Reference
# Basit geometri kurucu: kutu, çatı, silindir -> tek bir renkli ağ (mesh) + çarpışma yüzeyleri

var v = PoolVector3Array()
var n = PoolVector3Array()
var c = PoolColorArray()
var f = PoolVector3Array()     # çarpışma üçgenleri


func bos() -> bool:
	return v.size() == 0


func ucgen(a: Vector3, b: Vector3, d: Vector3, renk: Color, normal: Vector3, carp: bool = true):
	v.append(a); v.append(b); v.append(d)
	n.append(normal); n.append(normal); n.append(normal)
	c.append(renk); c.append(renk); c.append(renk)
	if carp:
		f.append(a); f.append(b); f.append(d)


func dortgen(a: Vector3, b: Vector3, d: Vector3, e: Vector3, renk: Color, normal: Vector3, carp: bool = true):
	ucgen(a, b, d, renk, normal, carp)
	ucgen(a, d, e, renk, normal, carp)


func kutu(taban: Vector3, en: float, boy: float, yuk: float, aci: float, renk: Color, carp: bool = true):
	var bs = Basis(Vector3.UP, aci)
	var x = bs.x * en * 0.5
	var z = bs.z * boy * 0.5
	var y = Vector3(0, yuk, 0)
	var p = [taban - x - z, taban + x - z, taban + x + z, taban - x + z]
	var u = [p[0] + y, p[1] + y, p[2] + y, p[3] + y]
	var koyu = renk.darkened(0.12)
	dortgen(p[0], p[1], u[1], u[0], koyu, -bs.z, carp)
	dortgen(p[1], p[2], u[2], u[1], renk, bs.x, carp)
	dortgen(p[2], p[3], u[3], u[2], koyu, bs.z, carp)
	dortgen(p[3], p[0], u[0], u[3], renk, -bs.x, carp)
	dortgen(u[0], u[1], u[2], u[3], renk.lightened(0.06), Vector3.UP, carp)


func cati(taban: Vector3, en: float, boy: float, yuk: float, aci: float, renk: Color, carp: bool = false):
	# sırt "en" yönünde uzanır
	var bs = Basis(Vector3.UP, aci)
	var x = bs.x * en * 0.5
	var z = bs.z * boy * 0.5
	var y = Vector3(0, yuk, 0)
	var s1 = taban - x + y
	var s2 = taban + x + y
	var n1 = (bs.z * yuk + Vector3.UP * boy * 0.5).normalized()
	var n2 = (-bs.z * yuk + Vector3.UP * boy * 0.5).normalized()
	dortgen(taban - x + z, taban + x + z, s2, s1, renk, n1, carp)
	dortgen(taban + x - z, taban - x - z, s1, s2, renk.darkened(0.1), n2, carp)
	ucgen(taban - x - z, taban - x + z, s1, renk.darkened(0.2), -bs.x, carp)
	ucgen(taban + x + z, taban + x - z, s2, renk.darkened(0.2), bs.x, carp)


func silindir(taban: Vector3, r: float, yuk: float, renk: Color, kenar: int = 8, carp: bool = true, ust_r: float = -1.0):
	if ust_r < 0.0:
		ust_r = r
	for i in kenar:
		var a1 = TAU * i / kenar
		var a2 = TAU * (i + 1) / kenar
		var d1 = Vector3(cos(a1), 0, sin(a1))
		var d2 = Vector3(cos(a2), 0, sin(a2))
		var nn = (d1 + d2).normalized()
		dortgen(taban + d1 * r, taban + d2 * r, taban + d2 * ust_r + Vector3(0, yuk, 0), taban + d1 * ust_r + Vector3(0, yuk, 0), renk if i % 2 == 0 else renk.darkened(0.06), nn, carp)
		if ust_r > 0.01:
			var tepe = taban + Vector3(0, yuk, 0)
			ucgen(tepe, tepe + d2 * ust_r, tepe + d1 * ust_r, renk.lightened(0.05), Vector3.UP, carp)


func yuzey_ekle(m: ArrayMesh, malzeme: Material):
	if v.size() == 0:
		return
	var a = []
	a.resize(Mesh.ARRAY_MAX)
	a[Mesh.ARRAY_VERTEX] = v
	a[Mesh.ARRAY_NORMAL] = n
	a[Mesh.ARRAY_COLOR] = c
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	m.surface_set_material(m.get_surface_count() - 1, malzeme)


func carpisma_sekli() -> ConcavePolygonShape:
	if f.size() == 0:
		return null
	var s = ConcavePolygonShape.new()
	s.set_faces(f)
	return s
