extends Node
# Çınarların Savaşı: ağ ve oyun kuralları
# Sunucu parçalara bölünmüştür, herkes bir parçasını kendi bilgisayarında taşır:
#  - HAREKET: Her oyuncu kendi hareketini yakınındaki oyunculara KENDİSİ gönderir (eşler arası ağ).
#  - HAKEM: Oyunu kuran oyuncu sadece hakemdir: can, çınarlar, puan, doğma, araç sahipliği.
#  - TANIŞTIRMA: Hakem, oyunculara birbirinin adresini verir; oyuncular birbirine doğrudan
#    bağlanır (UDP delik açma). Doğrudan bağlanamayanların hareketi hakem üzerinden gider.
#  - DEVİR: Hakem oyundan çıkarsa hakemlik kendiliğinden başka bir oyuncuya geçer, oyun sürer.

const V = preload("res://veri.gd")
const Arazi = preload("res://arazi.gd")

signal baglandi
signal baglanamadi
signal koptu(neden)
signal yakindakiler_geldi(liste, arac_liste)
signal atis_goster(bas, son, silah, atan_id, adet)
signal arac_degisti(i)
signal oyuncu_gitti_sinyal(id)
signal can_degisti_sinyal(id, can, olu, olduren)
signal dogdun_sinyal(konum)
signal olay_sinyal(metin)
signal durum_guncellendi
signal tur_bitti_sinyal(kazanan)
signal tur_basladi_sinyal
signal oyunlar_bulundu(liste)
signal isabet_sinyal(oldurdu)
signal hakem_degisti(metin)
signal devir_tamam
signal modem_sonuc(basarili, metin)

var arazi
var sunucu = false
var cevrimici = false
var benim_id = 0
var ad = "Oyuncu"
var oyuncular = {}
var puan = [0, 0]
var agaclar = []
var araclar = []
var saat = 0.0
var tur_sonu = false
var tur_sonu_zaman = 0.0
var agac_can_test = 0

var _gonderme = 0.0
var _saniye = 0.0
var _puan_sayac = 0
var _saldiri_uyari = [0.0, 0.0, 0.0]
var _yayin: PacketPeerUDP
var _yayin_zaman = 0.0
var _dinle: PacketPeerUDP
var bulunan = {}

# eşler arası ağ
var kimlik = ""
var sunucu_ip = ""
var sunucu_mesh_port = 0
var mesh: PacketPeerUDP
var mesh_port = 0
var esler = {}            # id -> {"ip", "port"}
var dogrudan = {}         # id -> son doğrudan paket zamanı (ms)
var rapor = {}            # (hakem) id -> o oyuncunun doğrudan aldığı oyuncular
var _benim_durum = null
var _mesh_zaman = 0.0
var _mesh_tik = 0
var _hakem_gonder = 0.0
var _esler_degisti = false
# hakem devri
var devir = false
var devir_ip = ""
var devir_deneme = 0
var bekleyen = {}         # (yeni hakem) kimlik -> eski oyuncu kaydı
var ayriliyor = false
# modem (UPnP): oyuncu izin verdiyse, hakem olduğunda modemde bağlantı noktası açılır
var modem_izni = false
var upnp = null
var modem_portlari = []
var dis_ip = ""
var _modem_is_parcacigi: Thread
var test_log = false
var aktarilan = 0         # (hakem) son saniyelerde aktarılan hareket sayısı


func _ready():
	randomize()
	kimlik = "%d-%d-%d" % [randi(), OS.get_unix_time(), OS.get_ticks_usec()]
	arazi = Arazi.new()
	get_tree().connect("network_peer_connected", self, "_baglanti_geldi")
	get_tree().connect("network_peer_disconnected", self, "_baglanti_gitti")
	get_tree().connect("connected_to_server", self, "_sunucuya_baglandi")
	get_tree().connect("connection_failed", self, "_baglanilamadi")
	get_tree().connect("server_disconnected", self, "_sunucu_gitti")


func _gonderen() -> int:
	var g = get_tree().get_rpc_sender_id()
	return g if g != 0 else benim_id


# ---------------------------------------------------------------- kurma / katılma
func oyun_kur(oyuncu_adi: String) -> String:
	var p = NetworkedMultiplayerENet.new()
	p.compression_mode = NetworkedMultiplayerENet.COMPRESS_RANGE_CODER
	var e = p.create_server(V.PORT, V.EN_COK_OYUNCU - 1)
	if e != OK:
		return "Oyun kurulamadı: %d numaralı bağlantı noktası kullanımda olabilir." % V.PORT
	get_tree().network_peer = p
	sunucu = true
	cevrimici = true
	ayriliyor = false
	benim_id = 1
	ad = _ad_temizle(oyuncu_adi)
	_dunyayi_sifirla()
	_oyuncu_ekle(1, ad, kimlik)
	_mesh_ac(V.PORT + 2)
	if modem_izni:
		modem_ac()
	_yayin = PacketPeerUDP.new()
	_yayin.set_broadcast_enabled(true)
	_yayin.set_dest_address("255.255.255.255", V.BULMA_PORT)
	return ""


func oyuna_katil(ip: String, oyuncu_adi: String) -> String:
	var p = NetworkedMultiplayerENet.new()
	p.compression_mode = NetworkedMultiplayerENet.COMPRESS_RANGE_CODER
	var e = p.create_client(ip.strip_edges(), V.PORT)
	if e != OK:
		return "Bu adrese bağlanılamıyor."
	get_tree().network_peer = p
	sunucu = false
	ayriliyor = false
	sunucu_ip = ip.strip_edges()
	ad = _ad_temizle(oyuncu_adi)
	if mesh == null:
		_mesh_ac(V.PORT + 3)
	return ""


func ayril():
	ayriliyor = true
	modem_kapat()
	if get_tree().network_peer != null:
		get_tree().network_peer.close_connection()
	get_tree().network_peer = null
	sunucu = false
	cevrimici = false
	benim_id = 0
	oyuncular = {}
	_yayin = null
	devir = false
	if mesh != null:
		mesh.close()
	mesh = null
	esler = {}
	dogrudan = {}
	rapor = {}
	_benim_durum = null


func _ad_temizle(s: String) -> String:
	s = s.strip_edges()
	if s == "":
		s = "Asker"
	return s.substr(0, 16)


func _dunyayi_sifirla():
	puan = [0, 0]
	saat = 0.0
	tur_sonu = false
	agaclar = []
	for b in 3:
		agaclar.append({"sahip": -1, "can": V.AGAC_CAN, "bitis": 0.0, "ilerleme": [0, 0]})
	araclar = []
	for b in 3:
		for t in 2:
			var u = V.us_yeri(t, b)
			for i in 2:
				var x = u.x + (14.0 if t == 0 else -14.0)
				var z = u.y - 6.0 + i * 12.0
				araclar.append({"konum": Vector3(x, arazi.yukseklik(x, z) + 1.0, z), "donus": Quat(Vector3.UP, PI / 2.0 if t == 0 else -PI / 2.0), "surucu": -1})


func _oyuncu_ekle(id: int, oyuncu_adi: String, kim: String = ""):
	var say = [0, 0]
	for o in oyuncular.values():
		say[o.takim] += 1
	var takim = 0 if say[0] <= say[1] else 1
	oyuncular[id] = {"ad": oyuncu_adi, "takim": takim, "can": 0, "olu": true, "konum": Vector3(), "yaw": 0.0, "pitch": 0.0,
		"silah": 0, "arac": -1, "oldurme": 0, "olum": 0, "dogma": 0.0, "kimlik": kim}


# ---------------------------------------------------------------- bağlantı olayları
func _sunucuya_baglandi():
	benim_id = get_tree().get_network_unique_id()
	rpc_id(1, "katil", ad, V.SURUM, kimlik)


func _baglanilamadi():
	if devir and devir_deneme < 6:
		get_tree().network_peer = null
		get_tree().create_timer(2.0).connect("timeout", self, "_devir_baglan")
		return
	call_deferred("ayril")
	if devir:
		emit_signal("koptu", "Oyunu kuran ayrıldı ve yeni hakeme bağlanılamadı.")
	else:
		emit_signal("baglanamadi")


func _sunucu_gitti():
	if ayriliyor:
		return
	# hakem gitti: hakemlik en küçük numaralı oyuncuya geçer (herkes aynı sonuca varır)
	var eski_benim = benim_id
	var eski = oyuncular.duplicate(true)
	eski.erase(1)
	cevrimici = false
	sunucu = false
	if eski.size() == 0 or not eski.has(eski_benim):
		call_deferred("ayril")
		emit_signal("koptu", "Oyunu kuran oyuncu ayrıldı ya da bağlantı koptu.")
		return
	var ids = eski.keys()
	ids.sort()
	var yeni = ids[0]
	emit_signal("hakem_degisti", "Oyunu kuran ayrıldı. Yeni hakem: %s" % eski[yeni].ad)
	call_deferred("_devir", yeni, eski, eski_benim)


func _devir(yeni, eski, eski_benim):
	get_tree().network_peer = null
	if yeni == eski_benim:
		_devral(eski, eski_benim)
		return
	devir = true
	devir_deneme = 0
	devir_ip = esler[yeni].ip if esler.has(yeni) else sunucu_ip
	get_tree().create_timer(2.0).connect("timeout", self, "_devir_baglan")


func _devir_baglan():
	devir_deneme += 1
	var e = oyuna_katil(devir_ip, ad)
	if e != "":
		_baglanilamadi()


func _devral(eski: Dictionary, eski_benim: int):
	var p = NetworkedMultiplayerENet.new()
	p.compression_mode = NetworkedMultiplayerENet.COMPRESS_RANGE_CODER
	if p.create_server(V.PORT, V.EN_COK_OYUNCU - 1) != OK:
		call_deferred("ayril")
		emit_signal("koptu", "Hakemliği devralamadım: %d numaralı bağlantı noktası kullanımda." % V.PORT)
		return
	get_tree().network_peer = p
	sunucu = true
	cevrimici = true
	benim_id = 1
	bekleyen = {}
	for id in eski:
		if id != eski_benim:
			bekleyen[eski[id].kimlik] = eski[id]
	oyuncular = {1: eski[eski_benim]}
	oyuncular[1].arac = -1
	for a in araclar:
		a.surucu = -1
	esler = {}
	rapor = {}
	_yayin = PacketPeerUDP.new()
	_yayin.set_broadcast_enabled(true)
	_yayin.set_dest_address("255.255.255.255", V.BULMA_PORT)
	emit_signal("devir_tamam")
	_herkese("olay", ["Hakemlik %s'te. Oyun devam ediyor." % ad])
	if modem_izni:
		modem_ac()


func _baglanti_geldi(_id):
	pass


func _baglanti_gitti(id):
	if not sunucu:
		return
	esler.erase(id)
	rapor.erase(id)
	dogrudan.erase(id)
	_esler_degisti = true
	if oyuncular.has(id):
		var a = oyuncular[id].arac
		if a >= 0 and a < araclar.size():
			araclar[a].surucu = -1
			_herkese("arac_durumu", [a, -1, araclar[a].konum, araclar[a].donus])
		var isim = oyuncular[id].ad
		_herkese("oyuncu_gitti", [id])
		_herkese("olay", ["%s oyundan ayrıldı." % isim])


remote func katil(oyuncu_adi, surum, kim = ""):
	if not sunucu:
		return
	var id = _gonderen()
	if surum != V.SURUM:
		rpc_id(id, "reddet", "Sürüm farklı: oyunu kuranın sürümü %s, seninki %s." % [V.SURUM, surum])
		return
	var say = [0, 0]
	for o in oyuncular.values():
		say[o.takim] += 1
	if say[0] >= V.TAKIM_EN_COK and say[1] >= V.TAKIM_EN_COK:
		rpc_id(id, "reddet", "Oyun dolu (20'ye 20).")
		return
	var geri_geldi = kim != "" and bekleyen.has(kim)
	if geri_geldi:
		oyuncular[id] = bekleyen[kim]       # hakem devrinden sonra aynı oyuncu: takımı, canı, puanı korunur
		oyuncular[id].arac = -1
		bekleyen.erase(kim)
	else:
		_oyuncu_ekle(id, _ad_temizle(str(oyuncu_adi)), str(kim))
	rpc_id(id, "kabul", id, oyuncular, puan, agaclar, araclar, saat, mesh_port)
	_herkese("oyuncu_geldi", [id, oyuncular[id]])
	if not geri_geldi:
		_herkese("olay", ["%s, %s'a katıldı." % [oyuncular[id].ad, V.TAKIM_ADI[oyuncular[id].takim]]])


remote func reddet(neden):
	call_deferred("ayril")
	emit_signal("koptu", neden)


remote func kabul(id, o, p, a, ar, s, mport = 0):
	benim_id = id
	oyuncular = o
	puan = p
	agaclar = a
	araclar = ar
	saat = s
	sunucu_mesh_port = mport
	cevrimici = true
	esler = {}
	dogrudan = {}
	if devir:
		devir = false
		emit_signal("devir_tamam")
	else:
		emit_signal("baglandi")


remote func oyuncu_geldi(id, veri):
	oyuncular[id] = veri
	emit_signal("durum_guncellendi")


remote func oyuncu_gitti(id):
	oyuncular.erase(id)
	emit_signal("oyuncu_gitti_sinyal", id)
	emit_signal("durum_guncellendi")


# ---------------------------------------------------------------- yardımcılar
func _herkese(metod: String, args: Array):
	# herkese gönder (sunucu kendisi de işler)
	callv(metod, args)
	callv("rpc", [metod] + args)


func _birine(id: int, metod: String, args: Array):
	if id == benim_id:
		callv(metod, args)
	else:
		callv("rpc_id", [id, metod] + args)


func sunucuya(metod: String, args: Array):
	if not cevrimici:
		return
	if sunucu:
		callv(metod, args)
	else:
		callv("rpc_id", [1, metod] + args)


func hareket_gonder(konum: Vector3, yaw: float, pitch: float, silah: int, arac_veri: Array):
	# hareket eşlere doğrudan gider (_mesh_isle); hakeme sadece kurallar için seyrek gider
	_benim_durum = [konum, yaw, pitch, silah, arac_veri]
	if oyuncular.has(benim_id):
		oyuncular[benim_id].konum = konum
	if not cevrimici:
		return
	if sunucu:
		hareket(konum, yaw, pitch, silah, arac_veri)
	elif OS.get_ticks_msec() * 0.001 - _hakem_gonder > 0.25:
		_hakem_gonder = OS.get_ticks_msec() * 0.001
		rpc_unreliable_id(1, "hareket", konum, yaw, pitch, silah, arac_veri)


func atis_bildir(bas: Vector3, son: Vector3, silah: int, adet: int = 1):
	# atış görüntüsü yakındakilere doğrudan gider; hakem sadece doğrudan bağlanamayanlara aktarır
	if not cevrimici:
		return
	if mesh != null:
		for k in esler:
			if k != benim_id and oyuncular.has(k) and oyuncular[k].konum.distance_to(bas) < 1200.0:
				_mesh_yolla(esler[k].ip, esler[k].port, ["a", benim_id, bas, son, silah, adet])
	if sunucu:
		atis(bas, son, silah, adet)
	else:
		rpc_unreliable_id(1, "atis", bas, son, silah, adet)


# ---------------------------------------------------------------- oyuncudan sunucuya
remote func hareket(konum, yaw, pitch, silah, arac_veri):
	if not sunucu:
		return
	var id = _gonderen()
	if not oyuncular.has(id):
		return
	var o = oyuncular[id]
	if o.olu:
		return
	o.konum = konum
	o.yaw = yaw
	o.pitch = pitch
	o.silah = int(silah)
	if arac_veri.size() == 3:
		var i = int(arac_veri[0])
		if i >= 0 and i < araclar.size() and araclar[i].surucu == id:
			araclar[i].konum = arac_veri[1]
			araclar[i].donus = arac_veri[2]
			o.arac = i


remote func atis(bas, son, silah, adet = 1):
	if not sunucu:
		return
	var id = _gonderen()
	if not oyuncular.has(id) or oyuncular[id].olu:
		return
	var simdi = OS.get_ticks_msec()
	for k in oyuncular.keys():
		if k == id or oyuncular[k].konum.distance_to(bas) >= 1200.0:
			continue
		if k == benim_id:
			if not (dogrudan.has(id) and simdi - dogrudan[id] < 3000):
				emit_signal("atis_goster", bas, son, silah, id, adet)
		elif not (id in rapor.get(k, [])):
			rpc_unreliable_id(k, "atis_al", bas, son, silah, id, adet)


remote func atis_al(bas, son, silah, atan_id, adet = 1):
	emit_signal("atis_goster", bas, son, silah, atan_id, adet)


remote func ates(hedef, hasar, silah = 0):
	if not sunucu or tur_sonu:
		return
	var id = _gonderen()
	if not oyuncular.has(id) or not oyuncular.has(hedef):
		return
	var a = oyuncular[id]
	var h = oyuncular[hedef]
	if a.olu or h.olu or a.takim == h.takim:
		return
	silah = int(clamp(silah, 0, V.SILAHLAR.size() - 1))
	hasar = int(min(hasar, V.SILAHLAR[a.silah].hasar * 2 * 3))   # baş vuruşu x2, toplu atış en çok 3 mermi
	if a.konum.distance_to(h.konum) > V.SILAHLAR[a.silah].menzil + 50.0:
		return
	h.can -= hasar
	var oldu = h.can <= 0
	if oldu:
		_oldur(hedef, id)
	else:
		_herkese("can_degisti", [hedef, h.can, false, id])
	_birine(id, "isabet", [oldu])


func _oldur(id: int, olduren: int):
	var h = oyuncular[id]
	h.can = 0
	h.olu = true
	h.olum += 1
	h.dogma = saat + V.DOGMA_BEKLEME
	if h.arac >= 0 and h.arac < araclar.size() and araclar[h.arac].surucu == id:
		araclar[h.arac].surucu = -1
		_herkese("arac_durumu", [h.arac, -1, araclar[h.arac].konum, araclar[h.arac].donus])
	h.arac = -1
	_herkese("can_degisti", [id, 0, true, olduren])
	if olduren >= 0 and oyuncular.has(olduren):
		var a = oyuncular[olduren]
		a.oldurme += 1
		puan[a.takim] += 3
		_herkese("olay", ["%s  ➜  %s  (%s)" % [a.ad, h.ad, V.SILAHLAR[a.silah].ad]])
	elif olduren == -2:
		_herkese("olay", ["%s zehirli siste kaldı." % h.ad])


remote func isabet(oldurdu):
	emit_signal("isabet_sinyal", oldurdu)


remote func agaca_ates(b, hasar, _silah = 0):
	if not sunucu or tur_sonu:
		return
	var id = _gonderen()
	if not oyuncular.has(id) or b < 0 or b > 2:
		return
	var o = oyuncular[id]
	var a = agaclar[b]
	if o.olu or a.bitis > 0.0 or a.sahip < 0 or a.sahip == o.takim:
		return
	hasar = int(min(hasar, V.SILAHLAR[o.silah].hasar * 3))
	a.can -= hasar
	if saat - _saldiri_uyari[b] > 30.0:
		_saldiri_uyari[b] = saat
		_herkese("olay", ["%s saldırı altında!" % V.AGAC_ADI[b]])
	if a.can <= 0:
		a.can = 0
		a.bitis = saat + V.DUSME_SURESI
		a.sahip = -1
		a.ilerleme = [0, 0]
		puan[o.takim] += 50
		_herkese("olay", ["%s, %s'nı yıktı! %s bölgesi 1 saat kullanılamaz." % [V.TAKIM_ADI[o.takim], V.AGAC_ADI[b], V.BOLGE_ADI[b]]])
		_durum_yayinla()


remote func dog(b, tip):
	if not sunucu:
		return
	var id = _gonderen()
	if not oyuncular.has(id):
		return
	var o = oyuncular[id]
	b = int(b)
	if not o.olu or saat < o.dogma or tur_sonu or b < 0 or b > 2:
		return
	var a = agaclar[b]
	if a.bitis > 0.0:
		return
	if tip == 1 and a.sahip != o.takim:
		return
	var merkez = V.us_yeri(o.takim, b) if tip == 0 else V.AGAC_YERI[b]
	var aci = randf() * TAU
	var uzak = rand_range(6.0, 22.0) if tip == 0 else rand_range(30.0, 50.0)
	var x = merkez.x + cos(aci) * uzak
	var z = merkez.y + sin(aci) * uzak
	var konum = Vector3(x, arazi.yukseklik(x, z) + 0.5, z)
	o.olu = false
	o.can = 100
	o.konum = konum
	o.arac = -1
	_herkese("can_degisti", [id, 100, false, -1])
	_birine(id, "dogdun", [konum])


remote func dogdun(konum):
	emit_signal("dogdun_sinyal", konum)


remote func arac_bin(i):
	if not sunucu:
		return
	var id = _gonderen()
	i = int(i)
	if not oyuncular.has(id) or i < 0 or i >= araclar.size():
		return
	var o = oyuncular[id]
	if o.olu or o.arac >= 0 or araclar[i].surucu != -1:
		return
	if o.konum.distance_to(araclar[i].konum) > 9.0:
		return
	araclar[i].surucu = id
	o.arac = i
	_herkese("arac_durumu", [i, id, araclar[i].konum, araclar[i].donus])


remote func arac_in(i, konum, donus):
	if not sunucu:
		return
	var id = _gonderen()
	i = int(i)
	if i < 0 or i >= araclar.size() or araclar[i].surucu != id:
		return
	araclar[i].surucu = -1
	araclar[i].konum = konum
	araclar[i].donus = donus
	if oyuncular.has(id):
		oyuncular[id].arac = -1
	_herkese("arac_durumu", [i, -1, konum, donus])


# ---------------------------------------------------------------- sunucudan oyunculara
remote func can_degisti(id, can, olu, olduren):
	if test_log:
		print("CAN %d t=%d can=%d olu=%s" % [id, OS.get_ticks_msec(), can, str(olu)])
	if oyuncular.has(id):
		oyuncular[id].can = can
		oyuncular[id].olu = olu
		if olu:
			oyuncular[id].arac = -1
	emit_signal("can_degisti_sinyal", id, can, olu, olduren)


remote func arac_durumu(i, surucu, konum, donus):
	if i < 0 or i >= araclar.size():
		return
	araclar[i].surucu = surucu
	araclar[i].konum = konum
	araclar[i].donus = donus
	emit_signal("arac_degisti", i)


remote func olay(metin):
	emit_signal("olay_sinyal", metin)


remote func durum(p, a, s, o_ozet):
	puan = p
	agaclar = a
	if not sunucu:
		saat = s
		for id in o_ozet.keys():
			if oyuncular.has(id):
				oyuncular[id].oldurme = o_ozet[id][0]
				oyuncular[id].olum = o_ozet[id][1]
				oyuncular[id].dogma = o_ozet[id][2]
	emit_signal("durum_guncellendi")


remote func tur_bitti(kazanan):
	tur_sonu = true
	emit_signal("tur_bitti_sinyal", kazanan)


remote func tur_basladi():
	tur_sonu = false
	emit_signal("tur_basladi_sinyal")


remote func yakindakiler(liste, arac_liste):
	emit_signal("yakindakiler_geldi", liste, arac_liste)


# ---------------------------------------------------------------- sunucu döngüsü
func _process(delta):
	if _dinle != null:
		_bulma_dinle()
	if mesh != null:
		_mesh_isle(delta)
	if not cevrimici:
		return
	saat += delta
	if not sunucu:
		return
	_gonderme -= delta
	if _gonderme <= 0.0:
		_gonderme = 1.0 / 12.0
		_yakindakileri_gonder()
	_saniye += delta
	if _saniye >= 1.0:
		_saniye -= 1.0
		_kurallar()
		_durum_yayinla()
	_yayin_zaman -= delta
	if _yayin_zaman <= 0.0 and _yayin != null:
		_yayin_zaman = 1.0
		var b = to_json({"oyun": "cinarlarin-savasi", "surum": V.SURUM, "ad": ad, "oyuncu": oyuncular.size(), "en_cok": V.EN_COK_OYUNCU})
		_yayin.put_packet(b.to_utf8())


func _yakindakileri_gonder():
	# Hakem sadece birbirine doğrudan bağlanamayan oyuncuların hareketini aktarır.
	var ids = oyuncular.keys()
	var simdi = OS.get_ticks_msec()
	for alici in ids:
		var ao = oyuncular[alici]
		var liste = []
		var dogru = rapor.get(alici, [])
		if alici == benim_id:
			dogru = []
			for k in dogrudan:
				if simdi - dogrudan[k] < 3000:
					dogru.append(k)
		for k in ids:
			if k == alici or k in dogru:
				continue
			var o = oyuncular[k]
			if o.olu:
				continue
			if o.konum.distance_to(ao.konum) < V.YAKIN:
				liste.append([k, o.konum, o.yaw, o.pitch, o.silah, o.arac])
		var al = []
		for i in araclar.size():
			var v = araclar[i]
			if v.surucu != -1 and not (v.surucu in dogru) and v.surucu != alici and v.konum.distance_to(ao.konum) < V.YAKIN:
				al.append([i, v.konum, v.donus, v.surucu])
		if liste.size() == 0 and al.size() == 0:
			continue
		if alici != benim_id:
			aktarilan += liste.size()
		if alici == benim_id:
			emit_signal("yakindakiler_geldi", liste, al)
		else:
			rpc_unreliable_id(alici, "yakindakiler", liste, al)


func _durum_yayinla():
	var ozet = {}
	for id in oyuncular.keys():
		var o = oyuncular[id]
		ozet[id] = [o.oldurme, o.olum, o.dogma]
	_herkese("durum", [puan, agaclar, saat, ozet])


func _kurallar():
	if tur_sonu:
		if saat >= tur_sonu_zaman:
			_yeni_tur()
		return
	_puan_sayac += 1
	for b in 3:
		var a = agaclar[b]
		if a.bitis > 0.0:
			if saat >= a.bitis:
				a.bitis = 0.0
				a.can = V.AGAC_CAN
				a.sahip = -1
				a.ilerleme = [0, 0]
				_herkese("olay", ["%s yeniden yeşerdi! %s bölgesi yeniden açıldı." % [V.AGAC_ADI[b], V.BOLGE_ADI[b]]])
			else:
				for id in oyuncular.keys():
					var o = oyuncular[id]
					if not o.olu and V.bolge(o.konum.z) == b:
						o.can -= 4
						if o.can <= 0:
							_oldur(id, -2)
						else:
							_herkese("can_degisti", [id, o.can, false, -2])
			continue
		var say = [0, 0]
		var yer = V.AGAC_YERI[b]
		for o in oyuncular.values():
			if not o.olu and Vector2(o.konum.x - yer.x, o.konum.z - yer.y).length() < V.ELE_GECIRME_YARICAP:
				say[o.takim] += 1
		for t in 2:
			var diger = 1 - t
			if say[t] > 0 and say[diger] == 0 and a.sahip != t:
				a.ilerleme[t] += 1
				if a.ilerleme[t] >= V.ELE_GECIRME:
					a.sahip = t
					a.can = V.AGAC_CAN if agac_can_test <= 0 else agac_can_test
					a.ilerleme = [0, 0]
					_herkese("olay", ["%s, %s'nı ele geçirdi!" % [V.TAKIM_ADI[t], V.AGAC_ADI[b]]])
			elif say[t] == 0:
				a.ilerleme[t] = max(0, a.ilerleme[t] - 1)
		if a.sahip >= 0 and _puan_sayac % 10 == 0:
			puan[a.sahip] += 2
	for t in 2:
		if puan[t] >= V.KAZANMA_PUANI:
			tur_sonu = true
			tur_sonu_zaman = saat + 15.0
			_herkese("tur_bitti", [t])
			_herkese("olay", ["%s turu kazandı!" % V.TAKIM_ADI[t]])
			break


func _yeni_tur():
	puan = [0, 0]
	for a in agaclar:
		a.sahip = -1
		a.can = V.AGAC_CAN
		a.bitis = 0.0
		a.ilerleme = [0, 0]
	for id in oyuncular.keys():
		var o = oyuncular[id]
		o.oldurme = 0
		o.olum = 0
		if not o.olu:
			o.olu = true
			o.dogma = saat
			if o.arac >= 0 and o.arac < araclar.size():
				araclar[o.arac].surucu = -1
				_herkese("arac_durumu", [o.arac, -1, araclar[o.arac].konum, araclar[o.arac].donus])
			o.arac = -1
			_herkese("can_degisti", [id, 0, true, -3])
		o.dogma = saat
	_herkese("tur_basladi", [])


# ---------------------------------------------------------------- yerel ağda oyun bulma
func bulmayi_baslat():
	bulunan = {}
	_dinle = PacketPeerUDP.new()
	if _dinle.listen(V.BULMA_PORT) != OK:
		_dinle = null


func bulmayi_durdur():
	if _dinle != null:
		_dinle.close()
	_dinle = null


func _bulma_dinle():
	var degisti = false
	while _dinle.get_available_packet_count() > 0:
		var p = _dinle.get_packet().get_string_from_utf8()
		var ip = _dinle.get_packet_ip()
		var d = parse_json(p)
		if typeof(d) == TYPE_DICTIONARY and d.get("oyun", "") == "cinarlarin-savasi":
			bulunan[ip] = {"ip": ip, "ad": str(d.get("ad", "?")), "oyuncu": int(d.get("oyuncu", 0)), "zaman": OS.get_ticks_msec(), "surum": str(d.get("surum", ""))}
			degisti = true
	for ip in bulunan.keys():
		if OS.get_ticks_msec() - bulunan[ip].zaman > 4000:
			bulunan.erase(ip)
			degisti = true
	if degisti:
		emit_signal("oyunlar_bulundu", bulunan.values())


# ---------------------------------------------------------------- eşler arası ağ (herkes sunucunun bir parçası)
func _mesh_ac(ilk_port: int):
	mesh = PacketPeerUDP.new()
	for p in range(ilk_port, ilk_port + 80):
		if mesh.listen(p) == OK:
			mesh_port = p
			return
	mesh = null


func _mesh_yolla(ip: String, port: int, veri: Array):
	if ip == "" or port <= 0:
		return
	mesh.set_dest_address(ip, port)
	mesh.put_packet(var2bytes(veri))


func _mesh_isle(delta):
	var simdi = OS.get_ticks_msec()
	while mesh.get_available_packet_count() > 0:
		var b = mesh.get_packet()
		var ip = mesh.get_packet_ip()
		var port = mesh.get_packet_port()
		if b.size() < 4 or b.size() > 600:
			continue
		var d = bytes2var(b)
		if typeof(d) != TYPE_ARRAY or d.size() < 2 or typeof(d[1]) != TYPE_INT:
			continue
		var id = d[1]
		if id == benim_id or not cevrimici:
			continue
		dogrudan[id] = simdi
		if not esler.has(id) or esler[id].ip != ip or esler[id].port != port:
			esler[id] = {"ip": ip, "port": port}
			if sunucu:
				_esler_degisti = true
		if d[0] == "h" and d.size() == 7:
			_mesh_hareket(id, d)
		elif d[0] == "a" and d.size() == 6:
			var ben = oyuncular.get(benim_id)
			if ben != null and typeof(d[2]) == TYPE_VECTOR3 and ben.konum.distance_to(d[2]) < 1200.0:
				emit_signal("atis_goster", d[2], d[3], int(d[4]), id, int(clamp(d[5], 1, 4)))
	if not cevrimici:
		return
	_mesh_zaman -= delta
	if _mesh_zaman > 0.0:
		return
	_mesh_zaman = 1.0 / 12.0
	_mesh_tik += 1
	var her_saniye = _mesh_tik % 12 == 0
	if not sunucu and her_saniye:
		_mesh_yolla(sunucu_ip, sunucu_mesh_port, ["m", benim_id])      # hakeme "buradayım"
	var ben = oyuncular.get(benim_id)
	var canli = ben != null and not ben.olu and _benim_durum != null
	for id in esler:
		if id == benim_id or (not sunucu and id == 1 and esler[id].ip == ""):
			continue
		var e = esler[id]
		if canli:
			var yakin = oyuncular.has(id) and oyuncular[id].konum.distance_to(ben.konum) < V.YAKIN * 1.2
			if yakin or her_saniye:
				_mesh_yolla(e.ip, e.port, ["h", benim_id] + _benim_durum)
		elif her_saniye:
			_mesh_yolla(e.ip, e.port, ["d", benim_id])                   # delik aç / açık tut
	if not sunucu and _mesh_tik % 24 == 0:
		var liste = []
		for k in dogrudan:
			if simdi - dogrudan[k] < 3000:
				liste.append(k)
		rpc_id(1, "dogrudan_rapor", liste)
	if sunucu and _esler_degisti and her_saniye:
		_esler_degisti = false
		var t = {1: ["", mesh_port]}
		for k in esler:
			t[k] = [esler[k].ip, esler[k].port]
		for k in oyuncular:
			if k != 1:
				rpc_id(k, "esler_tablosu", t)


func _mesh_hareket(id: int, d: Array):
	if not oyuncular.has(id):
		return
	var o = oyuncular[id]
	o.konum = d[2]
	o.yaw = d[3]
	o.pitch = d[4]
	o.silah = int(d[5])
	var av = d[6]
	var aid = -1
	var al = []
	if typeof(av) == TYPE_ARRAY and av.size() == 3:
		aid = int(av[0])
		if aid >= 0 and aid < araclar.size():
			al = [[aid, av[1], av[2], id]]
			if sunucu and araclar[aid].surucu == id:
				araclar[aid].konum = av[1]
				araclar[aid].donus = av[2]
	o.arac = aid
	if o.olu:
		return
	var ben = oyuncular.get(benim_id)
	if ben != null and ben.konum.distance_to(o.konum) < V.YAKIN:
		emit_signal("yakindakiler_geldi", [[id, o.konum, o.yaw, o.pitch, o.silah, aid]], al)


remote func esler_tablosu(t):
	if sunucu:
		return
	var simdi = OS.get_ticks_msec()
	for k in t:
		if k == benim_id:
			continue
		if dogrudan.has(k) and simdi - dogrudan[k] < 3000:
			continue      # zaten doğrudan konuşuyoruz, bildiğimiz adres doğru
		var ip = t[k][0] if t[k][0] != "" else sunucu_ip
		esler[k] = {"ip": ip, "port": int(t[k][1])}
	for k in esler.keys():
		if not t.has(k):
			esler.erase(k)


remote func dogrudan_rapor(liste):
	if sunucu:
		rapor[_gonderen()] = liste


func ag_ozeti() -> String:
	# göstergede: kaç oyuncuyla doğrudan bağlıyız
	var simdi = OS.get_ticks_msec()
	var n = 0
	for k in dogrudan:
		if simdi - dogrudan[k] < 3000:
			n += 1
	return "%d oyuncuyla doğrudan bağlı" % n


# ---------------------------------------------------------------- modem (UPnP)
func modem_ac():
	if upnp != null or (_modem_is_parcacigi != null and _modem_is_parcacigi.is_active()):
		return
	if not ClassDB.class_exists("UPNP"):
		emit_signal("modem_sonuc", false, "Bu sistemde modemle konuşma (UPnP) desteği yok.")
		return
	_modem_is_parcacigi = Thread.new()
	_modem_is_parcacigi.start(self, "_modem_is", [V.PORT, mesh_port])


func _modem_is(portlar):
	var u = UPNP.new()
	if u.discover(2000, 2, "InternetGatewayDevice") != UPNP.UPNP_RESULT_SUCCESS or u.get_gateway() == null or not u.get_gateway().is_valid_gateway():
		call_deferred("_modem_bitti", null, [], "")
		return
	var acilan = []
	for p in portlar:
		if p <= 0:
			continue
		var r = u.add_port_mapping(p, p, "Cinarlarin Savasi", "UDP", 0)
		if r != UPNP.UPNP_RESULT_SUCCESS:
			r = u.add_port_mapping(p, p, "Cinarlarin Savasi", "UDP", 7200)
		if r == UPNP.UPNP_RESULT_SUCCESS:
			acilan.append(p)
	call_deferred("_modem_bitti", u, acilan, u.query_external_address())


func _modem_bitti(u, acilan, dis):
	if _modem_is_parcacigi != null:
		_modem_is_parcacigi.wait_to_finish()
	if u == null or acilan.size() == 0:
		emit_signal("modem_sonuc", false, "Modemde bağlantı noktası açılamadı (modemde UPnP kapalı olabilir). Aynı ağdakiler yine katılabilir; internet için modemden 9880 ve 9882 UDP'yi elle yönlendirmen gerekir.")
		return
	upnp = u
	modem_portlari = acilan
	dis_ip = dis
	if not cevrimici:
		modem_kapat()
		return
	emit_signal("modem_sonuc", true, "Modemde bağlantı noktası açıldı. Arkadaşların internetten bu adresle katılabilir: %s" % dis_ip)


func modem_kapat():
	if upnp != null:
		for p in modem_portlari:
			upnp.delete_port_mapping(p, "UDP")
	upnp = null
	modem_portlari = []
	dis_ip = ""


func _notification(n):
	if n == NOTIFICATION_PREDELETE or n == MainLoop.NOTIFICATION_WM_QUIT_REQUEST:
		modem_kapat()
