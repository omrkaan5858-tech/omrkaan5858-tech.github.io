extends KinematicBody
# Çınarların Savaşı: öteki oyuncuların görüntüsü (ağdan gelen konuma yumuşakça gider)
# Ayrıntılı asker: miğfer, yelek, sırt çantası, eklemli kollar ve bacaklar, elindeki silah.

const V = preload("res://veri.gd")

var id = 0
var takim = 0
var dunya
var hedef_g = Vector3()
var yaw = 0.0
var pitch = 0.0
var ilk = true
var govde: Spatial
var kollar: Spatial
var bacak_sol: Spatial
var bacak_sag: Spatial
var silahlar = []
var adim = 0.0


func kur(oyuncu_id: int, t: int, d):
	id = oyuncu_id
	takim = t
	dunya = d
	collision_layer = 2
	collision_mask = 0
	set_meta("oyuncu_id", id)
	var cs = CollisionShape.new()
	var sh = CapsuleShape.new()
	sh.radius = 0.42
	sh.height = 1.0
	cs.shape = sh
	cs.rotation_degrees = Vector3(90, 0, 0)
	cs.translation = Vector3(0, 0.9, 0)
	add_child(cs)
	var g = d.gorsel
	var k = 10 if d.kalite >= 2 else 7
	var renk = V.TAKIM_RENK[t].darkened(0.35)
	var haki = Color(0.30, 0.32, 0.23)
	var m_takim = g.kumas(renk)
	var m_haki = g.kumas(haki)
	var m_koyu = g.kumas(Color(0.16, 0.17, 0.14))
	govde = Spatial.new()
	add_child(govde)
	# bacaklar (kalçadan döner)
	bacak_sol = _bacak(g, m_haki, m_koyu, k)
	bacak_sol.translation = Vector3(-0.12, 0.92, 0)
	govde.add_child(bacak_sol)
	bacak_sag = _bacak(g, m_haki, m_koyu, k)
	bacak_sag.translation = Vector3(0.12, 0.92, 0)
	govde.add_child(bacak_sag)
	# gövde, yelek, kemer, çanta, baş
	_parca(govde, g.kutu(Vector3(0.40, 0.58, 0.24)), Vector3(0, 1.22, 0), m_takim)
	_parca(govde, g.kutu(Vector3(0.44, 0.40, 0.29)), Vector3(0, 1.26, 0), m_haki)
	for p in [-0.12, 0.0, 0.12]:
		_parca(govde, g.kutu(Vector3(0.09, 0.12, 0.06)), Vector3(p, 1.16, -0.17), m_koyu)
	_parca(govde, g.kutu(Vector3(0.42, 0.06, 0.26)), Vector3(0, 0.95, 0), m_koyu)
	_parca(govde, g.kutu(Vector3(0.34, 0.42, 0.18)), Vector3(0, 1.28, 0.22), m_haki)
	_parca(govde, g.silindir(0.07, 0.07, 0.36, k), Vector3(0, 1.52, 0.22), m_koyu, Vector3(0, 0, PI / 2.0))
	_parca(govde, g.silindir(0.07, 0.08, 0.1, k), Vector3(0, 1.56, 0), g.mat_ten)
	_parca(govde, g.kure(0.12, 0.27, k + 2, k / 2 + 2), Vector3(0, 1.72, 0), g.mat_ten)
	_parca(govde, g.kure(0.155, 0.16, k + 4, k / 2 + 2, true), Vector3(0, 1.76, 0), m_haki)
	_parca(govde, g.silindir(0.158, 0.158, 0.03, k + 4), Vector3(0, 1.76, 0), m_takim)
	_parca(govde, g.kutu(Vector3(0.2, 0.045, 0.03)), Vector3(0, 1.73, -0.11), g.mat_cam)
	# omuz işaretleri (takım rengi)
	var isaret = SpatialMaterial.new()
	isaret.albedo_color = V.TAKIM_RENK[t]
	isaret.emission_enabled = true
	isaret.emission = V.TAKIM_RENK[t]
	isaret.emission_energy = 0.35
	_parca(govde, g.kutu(Vector3(0.05, 0.08, 0.1)), Vector3(-0.235, 1.42, 0), isaret)
	_parca(govde, g.kutu(Vector3(0.05, 0.08, 0.1)), Vector3(0.235, 1.42, 0), isaret)
	# kollar silahı tutar ve nişan yönüne döner
	kollar = Spatial.new()
	kollar.translation = Vector3(0, 1.42, 0)
	govde.add_child(kollar)
	for yan in [-1, 1]:
		var ust = Spatial.new()
		ust.translation = Vector3(0.24 * yan, 0, 0)
		ust.rotation = Vector3(1.1 if yan > 0 else 1.25, 0.35 * yan, 0)
		kollar.add_child(ust)
		_parca(ust, g.silindir(0.06, 0.055, 0.3, k), Vector3(0, -0.15, 0), m_takim)
		var alt = Spatial.new()
		alt.translation = Vector3(0, -0.3, 0)
		alt.rotation = Vector3(0.5 if yan > 0 else 0.35, 0, 0)
		ust.add_child(alt)
		_parca(alt, g.silindir(0.05, 0.045, 0.28, k), Vector3(0, -0.14, 0), m_takim)
		_parca(alt, g.kure(0.05, 0.1, k, k / 2), Vector3(0, -0.3, 0), m_koyu)
	for i in 5:
		var sm = g.silah_modeli(i, false)
		sm.translation = Vector3(0.05, -0.12, -0.38)
		sm.scale = Vector3(1.1, 1.1, 1.1)
		sm.visible = i == 0
		kollar.add_child(sm)
		silahlar.append(sm)


func _parca(ust: Spatial, mesh: Mesh, konum: Vector3, malzeme: Material, don: Vector3 = Vector3()) -> MeshInstance:
	var m = MeshInstance.new()
	m.mesh = mesh
	m.translation = konum
	m.rotation = don
	m.material_override = malzeme
	ust.add_child(m)
	return m


func _bacak(g, m_haki, m_koyu, k) -> Spatial:
	var b = Spatial.new()
	_parca(b, g.silindir(0.095, 0.08, 0.44, k), Vector3(0, -0.22, 0), m_haki)
	_parca(b, g.silindir(0.08, 0.07, 0.42, k), Vector3(0, -0.64, 0), m_haki)
	_parca(b, g.kutu(Vector3(0.14, 0.1, 0.11)), Vector3(0, -0.42, -0.04), m_koyu)
	_parca(b, g.kutu(Vector3(0.13, 0.11, 0.27)), Vector3(0, -0.87, -0.05), m_koyu)
	return b


func hedef(konum_g: Vector3, y: float, p: float, silah: int, arac: int):
	hedef_g = konum_g
	yaw = y
	pitch = p
	visible = arac < 0
	collision_layer = 2 if arac < 0 else 0
	if ilk:
		translation = dunya.yerel(konum_g)
		ilk = false
	for i in silahlar.size():
		silahlar[i].visible = i == clamp(silah, 0, 4)


func _process(delta):
	var h = dunya.yerel(hedef_g)
	var once = translation
	translation = translation.linear_interpolate(h, min(1.0, delta * 12.0))
	if translation.distance_to(h) > 30.0:
		translation = h
	rotation.y = lerp_angle(rotation.y, yaw, min(1.0, delta * 12.0))
	kollar.rotation.x = lerp(kollar.rotation.x, clamp(pitch, -1.2, 1.2), min(1.0, delta * 10.0))
	var hiz = Vector2(translation.x - once.x, translation.z - once.z).length() / max(delta, 0.001)
	adim += delta * min(hiz, 8.0) * 1.6
	var salinim = sin(adim) * min(hiz, 7.0) / 7.0 * 0.6
	bacak_sol.rotation.x = salinim
	bacak_sag.rotation.x = -salinim
	govde.translation.y = abs(sin(adim)) * 0.04 * min(hiz, 7.0) / 7.0
