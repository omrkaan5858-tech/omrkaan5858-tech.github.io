extends Node
# Çınarların Savaşı: ana akış ve arayüz (menü, doğma ekranı, göstergeler, harita, skor tablosu)

const V = preload("res://veri.gd")
const DunyaBetik = preload("res://dunya.gd")
const Gorsel = preload("res://gorsel.gd")

const YAZI_YOLU = "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"
const KALIN_YOLU = "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf"
const AYAR_DOSYASI = "user://ayarlar.cfg"
const YESIL = Color(0.24, 0.48, 0.25)
const KOYU = Color(0.06, 0.12, 0.07)

var dunya = null
var ayar = ConfigFile.new()
var kok: Control
var ekranlar = {}
var yazilar = {}
var yazi_buyuk
var yazi_orta
var yazi_kucuk
var harita_resmi: ImageTexture
var olay_kutusu: VBoxContainer
var hud = {}
var dogma = {}
var katil = {}
var menu = {}
var esc_paneli: Control
var harita_paneli: Control
var harita_cizim: Control
var skor_paneli: Control
var durbun: Control
var tur_yazisi: Label
var orta_yazi: Label
var orta_sure = 0.0
var hasar_sure = 0.0
var isabet_sure = 0.0
var test = {}
var test_sure = 0.0
var durum = "menu"       # menu, katil, yukleme, dogma, oyun
var izin = {}


class Durbun extends Control:
	func _draw():
		var m = rect_size / 2.0
		var r = min(rect_size.x, rect_size.y) * 0.45
		var R = rect_size.length()
		for i in 64:
			var a1 = TAU * i / 64.0
			var a2 = TAU * (i + 1) / 64.0
			var p = PoolVector2Array([m + Vector2(cos(a1), sin(a1)) * r, m + Vector2(cos(a2), sin(a2)) * r,
				m + Vector2(cos(a2), sin(a2)) * R, m + Vector2(cos(a1), sin(a1)) * R])
			draw_colored_polygon(p, Color(0, 0, 0))
		draw_line(Vector2(m.x - r, m.y), Vector2(m.x + r, m.y), Color(0, 0, 0), 2.0)
		draw_line(Vector2(m.x, m.y - r), Vector2(m.x, m.y + r), Color(0, 0, 0), 2.0)
		draw_arc(m, r, 0, TAU, 96, Color(0, 0, 0), 4.0)


class Cizim extends Control:
	var hedef
	var metod
	func _draw():
		hedef.call(metod, self)


# ---------------------------------------------------------------- başlangıç
func _ready():
	randomize()
	_girdileri_kur()
	ayar.load(AYAR_DOSYASI)
	_arayuzu_kur()
	Ag.connect("baglandi", self, "_baglandi")
	Ag.connect("baglanamadi", self, "_baglanamadi")
	Ag.connect("koptu", self, "_koptu")
	Ag.connect("can_degisti_sinyal", self, "_can_degisti")
	Ag.connect("dogdun_sinyal", self, "_dogdun")
	Ag.connect("olay_sinyal", self, "_olay")
	Ag.connect("tur_bitti_sinyal", self, "_tur_bitti")
	Ag.connect("tur_basladi_sinyal", self, "_tur_basladi")
	Ag.connect("oyunlar_bulundu", self, "_oyunlar_bulundu")
	Ag.connect("isabet_sinyal", self, "_isabet")
	Ag.connect("arac_degisti", self, "_arac_degisti")
	Ag.connect("hakem_degisti", self, "_hakem_degisti")
	Ag.connect("devir_tamam", self, "_devir_tamam")
	Ag.connect("modem_sonuc", self, "_modem_sonuc")
	Ag.modem_izni = ayar.get_value("oyun", "modem_izni", false)
	for a in OS.get_cmdline_args():
		if a.begins_with("--cs-"):
			var p = a.substr(5).split("=")
			test[p[0]] = p[1] if p.size() > 1 else ""
	_ekran("menu")
	Ag.test_log = not test.empty()
	if test.has("modem"):
		Ag.modem_izni = true
	if test.has("izin"):
		izin.panel.visible = true
	if test.has("kur"):
		menu.ad.text = test.get("ad", "Test")
		_kur()
		if test.has("agaccan"):
			Ag.agac_can_test = int(test.agaccan)
		if test.has("saat"):
			Ag.saat = float(test.saat)
	elif test.has("katil"):
		menu.ad.text = test.get("ad", "Test2")
		_baglan(test.katil)


func _girdileri_kur():
	var tuslar = {"ileri": KEY_W, "geri": KEY_S, "sol": KEY_A, "sag": KEY_D, "zipla": KEY_SPACE, "kos": KEY_SHIFT,
		"etkiles": KEY_E, "dolum": KEY_R, "fener": KEY_F, "harita": KEY_M, "skor": KEY_TAB, "menu": KEY_ESCAPE,
		"silah1": KEY_1, "silah2": KEY_2, "silah3": KEY_3, "silah4": KEY_4, "silah5": KEY_5}
	for ad in tuslar:
		if not InputMap.has_action(ad):
			InputMap.add_action(ad)
		var e = InputEventKey.new()
		e.physical_scancode = tuslar[ad]     # klavye düzeninden bağımsız (Q ya da F klavye)
		InputMap.action_add_event(ad, e)
	for ad in ["ileri", "geri", "sol", "sag"]:
		var e = InputEventKey.new()
		e.scancode = {"ileri": KEY_UP, "geri": KEY_DOWN, "sol": KEY_LEFT, "sag": KEY_RIGHT}[ad]
		InputMap.action_add_event(ad, e)
	for ad in [["ates", BUTTON_LEFT], ["nisan", BUTTON_RIGHT]]:
		if not InputMap.has_action(ad[0]):
			InputMap.add_action(ad[0])
		var e = InputEventMouseButton.new()
		e.button_index = ad[1]
		InputMap.action_add_event(ad[0], e)


func _yazi(yol: String, boy: int, kenar: int = 0) -> DynamicFont:
	var f = DynamicFont.new()
	var d = DynamicFontData.new()
	d.font_path = yol if File.new().file_exists(yol) else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
	f.font_data = d
	f.size = boy
	if kenar > 0:
		f.outline_size = kenar
		f.outline_color = Color(0, 0, 0, 0.8)
	return f


func _kutu_stili(renk: Color, yaricap: int = 10, kenar: int = 12) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = renk
	s.set_corner_radius_all(yaricap)
	s.content_margin_left = kenar
	s.content_margin_right = kenar
	s.content_margin_top = kenar * 0.6
	s.content_margin_bottom = kenar * 0.6
	return s


# ---------------------------------------------------------------- arayüz kurulumu
func _arayuzu_kur():
	var katman = CanvasLayer.new()
	add_child(katman)
	kok = Control.new()
	kok.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	kok.mouse_filter = Control.MOUSE_FILTER_IGNORE
	katman.add_child(kok)
	var tema = Theme.new()
	tema.default_font = _yazi(YAZI_YOLU, 18)
	yazi_buyuk = _yazi(KALIN_YOLU, 54, 2)
	yazi_orta = _yazi(KALIN_YOLU, 26, 2)
	yazi_kucuk = _yazi(YAZI_YOLU, 16, 1)
	tema.set_stylebox("normal", "Button", _kutu_stili(YESIL))
	tema.set_stylebox("hover", "Button", _kutu_stili(YESIL.lightened(0.15)))
	tema.set_stylebox("pressed", "Button", _kutu_stili(YESIL.darkened(0.2)))
	tema.set_stylebox("disabled", "Button", _kutu_stili(Color(0.3, 0.33, 0.3)))
	tema.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	tema.set_color("font_color", "Button", Color(1, 1, 1))
	tema.set_color("font_color_disabled", "Button", Color(0.65, 0.68, 0.65))
	tema.set_stylebox("panel", "PanelContainer", _kutu_stili(Color(0.05, 0.1, 0.06, 0.88), 14, 18))
	tema.set_stylebox("normal", "LineEdit", _kutu_stili(Color(1, 1, 1, 0.95), 8, 10))
	tema.set_stylebox("focus", "LineEdit", _kutu_stili(Color(1, 1, 1, 1), 8, 10))
	tema.set_color("font_color", "LineEdit", Color(0.1, 0.15, 0.1))
	tema.set_color("font_color", "Label", Color(0.95, 0.97, 0.93))
	kok.theme = tema

	# --- ana menü
	var m = _tam_ekran("menu", KOYU)
	var orta = VBoxContainer.new()
	orta.alignment = BoxContainer.ALIGN_CENTER
	orta.add_constant_override("separation", 14)
	_ortala(m, orta)
	orta.add_child(_etiket("Çınarların Savaşı", yazi_buyuk, Color(0.75, 0.92, 0.6)))
	orta.add_child(_etiket("Üç diyar, üç çınar, iki takım. Bir çınar yıkılırsa bölgesi bir saat düşer.", null, Color(0.75, 0.82, 0.72)))
	orta.add_child(_bosluk(14))
	menu.ad = LineEdit.new()
	menu.ad.placeholder_text = "Adın"
	menu.ad.text = ayar.get_value("oyuncu", "ad", "")
	menu.ad.max_length = 16
	menu.ad.rect_min_size = Vector2(360, 0)
	orta.add_child(menu.ad)
	orta.add_child(_dugme("Oyun kur", "_kur_dugmesi"))
	orta.add_child(_dugme("Oyuna katıl", "_katil_dugmesi"))
	orta.add_child(_dugme("Nasıl oynanır", "_nasil"))
	orta.add_child(_dugme("Çıkış", "_cik"))
	menu.durum = _etiket("", null, Color(1.0, 0.75, 0.6))
	orta.add_child(menu.durum)
	var surum = _etiket("Çınar OS · sürüm " + V.SURUM, yazi_kucuk, Color(0.5, 0.6, 0.5))
	surum.set_anchors_and_margins_preset(Control.PRESET_BOTTOM_RIGHT)
	surum.margin_left = -260
	surum.margin_top = -36
	m.add_child(surum)

	# --- nasıl oynanır
	var n = _tam_ekran("nasil", KOYU)
	var np = PanelContainer.new()
	_ortala(n, np)
	var nv = VBoxContainer.new()
	np.add_child(nv)
	nv.add_child(_etiket("Nasıl oynanır", yazi_orta))
	var metin = Label.new()
	metin.text = """Amaç: 500 puana ilk ulaşan takım turu kazanır.

ÇINARLAR  Her bölgenin dev bir çınarı var (Avrupa, Vaha, Orman).
  • Çınarın yanında 30 saniye düşmansız durursan takımın onu ele geçirir.
  • Ele geçirilen her çınar takımına her 10 saniyede 2 puan kazandırır.
  • Düşman çınarına ateş ederek onu yıkabilirsin (+50 puan).
  • Yıkılan çınarın bölgesi 1 saat zehirli sisle kaplanır: orada can azalır, kimse doğamaz.
  • Her vuruşla öldürme +3 puan.

TUŞLAR
  W A S D: yürü     Shift: koş     Boşluk: zıpla (cipte fren)
  Sol tık: ateş     Sağ tık: nişan     R: şarjör değiştir     1-5 / tekerlek: silah seç
  E: cipe bin / in     F: fener     M: harita     Tab: skor tablosu     Esc: menü

SİLAHLAR (hepsi 88 mermilik şarjör, her silahta 60 yedek şarjör)
  1 Kartal T-88 piyade tüfeği · 2 Atmaca K-88 keskin nişancı · 3 Arı H-88 hafif makineli
  4 Boğa P-88 pompalı · 5 Serçe S-88 tabanca

AĞ  Sunucu herkese bölünmüştür: herkes kendi hareketini yakınındakilere kendisi gönderir,
  oyunu kuran sadece hakemdir (can, çınarlar, puan). Hakem çıkarsa hakemlik başkasına geçer.
  Aynı ev ya da okul ağındaki oyunlar "Oyuna katıl" ekranında kendiliğinden görünür.
  İnternetten oynamak için hakemin modeminde 9880 ve 9882 (UDP) yönlendirilmelidir."""
	nv.add_child(metin)
	nv.add_child(_dugme("Geri", "_menuye"))

	# --- oyuna katıl
	var k = _tam_ekran("katil", KOYU)
	var kp = PanelContainer.new()
	kp.rect_min_size = Vector2(620, 0)
	_ortala(k, kp)
	var kv = VBoxContainer.new()
	kv.add_constant_override("separation", 12)
	kp.add_child(kv)
	kv.add_child(_etiket("Oyuna katıl", yazi_orta))
	kv.add_child(_etiket("Yerel ağda bulunan oyunlar:", null, Color(0.75, 0.85, 0.72)))
	katil.liste = VBoxContainer.new()
	kv.add_child(katil.liste)
	katil.bos = _etiket("Aranıyor... (aynı ağda kurulmuş oyun yoksa burası boş kalır)", yazi_kucuk, Color(0.65, 0.7, 0.62))
	katil.liste.add_child(katil.bos)
	kv.add_child(_bosluk(8))
	kv.add_child(_etiket("Ya da oyunu kuranın IP adresini yaz:", null, Color(0.75, 0.85, 0.72)))
	var ks = HBoxContainer.new()
	katil.ip = LineEdit.new()
	katil.ip.text = ayar.get_value("oyuncu", "ip", "")
	katil.ip.placeholder_text = "ör. 192.168.1.20"
	katil.ip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ks.add_child(katil.ip)
	ks.add_child(_dugme("Bağlan", "_ip_baglan"))
	kv.add_child(ks)
	katil.durum = _etiket("", null, Color(1.0, 0.8, 0.6))
	kv.add_child(katil.durum)
	kv.add_child(_dugme("Geri", "_menuye"))

	# --- yükleme
	var y = _tam_ekran("yukleme", KOYU)
	yazilar.yukleme = _etiket("Dünya hazırlanıyor...", yazi_orta)
	_ortala(y, yazilar.yukleme)

	# --- doğma ekranı
	var d = Control.new()
	d.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	d.mouse_filter = Control.MOUSE_FILTER_IGNORE
	kok.add_child(d)
	ekranlar["dogma"] = d
	var dp = PanelContainer.new()
	dp.rect_position = Vector2(30, 30)
	dp.rect_min_size = Vector2(430, 0)
	d.add_child(dp)
	var dv = VBoxContainer.new()
	dv.add_constant_override("separation", 10)
	dp.add_child(dv)
	dogma.takim = _etiket("", yazi_orta)
	dv.add_child(dogma.takim)
	dogma.bilgi = _etiket("Doğacağın yeri seç:", null, Color(0.8, 0.88, 0.78))
	dv.add_child(dogma.bilgi)
	dogma.dugmeler = []
	dogma.durumlar = []
	for b in 3:
		dv.add_child(_bosluk(4))
		var baslik = _etiket(V.BOLGE_ADI[b], null, Color(0.9, 0.95, 0.85))
		dv.add_child(baslik)
		var sd = _etiket("", yazi_kucuk, Color(0.75, 0.8, 0.72))
		dv.add_child(sd)
		dogma.durumlar.append(sd)
		var hs = HBoxContainer.new()
		var u = _dugme("Üste doğ", "_dog", [b, 0])
		var c = _dugme("Çınarda doğ", "_dog", [b, 1])
		u.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hs.add_child(u)
		hs.add_child(c)
		dv.add_child(hs)
		dogma.dugmeler.append([u, c])
		var izle = _dugme("İzle", "_izle", [b])
		izle.visible = false
	dv.add_child(_bosluk(6))
	dogma.sure = _etiket("", yazi_orta, Color(1.0, 0.85, 0.5))
	dv.add_child(dogma.sure)
	dv.add_child(_dugme("Harita (M)", "_harita_ac"))

	# --- oyun göstergeleri
	var h = Control.new()
	h.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	kok.add_child(h)
	ekranlar["oyun"] = h
	durbun = Durbun.new()
	durbun.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	durbun.mouse_filter = Control.MOUSE_FILTER_IGNORE
	durbun.visible = false
	h.add_child(durbun)
	hud.hasar = ColorRect.new()
	hud.hasar.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	hud.hasar.color = Color(0.8, 0.0, 0.0, 0.0)
	hud.hasar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(hud.hasar)
	hud.nisangah = _etiket("+", yazi_orta)
	hud.nisangah.set_anchors_and_margins_preset(Control.PRESET_CENTER)
	hud.nisangah.margin_left = -10
	hud.nisangah.margin_top = -20
	h.add_child(hud.nisangah)
	hud.isabet = _etiket("✕", yazi_orta, Color(1, 0.3, 0.3))
	hud.isabet.set_anchors_and_margins_preset(Control.PRESET_CENTER)
	hud.isabet.margin_left = -11
	hud.isabet.margin_top = -20
	hud.isabet.visible = false
	h.add_child(hud.isabet)
	hud.konum = _etiket("", yazi_kucuk)
	hud.konum.rect_position = Vector2(16, 12)
	h.add_child(hud.konum)
	hud.puan = _etiket("", yazi_orta)
	hud.puan.set_anchors_and_margins_preset(Control.PRESET_CENTER_TOP)
	hud.puan.margin_left = -200
	hud.puan.margin_right = 200
	hud.puan.margin_top = 10
	hud.puan.align = Label.ALIGN_CENTER
	h.add_child(hud.puan)
	hud.agaclar = _etiket("", yazi_kucuk)
	hud.agaclar.set_anchors_and_margins_preset(Control.PRESET_TOP_RIGHT)
	hud.agaclar.margin_left = -360
	hud.agaclar.margin_top = 12
	h.add_child(hud.agaclar)
	hud.can = ProgressBar.new()
	hud.can.max_value = 100
	hud.can.percent_visible = false
	hud.can.add_stylebox_override("fg", _kutu_stili(Color(0.3, 0.8, 0.35), 6, 0))
	hud.can.add_stylebox_override("bg", _kutu_stili(Color(0, 0, 0, 0.5), 6, 0))
	hud.can.set_anchors_and_margins_preset(Control.PRESET_BOTTOM_LEFT)
	hud.can.margin_left = 20
	hud.can.margin_right = 300
	hud.can.margin_top = -44
	hud.can.margin_bottom = -24
	h.add_child(hud.can)
	hud.can_yazi = _etiket("", yazi_kucuk)
	hud.can_yazi.set_anchors_and_margins_preset(Control.PRESET_BOTTOM_LEFT)
	hud.can_yazi.margin_left = 22
	hud.can_yazi.margin_top = -72
	h.add_child(hud.can_yazi)
	hud.mermi = _etiket("", yazi_orta)
	hud.mermi.set_anchors_and_margins_preset(Control.PRESET_BOTTOM_RIGHT)
	hud.mermi.margin_left = -640
	hud.mermi.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	hud.mermi.margin_right = -20
	hud.mermi.margin_top = -84
	hud.mermi.align = Label.ALIGN_RIGHT
	h.add_child(hud.mermi)
	hud.ipucu = _etiket("", yazi_kucuk, Color(1, 0.95, 0.7))
	hud.ipucu.set_anchors_and_margins_preset(Control.PRESET_CENTER_BOTTOM)
	hud.ipucu.margin_left = -300
	hud.ipucu.margin_right = 300
	hud.ipucu.margin_top = -130
	hud.ipucu.align = Label.ALIGN_CENTER
	h.add_child(hud.ipucu)
	hud.uyari = _etiket("", yazi_orta, Color(0.75, 1.0, 0.45))
	hud.uyari.set_anchors_and_margins_preset(Control.PRESET_CENTER_TOP)
	hud.uyari.margin_left = -400
	hud.uyari.margin_right = 400
	hud.uyari.margin_top = 120
	hud.uyari.align = Label.ALIGN_CENTER
	h.add_child(hud.uyari)

	# --- her ekranda görünenler
	olay_kutusu = VBoxContainer.new()
	olay_kutusu.set_anchors_and_margins_preset(Control.PRESET_TOP_RIGHT)
	olay_kutusu.margin_left = -520
	olay_kutusu.margin_right = -16
	olay_kutusu.margin_top = 120
	olay_kutusu.mouse_filter = Control.MOUSE_FILTER_IGNORE
	kok.add_child(olay_kutusu)
	orta_yazi = _etiket("", yazi_buyuk)
	orta_yazi.set_anchors_and_margins_preset(Control.PRESET_CENTER)
	orta_yazi.margin_left = -600
	orta_yazi.margin_right = 600
	orta_yazi.margin_top = -160
	orta_yazi.align = Label.ALIGN_CENTER
	orta_yazi.autowrap = true
	kok.add_child(orta_yazi)

	# --- harita
	harita_paneli = PanelContainer.new()
	harita_paneli.visible = false
	_ortala(kok, harita_paneli)
	var hv = VBoxContainer.new()
	harita_paneli.add_child(hv)
	hv.add_child(_etiket("Dünya haritası (M: kapat)", null))
	harita_cizim = Cizim.new()
	harita_cizim.hedef = self
	harita_cizim.metod = "_harita_ciz"
	harita_cizim.rect_min_size = Vector2(250, 625)
	hv.add_child(harita_cizim)

	# --- skor tablosu
	skor_paneli = PanelContainer.new()
	skor_paneli.visible = false
	_ortala(kok, skor_paneli)
	yazilar.skor = Label.new()
	skor_paneli.add_child(yazilar.skor)

	# --- tur sonu
	tur_yazisi = _etiket("", yazi_buyuk, Color(1, 0.9, 0.5))
	tur_yazisi.set_anchors_and_margins_preset(Control.PRESET_CENTER)
	tur_yazisi.margin_left = -600
	tur_yazisi.margin_right = 600
	tur_yazisi.margin_top = 40
	tur_yazisi.align = Label.ALIGN_CENTER
	kok.add_child(tur_yazisi)

	# --- modem izni (ilk açılışta bir kez sorulur)
	izin.panel = ColorRect.new()
	izin.panel.color = Color(0, 0, 0, 0.75)
	izin.panel.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	izin.panel.visible = false
	kok.add_child(izin.panel)
	var ip_ = PanelContainer.new()
	ip_.add_stylebox_override("panel", _kutu_stili(Color(0.07, 0.15, 0.08), 14, 22))
	ip_.rect_min_size = Vector2(640, 0)
	_ortala(izin.panel, ip_)
	var iv = VBoxContainer.new()
	iv.add_constant_override("separation", 12)
	ip_.add_child(iv)
	iv.add_child(_etiket("İnternetten oynamak için izin", yazi_orta))
	var it = Label.new()
	it.autowrap = true
	it.rect_min_size = Vector2(600, 0)
	it.text = "Arkadaşların internetten senin oyununa katılabilsin diye, sen hakem olduğunda modeminde Çınarların Savaşı için iki bağlantı noktası (9880 ve 9882, UDP) açayım mı?\n\n• Sadece sen oyunu kurduğunda ya da hakemlik sana geçtiğinde açılır, oyun kapanınca kapatılır.\n• Aynı ev ya da okul ağında oynamak için buna gerek yok.\n• Kararını sonra Esc menüsünden değiştirebilirsin."
	iv.add_child(it)
	var ih = HBoxContainer.new()
	var e1 = _dugme("Evet, aç", "_izin_ver", [true])
	var e2 = _dugme("Hayır", "_izin_ver", [false])
	e1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	e2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ih.add_child(e1)
	ih.add_child(e2)
	iv.add_child(ih)

	# --- Esc menüsü
	esc_paneli = PanelContainer.new()
	esc_paneli.visible = false
	_ortala(kok, esc_paneli)
	var ev = VBoxContainer.new()
	ev.add_constant_override("separation", 10)
	esc_paneli.add_child(ev)
	ev.add_child(_etiket("Duraklat", yazi_orta))
	ev.add_child(_dugme("Devam", "_esc_kapat"))
	ev.add_child(_etiket("Fare hassasiyeti", yazi_kucuk))
	var hs = HSlider.new()
	hs.min_value = 0.03
	hs.max_value = 0.4
	hs.step = 0.01
	hs.value = ayar.get_value("oyun", "hassasiyet", 0.12)
	hs.rect_min_size = Vector2(320, 24)
	hs.connect("value_changed", self, "_hassasiyet")
	ev.add_child(hs)
	ev.add_child(_etiket("Görüş mesafesi", yazi_kucuk))
	var go = OptionButton.new()
	for g in ["Yakın (zayıf bilgisayar)", "Orta", "Uzak"]:
		go.add_item(g)
	go.selected = [5, 7, 9].find(ayar.get_value("oyun", "gorus", 7))
	go.connect("item_selected", self, "_gorus")
	ev.add_child(go)
	ev.add_child(_etiket("Grafik kalitesi (sonraki oyunda tam geçerli olur)", yazi_kucuk))
	var gk = OptionButton.new()
	for g in Gorsel.KALITE_ADI:
		gk.add_item(g)
	gk.selected = int(ayar.get_value("oyun", "grafik", Gorsel.otomatik_kalite()))
	gk.connect("item_selected", self, "_grafik")
	ev.add_child(gk)
	izin.kutu = CheckBox.new()
	izin.kutu.text = "Hakem olunca modemde bağlantı noktası aç (internet oyunu)"
	izin.kutu.pressed = ayar.get_value("oyun", "modem_izni", false)
	izin.kutu.connect("toggled", self, "_modem_izni_degisti")
	ev.add_child(izin.kutu)
	ev.add_child(_dugme("Ana menüye dön", "_ana_menuye"))
	ev.add_child(_dugme("Oyundan çık", "_cik"))


func _ortala(ust: Control, c: Control):
	var cc = CenterContainer.new()
	cc.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ust.add_child(cc)
	cc.add_child(c)


func _tam_ekran(ad: String, renk: Color) -> Control:
	var c = ColorRect.new()
	c.color = renk
	c.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	kok.add_child(c)
	ekranlar[ad] = c
	return c


func _etiket(m: String, yazi = null, renk: Color = Color(0.95, 0.97, 0.93)) -> Label:
	var l = Label.new()
	l.text = m
	if yazi != null:
		l.add_font_override("font", yazi)
	l.add_color_override("font_color", renk)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _dugme(m: String, metod: String, args: Array = []) -> Button:
	var b = Button.new()
	b.text = m
	b.rect_min_size = Vector2(0, 44)
	b.connect("pressed", self, metod, args)
	return b


func _bosluk(y: int) -> Control:
	var c = Control.new()
	c.rect_min_size = Vector2(0, y)
	return c


func _ekran(ad: String):
	durum = ad
	for k in ekranlar:
		ekranlar[k].visible = k == ad
	if ad == "oyun":
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	else:
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


# ---------------------------------------------------------------- menü işlemleri
func _ad_kaydet():
	ayar.set_value("oyuncu", "ad", menu.ad.text)
	ayar.save(AYAR_DOSYASI)


func _izin_sor(sonra: String):
	# ilk kez: modemde bağlantı noktası açmak için izin iste
	if ayar.has_section_key("oyun", "modem_izni") or test.size() > 0:
		call(sonra)
		return
	izin.sonra = sonra
	izin.panel.visible = true


func _izin_ver(evet: bool):
	ayar.set_value("oyun", "modem_izni", evet)
	ayar.save(AYAR_DOSYASI)
	Ag.modem_izni = evet
	izin.kutu.pressed = evet
	izin.panel.visible = false
	call(izin.sonra)


func _modem_izni_degisti(evet: bool):
	ayar.set_value("oyun", "modem_izni", evet)
	ayar.save(AYAR_DOSYASI)
	Ag.modem_izni = evet
	if evet and Ag.sunucu:
		Ag.modem_ac()
	elif not evet:
		Ag.modem_kapat()


func _modem_sonuc(_basarili, metin):
	_olay(metin)


func _kur_dugmesi():
	_izin_sor("_kur")


func _katil_dugmesi():
	_izin_sor("_katil_ekrani")


func _kur():
	_ad_kaydet()
	var e = Ag.oyun_kur(menu.ad.text)
	if e != "":
		menu.durum.text = e
		return
	_oyuna_gir()


func _katil_ekrani():
	_ad_kaydet()
	katil.durum.text = ""
	Ag.bulmayi_baslat()
	_ekran("katil")


func _oyunlar_bulundu(liste):
	for c in katil.liste.get_children():
		if c != katil.bos:
			c.queue_free()
	katil.bos.visible = liste.size() == 0
	for o in liste:
		var b = _dugme("Kuran: %s  ·  %d/%d oyuncu  ·  %s" % [o.ad, o.oyuncu, V.EN_COK_OYUNCU, o.ip], "_baglan", [o.ip])
		katil.liste.add_child(b)


func _ip_baglan():
	_baglan(katil.ip.text)


func _baglan(ip: String):
	if ip.strip_edges() == "":
		katil.durum.text = "Bir IP adresi yaz."
		return
	ayar.set_value("oyuncu", "ip", ip)
	ayar.save(AYAR_DOSYASI)
	var e = Ag.oyuna_katil(ip, menu.ad.text)
	if e != "":
		katil.durum.text = e
		return
	katil.durum.text = "Bağlanıyor: %s ..." % ip
	if durum != "katil":
		_ekran("katil")


func _baglandi():
	Ag.bulmayi_durdur()
	_oyuna_gir()


func _baglanamadi():
	katil.durum.text = "Bağlanılamadı. Adresi ve oyunun kurulu olduğunu kontrol et."


func _koptu(neden):
	_dunyayi_kapat()
	_ekran("menu")
	menu.durum.text = neden


func _nasil():
	_ekran("nasil")


func _menuye():
	Ag.bulmayi_durdur()
	_ekran("menu")


func _cik():
	get_tree().quit()


func _ana_menuye():
	esc_paneli.visible = false
	Ag.ayril()
	_dunyayi_kapat()
	_ekran("menu")


func _dunyayi_kapat():
	if dunya != null:
		dunya.queue_free()
		dunya = null
	harita_paneli.visible = false
	skor_paneli.visible = false
	tur_yazisi.text = ""


func _hassasiyet(v):
	ayar.set_value("oyun", "hassasiyet", v)
	ayar.save(AYAR_DOSYASI)
	if dunya != null and dunya.oyuncu != null:
		dunya.oyuncu.hassasiyet = v


func _gorus(i):
	var g = [5, 7, 9][i]
	ayar.set_value("oyun", "gorus", g)
	ayar.save(AYAR_DOSYASI)
	if dunya != null:
		dunya.gorus = g
		dunya.son_parca = Vector2(1e9, 1e9)


func _grafik(i):
	ayar.set_value("oyun", "grafik", i)
	ayar.save(AYAR_DOSYASI)
	_ekran_ayari(i)


func _ekran_ayari(k: int):
	var a = Gorsel.ayar_al(k)
	get_viewport().msaa = a.msaa
	get_viewport().fxaa = a.fxaa


# ---------------------------------------------------------------- oyuna giriş, doğma
func _oyuna_gir():
	_ekran("yukleme")
	yazilar.yukleme.text = "Dünya hazırlanıyor..."
	yield(get_tree(), "idle_frame")
	yield(get_tree(), "idle_frame")
	if harita_resmi == null:
		_harita_uret()
	dunya = DunyaBetik.new()
	dunya.kalite = int(ayar.get_value("oyun", "grafik", Gorsel.otomatik_kalite()))
	if test.has("kalite"):
		dunya.kalite = int(test.kalite)
	_ekran_ayari(dunya.kalite)
	dunya.gorus = int(ayar.get_value("oyun", "gorus", 7))
	if test.has("gorus"):
		dunya.gorus = int(test.gorus)
	add_child(dunya)
	move_child(dunya, 0)
	var b = 0 if not test.has("bolge") else int(test.bolge)
	dunya.seyirci_bolgesi(b)
	_dogma_ekrani()
	if (test.has("kur") or test.has("katil")) and not test.has("seyir"):
		yield(get_tree().create_timer(1.0), "timeout")
		Ag.sunucuya("dog", [int(test.get("bolge", "0")), int(test.get("tip", "0"))])


func _dogma_ekrani():
	_ekran("dogma")
	_dogma_guncelle()


func _dog(b: int, tip: int):
	Ag.sunucuya("dog", [b, tip])


func _izle(b: int):
	if dunya != null:
		dunya.seyirci_bolgesi(b)


func _dogdun(konum):
	if dunya == null:
		return
	_ekran("yukleme")
	yazilar.yukleme.text = "Doğuyorsun..."
	yield(get_tree(), "idle_frame")
	dunya.dogmaya_hazirla(konum)
	var bas = OS.get_ticks_msec()
	while dunya != null and not dunya.cevre_hazir(konum) and OS.get_ticks_msec() - bas < 30000:
		yield(get_tree(), "idle_frame")
	if dunya == null:
		return
	dunya.oyuncu_dogur(konum)
	dunya.oyuncu.hassasiyet = ayar.get_value("oyun", "hassasiyet", 0.12)
	_ekran("oyun")
	test_sure = 0.0


func _can_degisti(id, _can, olu, olduren):
	if id != Ag.benim_id or dunya == null:
		return
	if not olu:
		if _can < 100 and durum == "oyun":
			hasar_sure = 0.35
		return
	dunya.oyuncu_oldu()
	if olduren >= 0 and Ag.oyuncular.has(olduren):
		_orta("%s seni vurdu" % Ag.oyuncular[olduren].ad, 3.0)
	elif olduren == -2:
		_orta("Zehirli sis seni öldürdü", 3.0)
	_dogma_ekrani()


func _hakem_degisti(metin):
	_orta(metin, 4.0)
	if dunya != null and dunya.oyuncu != null and dunya.oyuncu.arac != null:
		dunya.oyuncu._aractan_in()


func _devir_tamam():
	_orta("Oyun devam ediyor", 2.0)
	if dunya != null:
		for id in dunya.kuklalar.keys():
			dunya._kukla_sil(id)
	print("DEVIR tamam, benim_id=", Ag.benim_id, " sunucu=", Ag.sunucu)


func _isabet(oldurdu):
	isabet_sure = 0.25 if not oldurdu else 0.6


func _arac_degisti(i):
	if dunya == null or dunya.oyuncu == null:
		return
	var v = Ag.araclar[i]
	if v.surucu == Ag.benim_id and dunya.oyuncu.arac == null and dunya.oyuncu.aktif:
		dunya.oyuncu.araca_bindir(dunya.araclar[i])


func _olay(metin):
	print("OLAY ", metin)
	var l = _etiket(metin, yazi_kucuk)
	l.align = Label.ALIGN_RIGHT
	olay_kutusu.add_child(l)
	while olay_kutusu.get_child_count() > 7:
		olay_kutusu.get_child(0).queue_free()
		olay_kutusu.remove_child(olay_kutusu.get_child(0))
	get_tree().create_timer(8.0).connect("timeout", l, "queue_free")
	if "yıktı" in metin or "yeşerdi" in metin:
		_orta(metin, 5.0)


func _orta(m: String, sure: float):
	orta_yazi.text = m
	orta_sure = sure


func _tur_bitti(kazanan):
	tur_yazisi.text = "%s turu kazandı!\nYeni tur 15 saniye sonra başlıyor." % V.TAKIM_ADI[kazanan]
	tur_yazisi.add_color_override("font_color", V.TAKIM_RENK[kazanan].lightened(0.3))


func _tur_basladi():
	tur_yazisi.text = ""
	_orta("Yeni tur başladı!", 3.0)


# ---------------------------------------------------------------- her kare
func _unhandled_input(ev):
	if ev.is_action_pressed("menu"):
		if durum in ["oyun", "dogma"]:
			if esc_paneli.visible:
				_esc_kapat()
			else:
				esc_paneli.visible = true
				Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
		elif durum == "nasil" or durum == "katil":
			_menuye()
	elif ev.is_action_pressed("harita") and durum in ["oyun", "dogma"]:
		_harita_ac()
	elif ev.is_action_pressed("skor") and durum in ["oyun", "dogma"]:
		skor_paneli.visible = true
	elif ev.is_action_released("skor"):
		skor_paneli.visible = false


func _esc_kapat():
	esc_paneli.visible = false
	if durum == "oyun":
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _harita_ac():
	harita_paneli.visible = not harita_paneli.visible
	var y = get_viewport().size.y - 150.0
	harita_cizim.rect_min_size = Vector2(y * 0.4, y)


func _process(delta):
	orta_sure -= delta
	orta_yazi.visible = orta_sure > 0.0
	if test.has("ekran"):
		if durum != test.ekran:
			_ekran(test.ekran)
			if test.ekran == "katil":
				Ag.bulmayi_baslat()
		test_sure += delta
		_test_foto()
	if dunya == null:
		return
	if durum == "dogma":
		_dogma_guncelle()
	if durum == "oyun":
		_hud_guncelle(delta)
	if skor_paneli.visible:
		_skor_guncelle()
	if harita_paneli.visible:
		harita_cizim.update()
	_test_isle(delta)


func _dogma_guncelle():
	if not Ag.oyuncular.has(Ag.benim_id):
		return
	var o = Ag.oyuncular[Ag.benim_id]
	dogma.takim.text = V.TAKIM_ADI[o.takim]
	dogma.takim.add_color_override("font_color", V.TAKIM_RENK[o.takim].lightened(0.2))
	var kalan = o.dogma - Ag.saat
	for b in 3:
		var a = Ag.agaclar[b]
		var t = ""
		if a.bitis > 0.0:
			t = "Bölge düştü! %d dk sonra açılır." % int(ceil((a.bitis - Ag.saat) / 60.0))
		elif a.sahip >= 0:
			t = "%s: %s'nın  ·  can %d/%d" % [V.AGAC_ADI[b], V.TAKIM_KISA[a.sahip] + " Takım", a.can, V.AGAC_CAN]
		else:
			t = "%s: kimsenin değil" % V.AGAC_ADI[b]
		dogma.durumlar[b].text = t
		var acik = a.bitis <= 0.0 and kalan <= 0.0 and not Ag.tur_sonu
		dogma.dugmeler[b][0].disabled = not acik
		dogma.dugmeler[b][1].disabled = not (acik and a.sahip == o.takim)
	dogma.sure.text = ("Doğmak için %d sn" % int(ceil(kalan))) if kalan > 0.0 else ""


func _hud_guncelle(delta):
	var p = dunya.oyuncu
	if p == null or not Ag.oyuncular.has(Ag.benim_id):
		return
	var o = Ag.oyuncular[Ag.benim_id]
	var g = dunya.odak()
	var b = V.bolge(g.z)
	var yer = dunya.arazi.yerlesim_adi(g.x, g.z)
	hud.konum.text = "%s%s\n%.1f km D  ·  %.1f km G\n%s  ·  %s\n%s%s" % [V.BOLGE_ADI[b], ("  ·  " + yer) if yer != "" else "",
		g.x / 1000.0, g.z / 1000.0, V.saat_metni(Ag.saat), V.HAVA_ADI[V.hava(b, Ag.saat)],
		"Hakem sensin  ·  " if Ag.sunucu else "", Ag.ag_ozeti()]
	hud.puan.text = "%s  %d   —   %d  %s" % [V.TAKIM_KISA[0], Ag.puan[0], Ag.puan[1], V.TAKIM_KISA[1]]
	var at = ""
	for i in 3:
		var a = Ag.agaclar[i]
		if a.bitis > 0.0:
			at += "%s: DÜŞTÜ (%d dk)\n" % [V.AGAC_ADI[i], int(ceil((a.bitis - Ag.saat) / 60.0))]
		elif a.sahip >= 0:
			at += "%s: %s  %d%%\n" % [V.AGAC_ADI[i], V.TAKIM_KISA[a.sahip], int(100.0 * a.can / V.AGAC_CAN)]
		else:
			var il = max(a.ilerleme[0], a.ilerleme[1])
			at += "%s: boş%s\n" % [V.AGAC_ADI[i], ("  (ele geçiriliyor %d/%d)" % [il, V.ELE_GECIRME]) if il > 0 else ""]
	hud.agaclar.text = at
	hud.can.value = o.can
	hud.can_yazi.text = "Can %d  ·  %s" % [o.can, V.TAKIM_ADI[o.takim]]
	var w = V.SILAHLAR[p.silah]
	if p.dolduruluyor > 0.0:
		hud.mermi.text = "%s\nŞarjör değiştiriliyor..." % w.ad
	else:
		hud.mermi.text = "%s  ·  %s\n%d / 88   ·   %d şarjör" % [w.ad, w.tur, p.mermi[p.silah], p.yedek[p.silah]]
	var ipucu = ""
	if p.arac != null:
		ipucu = "W/S: gaz/geri · A/D: direksiyon · Boşluk: fren · E: in"
	elif dunya.en_yakin_arac(p.translation, 4.5) != null:
		ipucu = "E: cipe bin"
	elif p.mermi[p.silah] == 0 and p.yedek[p.silah] > 0 and p.dolduruluyor <= 0.0:
		ipucu = "R: şarjör değiştir"
	var dustu = Ag.agaclar[b].bitis > 0.0
	hud.uyari.text = ("Bu bölge düştü! Zehirli sis canını azaltıyor, bölgeden çık!" if dustu else "")
	hud.ipucu.text = ipucu
	durbun.visible = p.nisan and p.silah == 1 and p.arac == null
	hud.nisangah.visible = not durbun.visible and p.arac == null
	hasar_sure -= delta
	hud.hasar.color.a = max(0.0, hasar_sure) * 0.9 + (0.15 if dustu else 0.0)
	hud.hasar.color = Color(0.8, 0.0, 0.0, hud.hasar.color.a) if not dustu else Color(0.3, 0.6, 0.1, hud.hasar.color.a)
	isabet_sure -= delta
	hud.isabet.visible = isabet_sure > 0.0


func _skor_guncelle():
	var satirlar = ["%-18s %8s %8s" % ["", "Öldürme", "Ölüm"]]
	if Ag.sunucu and Ag.dis_ip != "":
		satirlar.insert(0, "İnternetten katılma adresi: %s\n" % Ag.dis_ip)
	for t in 2:
		satirlar.append("")
		satirlar.append("%s  (%d puan)" % [V.TAKIM_ADI[t], Ag.puan[t]])
		for id in Ag.oyuncular:
			var o = Ag.oyuncular[id]
			if o.takim == t:
				satirlar.append("  %-16s %8d %8d%s" % [o.ad, o.oldurme, o.olum, "  ← sen" if id == Ag.benim_id else ""])
	yazilar.skor.text = PoolStringArray(satirlar).join("\n")


# ---------------------------------------------------------------- harita
func _harita_uret():
	var yol = "user://harita-%s.png" % V.SURUM
	var img = Image.new()
	if File.new().file_exists(yol) and img.load(yol) == OK:
		harita_resmi = ImageTexture.new()
		harita_resmi.create_from_image(img)
		return
	yazilar.yukleme.text = "Dünya haritası çiziliyor (ilk açılışta bir kez)..."
	var a = Ag.arazi
	var en = 100
	var boy = 250
	img.create(en, boy, false, Image.FORMAT_RGB8)
	img.lock()
	for j in boy:
		for i in en:
			var x = (i + 0.5) * 1000.0
			var z = (j + 0.5) * 1000.0
			var h = a.ham_yukseklik(x, z)
			var c
			if h <= 0.3:
				c = Color(0.16, 0.36, 0.55).darkened(clamp(-h / 60.0, 0.0, 0.4))
			else:
				c = a.renk(x, z, h, 0.0).darkened(0.1)
				c = c.lightened(clamp(h / 1600.0, 0.0, 0.35))
			img.set_pixel(i, j, c)
	img.unlock()
	img.save_png(yol)
	harita_resmi = ImageTexture.new()
	harita_resmi.create_from_image(img)


func _harita_ciz(c: Control):
	var boy = c.rect_size
	if harita_resmi == null:
		return
	c.draw_texture_rect(harita_resmi, Rect2(Vector2(), boy), false)
	var olcek = Vector2(boy.x / V.DUNYA_EN, boy.y / V.DUNYA_BOY)
	for s in V.BOLGE_SINIR:
		c.draw_line(Vector2(0, s * olcek.y), Vector2(boy.x, s * olcek.y), Color(1, 1, 1, 0.35), 1.0)
	for b in 3:
		var a = Ag.agaclar[b] if b < Ag.agaclar.size() else null
		var p = V.AGAC_YERI[b] * olcek
		var renk = Color(1, 1, 1)
		if a != null:
			if a.bitis > 0.0:
				renk = Color(0.45, 0.6, 0.2)
			elif a.sahip >= 0:
				renk = V.TAKIM_RENK[a.sahip]
		c.draw_circle(p, 7.0, Color(0, 0, 0))
		c.draw_circle(p, 5.5, renk)
		c.draw_string(yazi_kucuk, p + Vector2(10, 5), V.AGAC_ADI[b])
		for t in 2:
			var u = V.us_yeri(t, b) * olcek
			c.draw_rect(Rect2(u - Vector2(3, 3), Vector2(6, 6)), V.TAKIM_RENK[t])
	if dunya != null:
		var g = dunya.odak()
		var p = Vector2(g.x, g.z) * olcek
		var yon = 0.0
		if dunya.oyuncu != null and dunya.oyuncu.aktif:
			yon = dunya.oyuncu.rotation.y if dunya.oyuncu.arac == null else dunya.oyuncu.arac.rotation.y + PI
		var ileri = Vector2(-sin(yon), -cos(yon))
		var yan = Vector2(ileri.y, -ileri.x)
		c.draw_colored_polygon(PoolVector2Array([p + ileri * 9.0, p - ileri * 5.0 + yan * 5.0, p - ileri * 5.0 - yan * 5.0]), Color(1, 0.95, 0.2))


# ---------------------------------------------------------------- otomatik test (geliştirici)
func _test_isle(delta):
	if test.empty() or dunya == null:
		return
	if test.has("seyir"):
		test_sure += delta
		_test_foto()
		return
	if durum != "oyun" or dunya.oyuncu == null:
		return
	test_sure += delta
	var p = dunya.oyuncu
	if test.has("ileri"):
		if test_sure < float(test.ileri):
			Input.action_press("ileri")
		else:
			Input.action_release("ileri")
	if test.has("ates") and test_sure > 2.0 and test_sure < 4.0:
		Input.action_press("ates")
	elif test.has("ates"):
		Input.action_release("ates")
	if test.has("silah") and p.silah != int(test.silah):
		p.silah_sec(int(test.silah))
	if test.has("bak"):
		p.rotation.y = float(test.bak)
	if test.has("egil"):
		p.kafa.rotation.x = float(test.egil)
	if test.has("nisan"):
		Input.action_press("nisan")
	if test.has("cik") and test_sure > float(test.cik):
		print("TEST cikiyorum")
		get_tree().quit()
	if int(test_sure / 4.0) != int((test_sure - delta) / 4.0):
		print("TEST ", Ag.ad, " id=", Ag.benim_id, " hakem=", Ag.sunucu, " ", Ag.ag_ozeti(), " kukla=", dunya.kuklalar.keys(), " aktarilan=", Ag.aktarilan)
	if test.has("git") and not test.has("_gitti") and test_sure > 0.5:
		test["_gitti"] = true
		var xz = test.git.split(",")
		var gx = float(xz[0])
		var gz = float(xz[1])
		var hedef = Vector3(gx, Ag.arazi.yukseklik(gx, gz) + 1.0, gz)
		dunya.orijine_al(hedef)
		dunya.hazirla(hedef)
		p.translation = dunya.yerel(hedef)
	if test.has("agac") and test_sure > 3.0:
		var b = int(test.agac.split(":")[0])
		var ay = V.AGAC_YERI[b]
		var hedef = dunya.yerel(Vector3(ay.x, Ag.arazi.yukseklik(ay.x, ay.y) + 12.0, ay.y))
		var d = hedef - p.kamera.global_transform.origin
		p.rotation.y = atan2(-d.x, -d.z)
		p.kafa.rotation.x = atan2(d.y, Vector2(d.x, d.z).length())
		if test_sure < float(test.agac.split(":")[1]):
			Input.action_press("ates")
		else:
			Input.action_release("ates")
	if test.has("vur") and test_sure > 3.0:
		for k in dunya.kuklalar.values():
			var d = k.translation + Vector3(0, 1.2, 0) - p.kamera.global_transform.origin
			p.rotation.y = atan2(-d.x, -d.z)
			p.kafa.rotation.x = atan2(d.y, Vector2(d.x, d.z).length())
			if test_sure < float(test.vur):
				Input.action_press("ates")
			else:
				Input.action_release("ates")
			break
	if test.has("arac") and test_sure > 1.0 and p.arac == null and not test.has("_arac_istendi"):
		var a = dunya.en_yakin_arac(p.translation, 40.0)
		if a != null:
			p.translation = a.translation + Vector3(3, 1, 0)
			test["_arac_istendi"] = true
			yield(get_tree().create_timer(0.5), "timeout")
			Ag.sunucuya("arac_bin", [a.numara])
	if test.has("arac") and p.arac != null:
		if test_sure < float(test.arac):
			Input.action_press("ileri")
		else:
			Input.action_release("ileri")
	if test.has("harita") and test_sure > 1.0 and not harita_paneli.visible:
		_harita_ac()
	if test.has("arac") and p.arac != null and int(test_sure * 2) != int((test_sure - delta) * 2):
		print("ARAC hiz=%.1f konum=%s" % [p.arac.linear_velocity.length(), str(dunya.kuresel(p.arac.translation))])
	_test_foto()


func _test_foto():
	if test.has("foto"):
		var f = test.foto.split(":")
		if test_sure >= float(f[1]) and not test.has("_cekildi"):
			test["_cekildi"] = true
			yield(VisualServer, "frame_post_draw")
			var img = get_viewport().get_texture().get_data()
			img.flip_y()
			img.save_png(f[0])
			print("TEST foto kaydedildi ", f[0])
			if not test.has("kal"):
				get_tree().quit()
