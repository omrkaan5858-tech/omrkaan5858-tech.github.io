extends Spatial
# Çınarların Savaşı: dünya
# - Arazi oyuncunun çevresinde parça parça üretilir (256 m'lik parçalar). Yakında çok ayrıntılı
#   (4 m'de bir nokta), uzakta kaba. Hesap ayrı bir iş parçacığında yapılır, oyun takılmaz.
# - Dünya 250 km olduğu için "orijin kaydırma" yapılır: oyuncu hep (0,0) yakınında tutulur,
#   gerçek konum ox/oz (64 bit) ile saklanır.
# - Gökyüzü, güneş gölgeleri, parlama, yükseklik sisi, gündüz-gece, bölgeye göre hava,
#   bölge çınarları, çimenler, su, araçlar, öteki oyuncular, efektler.

const V = preload("res://veri.gd")
const Insa = preload("res://insa.gd")
const Arazi = preload("res://arazi.gd")
const Gorsel = preload("res://gorsel.gd")
const OyuncuBetik = preload("res://oyuncu.gd")
const KuklaBetik = preload("res://kukla.gd")
const AracBetik = preload("res://arac.gd")
const Ses = preload("res://ses.gd")

var arazi
var gorsel
var kalite = 2
var ox = 0.0
var oz = 0.0
var gorus = 7
var parcalar = {}          # Vector2 -> {"lod", "dugum"}
var son_parca = Vector2(1e9, 1e9)

# arka plan iş parçacığı (arazi hesabı)
var isci: Thread
var isci_kilit = Mutex.new()
var isci_isaret = Semaphore.new()
var istekler = []
var sonuclar = []
var istenen = {}           # Vector2 -> lod (şu an istenen)
var isci_dur = false
var isci_arazi

var oyuncu = null
var kuklalar = {}
var kukla_zaman = {}
var araclar = []
var dev_agaclar = []
var seyirci: Camera
var seyirci_bolge = 0
var seyirci_aci = 0.0

var mat_iz
var ortam: Environment
var gok: ProceduralSky
var gok_zaman = 0.0
var gunes: DirectionalLight
var su: MeshInstance
var yagmur: CPUParticles
var kum: CPUParticles
var zehir: CPUParticles
var ay_kure: MeshInstance
var gunes_kure: MeshInstance
var yildizlar: MeshInstance
var yildiz_mat: SpatialMaterial
var atis_sesleri = []
var gunluk = 1.0           # 0 gece .. 1 gündüz (HUD/efektler için)


func _ready():
	arazi = Ag.arazi
	if gorsel == null:
		gorsel = Gorsel.new(kalite)
	mat_iz = SpatialMaterial.new()
	mat_iz.flags_unshaded = true
	mat_iz.albedo_color = Color(1.0, 0.85, 0.4)
	_ortam_kur()
	_su_kur()
	_dev_agaclar_kur()
	_araclari_kur()
	for i in 5:
		atis_sesleri.append(Ses.atis(i))
	seyirci = Camera.new()
	seyirci.far = 5000.0
	seyirci.fov = 70.0
	add_child(seyirci)
	seyirci.add_to_group("kaydir")
	seyirci.current = true
	Ag.connect("yakindakiler_geldi", self, "_yakindakiler")
	Ag.connect("atis_goster", self, "_uzak_atis")
	Ag.connect("arac_degisti", self, "_arac_degisti")
	Ag.connect("oyuncu_gitti_sinyal", self, "_kukla_sil")
	isci_arazi = Arazi.new()
	isci = Thread.new()
	isci.start(self, "_isci_dongu", null)


func _exit_tree():
	isci_kilit.lock()
	isci_dur = true
	isci_kilit.unlock()
	isci_isaret.post()
	if isci != null and isci.is_active():
		isci.wait_to_finish()


# ---------------------------------------------------------------- koordinat
func yerel(g: Vector3) -> Vector3:
	return Vector3(g.x - ox, g.y, g.z - oz)


func kuresel(l: Vector3) -> Vector3:
	return Vector3(l.x + ox, l.y, l.z + oz)


func odak_dugumu() -> Spatial:
	if oyuncu != null and oyuncu.aktif:
		if oyuncu.arac != null:
			return oyuncu.arac
		return oyuncu
	return seyirci


func odak() -> Vector3:
	return kuresel(odak_dugumu().global_transform.origin)


func _kaydir(s: Vector3):
	ox += s.x
	oz += s.z
	for d in get_tree().get_nodes_in_group("kaydir"):
		if d is RigidBody and d.mode == RigidBody.MODE_RIGID:
			var t = d.global_transform
			t.origin -= s
			d.global_transform = t
		else:
			d.translation -= s


func orijine_al(g: Vector3):
	_kaydir(Vector3(round(g.x - ox), 0, round(g.z - oz)))


# ---------------------------------------------------------------- ortam: gök, güneş, sis, parlama
func _ortam_kur():
	var a = gorsel.ayar
	ortam = Environment.new()
	if a.gok:
		gok = ProceduralSky.new()
		gok.texture_size = ProceduralSky.TEXTURE_SIZE_512
		gok.radiance_size = Sky.RADIANCE_SIZE_32
		gok.sun_angle_max = 30.0
		gok.sun_curve = 0.12
		ortam.background_mode = Environment.BG_SKY
		ortam.background_sky = gok
		ortam.ambient_light_sky_contribution = 0.25
	else:
		ortam.background_mode = Environment.BG_COLOR
		ortam.background_color = Color(0.55, 0.72, 0.95)
	ortam.ambient_light_color = Color(0.6, 0.65, 0.7)
	ortam.ambient_light_energy = 0.6
	ortam.fog_enabled = true
	ortam.fog_color = Color(0.62, 0.74, 0.9)
	ortam.fog_depth_begin = 300.0
	ortam.fog_depth_end = gorus * V.PARCA
	ortam.fog_depth_curve = 1.6
	if a.gok:
		ortam.fog_sun_amount = 0.45
		ortam.fog_sun_color = Color(1.0, 0.85, 0.6)
		ortam.fog_transmit_enabled = true
		ortam.fog_height_enabled = true
		ortam.fog_height_curve = 1.2
	ortam.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	ortam.tonemap_exposure = 1.0
	ortam.tonemap_white = 6.0
	if a.glow:
		ortam.glow_enabled = true
		ortam.glow_intensity = 0.4
		ortam.glow_strength = 0.9
		ortam.glow_bloom = 0.0
		ortam.glow_hdr_threshold = 1.4
		ortam.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
		ortam.set("glow_levels/1", false)
		ortam.set("glow_levels/3", true)
		ortam.set("glow_levels/5", true)
	if a.ssao:
		ortam.ssao_enabled = true
		ortam.ssao_radius = 1.2
		ortam.ssao_intensity = 1.2
		ortam.ssao_light_affect = 0.15
		ortam.ssao_quality = Environment.SSAO_QUALITY_LOW
	ortam.adjustment_enabled = true
	ortam.adjustment_contrast = 1.06
	ortam.adjustment_saturation = 1.12
	var we = WorldEnvironment.new()
	we.environment = ortam
	add_child(we)
	gunes = DirectionalLight.new()
	gunes.light_energy = 1.1
	if a.golge > 0.0:
		gunes.shadow_enabled = true
		gunes.directional_shadow_mode = DirectionalLight.SHADOW_PARALLEL_4_SPLITS if kalite >= 2 else DirectionalLight.SHADOW_PARALLEL_2_SPLITS
		gunes.directional_shadow_max_distance = a.golge
		gunes.directional_shadow_blend_splits = kalite >= 2
		gunes.shadow_bias = 0.08
		gunes.directional_shadow_normal_bias = 0.6
		gunes.shadow_color = Color(0.25, 0.27, 0.35)
	add_child(gunes)
	ay_kure = _gok_kuresi(Color(0.88, 0.9, 0.96), 34.0)
	gunes_kure = _gok_kuresi(Color(1.0, 0.92, 0.6), 45.0)
	gunes_kure.visible = false
	_yildizlar_kur()
	yagmur = _parcacik(Color(0.75, 0.82, 0.95, 0.5), Vector3(0.02, 0.8, 0.02), Vector3(0, -1, 0), 30.0, 3000)
	kum = _parcacik(Color(0.85, 0.65, 0.40, 0.6), Vector3(0.12, 0.12, 0.12), Vector3(1, -0.1, 0.3), 14.0, 3000)
	zehir = _parcacik(Color(0.55, 0.85, 0.30, 0.55), Vector3(0.22, 0.22, 0.22), Vector3(0.2, 0.3, 0.1), 1.5, 1200)


func _gok_kuresi(renk: Color, r: float) -> MeshInstance:
	var m = MeshInstance.new()
	var s = gorsel.kure(r, -1.0, 16, 8)
	var mt = SpatialMaterial.new()
	mt.flags_unshaded = true
	mt.flags_do_not_receive_shadows = true
	mt.flags_disable_ambient_light = true
	mt.albedo_color = renk
	s.material = mt
	m.mesh = s
	m.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
	add_child(m)
	return m


func _yildizlar_kur():
	var rng = RandomNumberGenerator.new()
	rng.seed = 9879
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_POINTS)
	for i in 1800:
		var y = rng.randf_range(0.02, 1.0)
		var a = rng.randf() * TAU
		var r = sqrt(1.0 - y * y)
		var p = Vector3(cos(a) * r, y, sin(a) * r) * 3500.0
		var parlak = rng.randf_range(0.4, 1.0)
		st.add_color(Color(parlak, parlak, parlak * rng.randf_range(0.9, 1.1)))
		st.add_vertex(p)
	yildizlar = MeshInstance.new()
	yildizlar.mesh = st.commit()
	yildiz_mat = SpatialMaterial.new()
	yildiz_mat.flags_unshaded = true
	yildiz_mat.flags_transparent = true
	yildiz_mat.flags_use_point_size = true
	yildiz_mat.params_point_size = 2.0
	yildiz_mat.vertex_color_use_as_albedo = true
	yildiz_mat.albedo_color = Color(1, 1, 1, 0)
	yildizlar.material_override = yildiz_mat
	yildizlar.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
	add_child(yildizlar)


func _parcacik(renk: Color, boyut: Vector3, yon: Vector3, hiz: float, adet: int) -> CPUParticles:
	var p = CPUParticles.new()
	var cm = CubeMesh.new()
	cm.size = boyut
	var mt = SpatialMaterial.new()
	mt.flags_unshaded = true
	mt.flags_transparent = true
	mt.albedo_color = renk
	cm.material = mt
	p.mesh = cm
	p.amount = adet if kalite >= 2 else adet / 2
	p.lifetime = 2.0
	p.emission_shape = CPUParticles.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(45, 12, 45)
	p.direction = yon
	p.spread = 8.0
	p.gravity = Vector3(0, 0, 0)
	p.initial_velocity = hiz
	p.local_coords = false
	p.emitting = false
	add_child(p)
	return p


func _su_kur():
	su = MeshInstance.new()
	var pm = PlaneMesh.new()
	pm.size = Vector2(12000, 12000)
	pm.material = gorsel.mat_su
	su.mesh = pm
	su.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
	add_child(su)


# ---------------------------------------------------------------- bölge çınarları (dev ağaçlar)
func _dev_agaclar_kur():
	var g = gorsel
	var kabuk = g.mat_govde.duplicate()
	kabuk.albedo_color = Color(0.58, 0.52, 0.42)     # çınarın açık renkli, alacalı kabuğu
	for b in 3:
		var a = V.AGAC_YERI[b]
		var h = arazi.yukseklik(a.x, a.y)
		var d = Spatial.new()
		d.translation = yerel(Vector3(a.x, h, a.y))
		d.add_to_group("kaydir")
		add_child(d)
		var rng = RandomNumberGenerator.new()
		rng.seed = 40 + b
		# gövde, kökler ve dallar tek ağ
		var parcalar_ = [[g.silindir(6.2, 3.6, 10.0, 18), g.dt(Vector3(0, 5, 0))],
			[g.silindir(3.6, 2.6, 34.0, 18), g.dt(Vector3(0, 27, 0))]]
		for i in 7:
			var aci = i * TAU / 7.0 + 0.3
			parcalar_.append([g.silindir(1.6, 0.4, 11.0, 8), Transform(Basis(Vector3.UP, -aci) * Basis(Vector3.FORWARD, 1.15), Vector3(cos(aci) * 6.5, 1.3, sin(aci) * 6.5))])
		for i in 12:
			var aci = i * TAU / 12.0 + rng.randf_range(-0.2, 0.2)
			var egim = rng.randf_range(0.65, 1.05)
			var boy = rng.randf_range(16.0, 24.0)
			var yer = Vector3(cos(aci) * 2.5, rng.randf_range(30.0, 40.0), sin(aci) * 2.5)
			var bs = Basis(Vector3.UP, -aci) * Basis(Vector3.FORWARD, -egim)
			parcalar_.append([g.silindir(1.25, 0.35, boy, 8), Transform(bs, yer + bs.y * boy * 0.5)])
		var govde = MeshInstance.new()
		govde.mesh = g.birlestir(parcalar_, kabuk)
		d.add_child(govde)
		# tepe: çok sayıda yaprak kümesi
		var tepe = MeshInstance.new()
		var yk = []
		var kenar = 16 if kalite >= 2 else 10
		yk.append([g.kure(18.0, 24.0, kenar, kenar / 2), g.dt(Vector3(0, 60, 0))])
		for i in 16:
			var aci = i * TAU / 16.0 + rng.randf_range(-0.15, 0.15)
			var uz = rng.randf_range(13.0, 22.0)
			var r = rng.randf_range(8.0, 13.0)
			yk.append([g.kure(r, r * 1.5, kenar, kenar / 2), g.dt(Vector3(cos(aci) * uz, rng.randf_range(45.0, 62.0), sin(aci) * uz))])
		var tmt = g.mat_yaprak.duplicate()
		tmt.vertex_color_use_as_albedo = false
		tmt.albedo_color = Color(0.27, 0.55, 0.21)
		tepe.mesh = g.birlestir(yk, tmt)
		d.add_child(tepe)
		var kutuk = MeshInstance.new()
		kutuk.mesh = g.birlestir([[g.silindir(6.2, 4.8, 4.0, 18), g.dt(Vector3(0, 2, 0))]], kabuk.duplicate())
		kutuk.mesh.surface_get_material(0).albedo_color = Color(0.22, 0.18, 0.14)
		kutuk.visible = false
		d.add_child(kutuk)
		var halka = MeshInstance.new()
		var hm = g.silindir(V.ELE_GECIRME_YARICAP, V.ELE_GECIRME_YARICAP, 0.4, 48)
		var hmt = SpatialMaterial.new()
		hmt.flags_transparent = true
		hmt.flags_unshaded = true
		hmt.albedo_color = Color(1, 1, 1, 0.25)
		hm.material = hmt
		halka.mesh = hm
		halka.translation = Vector3(0, 0.3, 0)
		halka.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
		d.add_child(halka)
		var govde_cisim = StaticBody.new()
		govde_cisim.collision_layer = 4
		govde_cisim.collision_mask = 0
		govde_cisim.set_meta("agac", b)
		var s1 = CollisionShape.new()
		var cs = CylinderShape.new()
		cs.radius = 5.0
		cs.height = 44.0
		s1.shape = cs
		s1.translation = Vector3(0, 22, 0)
		var s2 = CollisionShape.new()
		var ss = SphereShape.new()
		ss.radius = 26.0
		s2.shape = ss
		s2.translation = Vector3(0, 55, 0)
		govde_cisim.add_child(s1)
		govde_cisim.add_child(s2)
		d.add_child(govde_cisim)
		dev_agaclar.append({"dugum": d, "tepe": tepe, "govde": govde, "kutuk": kutuk, "halka": hmt, "yaprak": tmt, "cisim": govde_cisim, "s2": s2})


func agaclari_guncelle():
	for b in 3:
		var a = Ag.agaclar[b] if b < Ag.agaclar.size() else null
		if a == null:
			continue
		var d = dev_agaclar[b]
		var dustu = a.bitis > 0.0
		d.tepe.visible = not dustu
		d.govde.visible = not dustu
		d.kutuk.visible = dustu
		d.s2.disabled = dustu
		var oran = clamp(float(a.can) / V.AGAC_CAN, 0.0, 1.0)
		d.yaprak.albedo_color = Color(0.55, 0.42, 0.18).linear_interpolate(Color(0.27, 0.55, 0.21), oran)
		if a.sahip >= 0:
			var c = V.TAKIM_RENK[a.sahip]
			d.halka.albedo_color = Color(c.r, c.g, c.b, 0.35)
		else:
			d.halka.albedo_color = Color(1, 1, 1, 0.18)


# ---------------------------------------------------------------- araçlar
func _araclari_kur():
	for i in Ag.araclar.size():
		var a = AracBetik.new()
		a.numara = i
		a.dunya = self
		add_child(a)
		a.add_to_group("kaydir")
		a.yerlestir(Ag.araclar[i].konum, Ag.araclar[i].donus)
		araclar.append(a)


func _arac_degisti(i):
	if i < araclar.size():
		var a = araclar[i]
		var v = Ag.araclar[i]
		if v.surucu != Ag.benim_id:
			a.uzaktan(v.konum, v.donus)


func en_yakin_arac(l: Vector3, menzil: float):
	var en = null
	var ed = menzil
	for a in araclar:
		var d = a.global_transform.origin.distance_to(l)
		if d < ed and Ag.araclar[a.numara].surucu == -1:
			ed = d
			en = a
	return en


# ---------------------------------------------------------------- öteki oyuncular
func _yakindakiler(liste: Array, arac_liste: Array):
	var simdi = OS.get_ticks_msec()
	for e in liste:
		var id = e[0]
		if id == Ag.benim_id:
			continue
		if not kuklalar.has(id):
			var k = KuklaBetik.new()
			var takim = Ag.oyuncular[id].takim if Ag.oyuncular.has(id) else 0
			k.kur(id, takim, self)
			add_child(k)
			k.add_to_group("kaydir")
			k.translation = yerel(e[1])
			kuklalar[id] = k
		kuklalar[id].hedef(e[1], e[2], e[3], e[4], e[5])
		kukla_zaman[id] = simdi
	for id in kuklalar.keys():
		if simdi - kukla_zaman.get(id, 0) > 1500:
			_kukla_sil(id)
	for e in arac_liste:
		var i = e[0]
		if i < araclar.size() and e[3] != Ag.benim_id:
			Ag.araclar[i].konum = e[1]
			Ag.araclar[i].donus = e[2]
			Ag.araclar[i].surucu = e[3]
			araclar[i].uzaktan(e[1], e[2])


func _kukla_sil(id):
	if kuklalar.has(id):
		kuklalar[id].queue_free()
		kuklalar.erase(id)
		kukla_zaman.erase(id)


# ---------------------------------------------------------------- yerel oyuncu
func dogmaya_hazirla(konum: Vector3):
	# doğmadan önce: dünyayı oraya kaydır, çevrenin üretilmesini başlat
	orijine_al(konum)
	son_parca = Vector2(1e9, 1e9)
	_parca_listesi(konum)


func cevre_hazir(konum: Vector3) -> bool:
	_sonuclari_isle(20000)
	var pi = int(floor(konum.x / V.PARCA))
	var pj = int(floor(konum.z / V.PARCA))
	for di in range(-2, 3):
		for dj in range(-2, 3):
			var k = Vector2(pi + di, pj + dj)
			if istenen.has(k) and not parcalar.has(k):
				return false
	return true


func oyuncu_dogur(konum: Vector3):
	if oyuncu == null:
		oyuncu = OyuncuBetik.new()
		oyuncu.dunya = self
		add_child(oyuncu)
		oyuncu.add_to_group("kaydir")
	oyuncu.dogdu(yerel(konum))
	seyirci.current = false


func oyuncu_oldu():
	if oyuncu != null:
		oyuncu.oldu()
	seyirci.current = true
	var l = oyuncu.global_transform.origin if oyuncu != null else Vector3()
	seyirci.translation = l + Vector3(0, 25, 25)
	seyirci.look_at(l, Vector3.UP)


func seyirci_bolgesi(b: int):
	seyirci_bolge = b


func hazirla(merkez: Vector3):
	# hemen (beklemeden) üret: sadece test ışınlaması için
	var pi = int(floor(merkez.x / V.PARCA))
	var pj = int(floor(merkez.z / V.PARCA))
	for di in range(-2, 3):
		for dj in range(-2, 3):
			var k = Vector2(pi + di, pj + dj)
			var lod = _lod(max(abs(di), abs(dj)))
			_parca_kur(_parca_hesapla([k, lod], arazi))
	son_parca = Vector2(1e9, 1e9)


# ---------------------------------------------------------------- arazi parçaları
func _lod(r: int) -> int:
	if r <= gorsel.ayar.halka0:
		return 0
	if r <= gorsel.ayar.halka1:
		return 1
	return 2


func _parca_listesi(merkez: Vector3):
	var pi = int(floor(merkez.x / V.PARCA))
	var pj = int(floor(merkez.z / V.PARCA))
	var p = Vector2(pi, pj)
	if p == son_parca:
		return
	son_parca = p
	var yeni = {}
	var liste = []
	for di in range(-gorus, gorus + 1):
		for dj in range(-gorus, gorus + 1):
			var k = Vector2(pi + di, pj + dj)
			var x = k.x * V.PARCA
			var z = k.y * V.PARCA
			if x < -4000.0 or z < -4000.0 or x > V.DUNYA_EN + 4000.0 or z > V.DUNYA_BOY + 4000.0:
				continue
			var r = max(abs(di), abs(dj))
			var lod = _lod(r)
			yeni[k] = lod
			if not parcalar.has(k) or parcalar[k].lod != lod:
				liste.append([r, k, lod])
	liste.sort_custom(self, "_yakin_once")
	istenen = yeni
	isci_kilit.lock()
	istekler = []        # henüz başlanmamış eski istekleri bırak, yenileri yakından uzağa sırala
	for e in liste:
		istekler.append([e[1], e[2]])
	isci_kilit.unlock()
	for _i in liste.size():
		isci_isaret.post()
	for k in parcalar.keys():
		if not istenen.has(k):
			parcalar[k].dugum.queue_free()
			parcalar.erase(k)


func _yakin_once(a, b):
	return a[0] < b[0]


func _isci_dongu(_u):
	while true:
		isci_isaret.wait()
		isci_kilit.lock()
		if isci_dur:
			isci_kilit.unlock()
			return
		var is_ = null
		if istekler.size() > 0:
			is_ = istekler.pop_front()
		isci_kilit.unlock()
		if is_ == null:
			continue
		var s = _parca_hesapla(is_, isci_arazi)
		isci_kilit.lock()
		sonuclar.append(s)
		isci_kilit.unlock()


func _sonuclari_isle(butce_us: int):
	var bas = OS.get_ticks_usec()
	while OS.get_ticks_usec() - bas < butce_us:
		isci_kilit.lock()
		var s = sonuclar.pop_front() if sonuclar.size() > 0 else null
		isci_kilit.unlock()
		if s == null:
			return
		if istenen.get(s.k, -1) == s.lod and not (parcalar.has(s.k) and parcalar[s.k].lod == s.lod):
			_parca_kur(s)


func _h_ara(H: PoolRealArray, w: int, adim: float, lx: float, lz: float) -> float:
	var fx = clamp(lx / adim + 1.0, 0.0, w - 1.001)
	var fz = clamp(lz / adim + 1.0, 0.0, w - 1.001)
	var a = min(int(fx), w - 2)
	var b = min(int(fz), w - 2)
	var tx = fx - a
	var tz = fz - b
	return lerp(lerp(H[b * w + a], H[b * w + a + 1], tx), lerp(H[(b + 1) * w + a], H[(b + 1) * w + a + 1], tx), tz)


func _satir(a: PoolVector3Array, b: Basis, o: Vector3) -> PoolVector3Array:
	# MultiMesh.transform_array biçimi: 3 satır + konum
	a.append(Vector3(b.x.x, b.y.x, b.z.x))
	a.append(Vector3(b.x.y, b.y.y, b.z.y))
	a.append(Vector3(b.x.z, b.y.z, b.z.z))
	a.append(o)
	return a


func _parca_hesapla(is_: Array, az) -> Dictionary:
	# Bu işlev arka plandaki iş parçacığında çalışır: sadece sayı hesaplar, düğüm oluşturmaz.
	var k = is_[0]
	var lod = is_[1]
	var ay = gorsel.ayar
	var n = ay.seg[lod]
	var adim = V.PARCA / n
	var x0 = k.x * V.PARCA
	var z0 = k.y * V.PARCA
	var w = n + 3
	var H = PoolRealArray()
	H.resize(w * w)
	for b in w:
		for a in w:
			H[b * w + a] = az.yukseklik(x0 + (a - 1) * adim, z0 + (b - 1) * adim)
	var verts = PoolVector3Array()
	var norms = PoolVector3Array()
	var renk = PoolColorArray()
	for b in n + 1:
		for a in n + 1:
			var h = H[(b + 1) * w + a + 1]
			var nn = Vector3(H[(b + 1) * w + a] - H[(b + 1) * w + a + 2], 2.0 * adim, H[b * w + a + 1] - H[(b + 2) * w + a + 1]).normalized()
			verts.append(Vector3(a * adim, h, b * adim))
			norms.append(nn)
			renk.append(az.renk(x0 + a * adim, z0 + b * adim, h, (1.0 - nn.y) * 3.0))
	var ind = PoolIntArray()
	for b in n:
		for a in n:
			var i = b * (n + 1) + a
			ind.append(i); ind.append(i + 1); ind.append(i + n + 1)
			ind.append(i + 1); ind.append(i + n + 2); ind.append(i + n + 1)
	var derin = [6.0, 12.0, 30.0][lod]
	var kenarlar = [[], [], [], []]
	for t in n + 1:
		kenarlar[0].append(t)
		kenarlar[1].append(n * (n + 1) + t)
		kenarlar[2].append(t * (n + 1))
		kenarlar[3].append(t * (n + 1) + n)
	for kenar in kenarlar:
		var bas = verts.size()
		for i in kenar:
			verts.append(verts[i] - Vector3(0, derin, 0))
			norms.append(norms[i])
			renk.append(renk[i])
		for t in n:
			ind.append(kenar[t]); ind.append(kenar[t + 1]); ind.append(bas + t)
			ind.append(kenar[t + 1]); ind.append(bas + t + 1); ind.append(bas + t)
	var s = {"k": k, "lod": lod, "x0": x0, "z0": z0, "v": verts, "n": norms, "c": renk, "i": ind}
	if lod <= 1:
		_nesneleri_hesapla(s, az, H, w, adim, lod)
	return s


func _nesneleri_hesapla(s: Dictionary, az, H: PoolRealArray, w: int, adim: float, lod: int):
	var x0 = s.x0
	var z0 = s.z0
	var kur = Insa.new()
	var olcuk = [[0.42, 5.0], [0.36, 9.0], [0.3, 8.0], [0.7, 13.0]]
	var agac_t = [PoolVector3Array(), PoolVector3Array(), PoolVector3Array(), PoolVector3Array()]
	var agac_c = [PoolColorArray(), PoolColorArray(), PoolColorArray(), PoolColorArray()]
	var aralik = gorsel.ayar.agac_aralik
	var gx = 0.0
	while gx < V.PARCA:
		var gz = 0.0
		while gz < V.PARCA:
			var hs = V.karistir(int(x0 + gx), int(z0 + gz), 3)
			var lx = gx + float(hs % 1000) / 1000.0 * aralik * 0.85
			var lz = gz + float((hs / 1000) % 1000) / 1000.0 * aralik * 0.85
			var rnd = float((hs / 1000000) % 1000) / 1000.0 * (aralik / 11.0) * (aralik / 11.0)
			var h = _h_ara(H, w, adim, lx, lz)
			var e = abs(_h_ara(H, w, adim, lx + 4.0, lz) - h) / 4.0 + abs(_h_ara(H, w, adim, lx, lz + 4.0) - h) / 4.0
			var tip = az.agac_tipi(x0 + lx, z0 + lz, h, e, min(rnd, 0.999))
			if tip >= 0:
				var sc = 0.75 + float(hs % 97) / 97.0 * 0.6
				var bs = Basis(Vector3.UP, float(hs % 628) / 100.0).scaled(Vector3(sc, sc, sc))
				agac_t[tip] = _satir(agac_t[tip], bs, Vector3(lx, h - 0.25, lz))
				var yesil = [Color(0.27, 0.50, 0.18), Color(0.14, 0.33, 0.17), Color(0.32, 0.55, 0.20), Color(0.16, 0.43, 0.13)][tip]
				var ac = agac_c[tip]
				ac.append(yesil.lightened(float(hs % 23) / 110.0).darkened(float(hs % 7) / 40.0))
				agac_c[tip] = ac
				kur.silindir(Vector3(lx, h - 0.5, lz), olcuk[tip][0] * sc, olcuk[tip][1] * sc, Color(), 5, true)
			gz += aralik
		gx += aralik
	kur.v = PoolVector3Array()      # gövde çarpışmaları kalır; görüntü MultiMesh ile
	kur.n = PoolVector3Array()
	kur.c = PoolColorArray()
	s["agac_t"] = agac_t
	s["agac_c"] = agac_c
	# yapılar
	var yapilar = []
	var bakildi = {}
	for kose in [Vector2(x0, z0), Vector2(x0 + V.PARCA, z0), Vector2(x0, z0 + V.PARCA), Vector2(x0 + V.PARCA, z0 + V.PARCA)]:
		var cx = int(kose.x / az.HUCRE)
		var cz = int(kose.y / az.HUCRE)
		if bakildi.has(cx * 1000 + cz):
			continue
		bakildi[cx * 1000 + cz] = true
		var y = az.hucre(cx, cz)
		if y == null:
			continue
		if y.x + y.r < x0 or y.x - y.r > x0 + V.PARCA or y.z + y.r < z0 or y.z - y.r > z0 + V.PARCA:
			continue
		for yp in az.yapilar_yerlesim(y):
			yapilar.append([yp, y.h])
	for o in az.ozel:
		if abs(o.x - (x0 + 128.0)) < 500.0 and abs(o.z - (z0 + 128.0)) < 500.0:
			for yp in az.yapilar_ozel(o):
				yapilar.append([yp, o.h])
	for e in yapilar:
		var yp = e[0]
		if yp.x < x0 or yp.x >= x0 + V.PARCA or yp.z < z0 or yp.z >= z0 + V.PARCA:
			continue
		var taban = Vector3(yp.x - x0, e[1] + yp.get("y", 0.0), yp.z - z0)
		match yp.t:
			"kutu":
				kur.kutu(taban, yp.en, yp.boy, yp.yuk, yp.aci, yp.renk)
				if yp.yuk > 3.5 and yp.en > 5.0 and yp.boy > 5.0 and lod == 0:
					_pencereler(kur, taban, yp)
			"cati":
				kur.cati(taban, yp.en, yp.boy, yp.yuk, yp.aci, yp.renk, yp.get("y", 1.0) == 0.0)
			"silindir":
				kur.silindir(taban, yp.r, yp.yuk, yp.renk, 14)
	s["yapi_v"] = kur.v
	s["yapi_n"] = kur.n
	s["yapi_c"] = kur.c
	s["carp"] = kur.f
	# çimenler (sadece en yakın parçalarda)
	var adet = gorsel.ayar.cimen if lod == 0 else 0
	var cim_t = PoolVector3Array()
	var cim_c = PoolColorArray()
	if adet > 0:
		var w0 = az.agirliklar(z0 + 128.0)
		if w0[1] < 0.6:
			var rng = RandomNumberGenerator.new()
			rng.seed = V.karistir(int(x0), int(z0), 77)
			for i in adet:
				var lx = rng.randf() * V.PARCA
				var lz = rng.randf() * V.PARCA
				var h = _h_ara(H, w, adim, lx, lz)
				if h < 1.0 or h > 850.0:
					continue
				var e = abs(_h_ara(H, w, adim, lx + 2.0, lz) - h) / 2.0
				if e > 0.6:
					continue
				var y = az.yerlesim_at(x0 + lx, z0 + lz)
				if y != null and Vector2(x0 + lx - y.x, z0 + lz - y.z).length() < y.r:
					continue
				var sc = rng.randf_range(0.7, 1.35)
				cim_t = _satir(cim_t, Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(sc, sc * rng.randf_range(0.8, 1.3), sc)), Vector3(lx, h - 0.05, lz))
				var c = Color(0.36, 0.55, 0.20) if w0[2] < 0.5 else Color(0.20, 0.48, 0.15)
				cim_c.append(c.lightened(rng.randf() * 0.15).darkened(rng.randf() * 0.15))
	s["cim_t"] = cim_t
	s["cim_c"] = cim_c


func _pencereler(kur, taban: Vector3, yp: Dictionary):
	# binaların duvarlarına pencere sıraları (koyu camlar)
	var bs = Basis(Vector3.UP, yp.aci)
	var cam = Color(0.16, 0.2, 0.25)
	var kat = int(yp.yuk / 3.2)
	for yuz in 4:
		var normal = [bs.z, -bs.z, bs.x, -bs.x][yuz]
		var yan = [bs.x, bs.x, bs.z, bs.z][yuz]
		var uzunluk = yp.en if yuz < 2 else yp.boy
		var derinlik = (yp.boy if yuz < 2 else yp.en) * 0.5 + 0.03
		var sayi = int(uzunluk / 3.5)
		for kt in kat:
			for p in sayi:
				var u = (p + 0.5) * uzunluk / sayi - uzunluk * 0.5
				var merkez = taban + normal * derinlik + yan * u + Vector3(0, kt * 3.2 + 1.6, 0)
				var x = yan * 0.6
				var y = Vector3(0, 0.75, 0)
				kur.dortgen(merkez - x - y, merkez + x - y, merkez + x + y, merkez - x + y, cam, normal, false)


func _parca_kur(s: Dictionary):
	var k = s.k
	if parcalar.has(k):
		parcalar[k].dugum.queue_free()
		parcalar.erase(k)
	var arr = []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = s.v
	arr[Mesh.ARRAY_NORMAL] = s.n
	arr[Mesh.ARRAY_COLOR] = s.c
	arr[Mesh.ARRAY_INDEX] = s.i
	var mesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	mesh.surface_set_material(0, gorsel.mat_arazi)
	var dugum = Spatial.new()
	dugum.translation = Vector3(s.x0 - ox, 0, s.z0 - oz)
	dugum.add_to_group("kaydir")
	var mi = MeshInstance.new()
	mi.mesh = mesh
	if s.lod == 2:
		mi.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
	dugum.add_child(mi)
	if s.lod <= 1:
		var cisim = StaticBody.new()
		cisim.collision_layer = 1
		cisim.collision_mask = 0
		var cs = CollisionShape.new()
		cs.shape = mesh.create_trimesh_shape()
		cisim.add_child(cs)
		if s.carp.size() > 0:
			var cs2 = CollisionShape.new()
			var sekil = ConcavePolygonShape.new()
			sekil.set_faces(s.carp)
			cs2.shape = sekil
			cisim.add_child(cs2)
		dugum.add_child(cisim)
		for tip in 4:
			var t = s.agac_t[tip]
			if t.size() == 0:
				continue
			for parca in 2:
				var mm = MultiMesh.new()
				mm.transform_format = MultiMesh.TRANSFORM_3D
				mm.color_format = MultiMesh.COLOR_8BIT if parca == 1 else MultiMesh.COLOR_NONE
				mm.mesh = gorsel.agac_meshleri[tip][parca]
				mm.instance_count = t.size() / 4
				mm.transform_array = t
				if parca == 1:
					mm.color_array = s.agac_c[tip]
				var mmi = MultiMeshInstance.new()
				mmi.multimesh = mm
				mmi.material_override = gorsel.mat_govde if parca == 0 else gorsel.mat_yaprak
				dugum.add_child(mmi)
		if s.yapi_v.size() > 0:
			var a = []
			a.resize(Mesh.ARRAY_MAX)
			a[Mesh.ARRAY_VERTEX] = s.yapi_v
			a[Mesh.ARRAY_NORMAL] = s.yapi_n
			a[Mesh.ARRAY_COLOR] = s.yapi_c
			var ym = ArrayMesh.new()
			ym.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
			ym.surface_set_material(0, gorsel.mat_yapi)
			var ymi = MeshInstance.new()
			ymi.mesh = ym
			dugum.add_child(ymi)
		if s.cim_t.size() > 0:
			var mm = MultiMesh.new()
			mm.transform_format = MultiMesh.TRANSFORM_3D
			mm.color_format = MultiMesh.COLOR_8BIT
			mm.mesh = gorsel.cimen_mesh
			mm.instance_count = s.cim_t.size() / 4
			mm.transform_array = s.cim_t
			mm.color_array = s.cim_c
			var mmi = MultiMeshInstance.new()
			mmi.multimesh = mm
			mmi.material_override = gorsel.mat_cimen
			mmi.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
			dugum.add_child(mmi)
	add_child(dugum)
	parcalar[k] = {"lod": s.lod, "dugum": dugum}


# ---------------------------------------------------------------- her kare
func _process(delta):
	if seyirci.current and (oyuncu == null or not oyuncu.aktif):
		seyirci_aci += delta * 0.05
		var a = V.AGAC_YERI[seyirci_bolge]
		var h = arazi.yukseklik(a.x, a.y)
		var hedef = yerel(Vector3(a.x, h + 30.0, a.y))
		var g = yerel(Vector3(a.x + cos(seyirci_aci) * 220.0, h + 90.0, a.y + sin(seyirci_aci) * 220.0))
		if seyirci.translation.distance_to(g) > 400.0:
			orijine_al(Vector3(a.x, 0, a.y))
			hedef = yerel(Vector3(a.x, h + 30.0, a.y))
			g = yerel(Vector3(a.x + cos(seyirci_aci) * 220.0, h + 90.0, a.y + sin(seyirci_aci) * 220.0))
		seyirci.translation = g
		seyirci.look_at(hedef, Vector3.UP)
	var o = odak()
	_parca_listesi(o)
	_sonuclari_isle(5000)
	var kam = get_viewport().get_camera()
	var kl = kam.global_transform.origin if kam != null else Vector3()
	su.translation = Vector3(stepify(kl.x, 100.0), 0.0, stepify(kl.z, 100.0))
	if gorsel.ayar.su:
		gorsel.mat_su.set_shader_param("kayma", Vector2(fmod(ox, 2000.0), fmod(oz, 2000.0)))
		gorsel.mat_su.set_shader_param("koyuluk", lerp(0.18, 1.0, gunluk))
	_gok(delta, kl, o)
	agaclari_guncelle()
	for d in dev_agaclar:
		d.dugum.visible = d.dugum.translation.distance_to(kl) < 7000.0
	if gorsel.ayar.dof and oyuncu != null and oyuncu.aktif:
		ortam.dof_blur_near_enabled = oyuncu.nisan and oyuncu.arac == null and oyuncu.silah != 1
		ortam.dof_blur_near_distance = 0.45
		ortam.dof_blur_near_transition = 0.15
		ortam.dof_blur_near_amount = 0.08


func _physics_process(_delta):
	var d = odak_dugumu()
	var p = d.global_transform.origin
	if Vector2(p.x, p.z).length() > 700.0:
		_kaydir(Vector3(round(p.x), 0, round(p.z)))


func _gok(delta, kl: Vector3, o: Vector3):
	var hs = V.gunun_saati(Ag.saat)
	var a = (hs - 6.0) / 12.0 * PI
	var gunes_yon = Vector3(cos(a), sin(a), 0.35).normalized()
	var gun = clamp(sin(a) * 4.0 + 0.3, 0.0, 1.0)
	gunluk = gun
	var b = V.bolge(o.z)
	var hava = V.hava(b, Ag.saat)
	var ust = Color(0.03, 0.04, 0.10).linear_interpolate(Color(0.30, 0.52, 0.86), gun)
	var ufuk = Color(0.06, 0.07, 0.14).linear_interpolate(Color(0.70, 0.80, 0.92), gun)
	var aksam = clamp(1.0 - abs(sin(a) - 0.06) / 0.2, 0.0, 1.0) if sin(a) > -0.15 else 0.0
	ufuk = ufuk.linear_interpolate(Color(1.0, 0.55, 0.30), aksam * 0.7)
	var isik = 1.25 * gun
	var sis_son = gorus * V.PARCA
	var sis_renk = ufuk
	var yukseklik_sis = 0.0
	if hs > 4.5 and hs < 9.5:
		yukseklik_sis = 1.0 - abs(hs - 6.5) / 3.0   # sabah vadilerde yerden yükselen sis
	if b == 1:
		ufuk = ufuk.linear_interpolate(Color(0.90, 0.80, 0.62), 0.35 * gun)
		sis_renk = ufuk
		yukseklik_sis *= 0.2
	match hava:
		1:
			ust = ust.linear_interpolate(Color(0.50, 0.53, 0.58) * max(gun, 0.1), 0.65)
			ufuk = ufuk.linear_interpolate(Color(0.62, 0.65, 0.70) * max(gun, 0.1), 0.5)
			isik *= 0.6
		2:
			ust = Color(0.32, 0.35, 0.40) * max(gun, 0.08)
			ufuk = Color(0.45, 0.48, 0.52) * max(gun, 0.08)
			isik *= 0.35
			sis_son *= 0.45
			yukseklik_sis = max(yukseklik_sis, 0.5)
		3:
			sis_son = 230.0
			sis_renk = Color(0.76, 0.78, 0.81) * max(gun, 0.15)
			ufuk = sis_renk
			isik *= 0.5
			yukseklik_sis = 1.0
		4:
			sis_son = 150.0
			sis_renk = Color(0.82, 0.63, 0.38) * max(gun, 0.15)
			ust = sis_renk
			ufuk = sis_renk
			isik *= 0.45
		5:
			sis_son *= 0.55
			sis_renk = Color(0.93, 0.86, 0.70) * max(gun, 0.15)
			ufuk = ufuk.linear_interpolate(sis_renk, 0.6)
	var dustu = b < Ag.agaclar.size() and Ag.agaclar[b].bitis > 0.0
	if dustu:
		sis_son = 260.0
		sis_renk = Color(0.36, 0.48, 0.20) * max(gun, 0.25)
		ust = sis_renk
		ufuk = sis_renk
		yukseklik_sis = 1.0
	if hava < 3 and not dustu:
		sis_renk = ufuk
	var hiz = min(1.0, delta * 2.0)
	ortam.fog_color = ortam.fog_color.linear_interpolate(sis_renk, hiz)
	ortam.fog_depth_end = lerp(ortam.fog_depth_end, sis_son, min(1.0, delta * 1.5))
	ortam.fog_depth_begin = min(250.0, ortam.fog_depth_end * 0.25)
	if gorsel.ayar.gok:
		# Godot 3: height_min = sisin başladığı (sıfır) yükseklik, height_max = en yoğun olduğu yükseklik.
		# max < min olunca sis aşağıda yoğunlaşır: oyuncunun ayağının altındaki vadiler sisle dolar.
		ortam.fog_height_min = kl.y - 4.0
		ortam.fog_height_max = kl.y - 4.0 - lerp(260.0, 50.0, yukseklik_sis)
		ortam.fog_sun_amount = 0.5 * gun if hava < 2 else 0.1
		ortam.fog_height_enabled = yukseklik_sis > 0.05
		gok_zaman -= delta
		if gok_zaman <= 0.0:
			gok_zaman = 2.0
			gok.sky_top_color = ust
			gok.sky_horizon_color = ufuk
			gok.ground_horizon_color = ufuk.darkened(0.15)
			gok.ground_bottom_color = ufuk.darkened(0.6)
			gok.sky_energy = 1.0
			gok.sun_color = Color(1.0, 0.92, 0.75).linear_interpolate(Color(1.0, 0.6, 0.35), aksam)
			gok.sun_energy = 7.0 * gun if hava < 2 else 0.0
			gok.sun_latitude = rad2deg(asin(clamp(gunes_yon.y, -1.0, 1.0)))
			gok.sun_longitude = rad2deg(atan2(gunes_yon.x, gunes_yon.z))
	else:
		ortam.background_color = ortam.background_color.linear_interpolate(ufuk, hiz)
		gunes_kure.visible = gunes_yon.y > -0.05 and hava < 2
		gunes_kure.translation = kl + gunes_yon * 3000.0
	ortam.ambient_light_color = Color(0.22, 0.26, 0.40).linear_interpolate(Color(0.62, 0.66, 0.72), gun)
	ortam.ambient_light_energy = lerp(0.4, 1.35, gun)
	if gun > 0.02:
		gunes.light_color = Color(1.0, 0.95, 0.86).linear_interpolate(Color(1.0, 0.62, 0.38), clamp(1.0 - sin(a) * 3.0, 0.0, 1.0))
		gunes.light_energy = isik
		gunes.global_transform = Transform(Basis(), Vector3()).looking_at(-gunes_yon, Vector3.UP if abs(gunes_yon.y) < 0.99 else Vector3.BACK)
	else:
		gunes.light_color = Color(0.55, 0.62, 0.88)
		gunes.light_energy = 0.2
		gunes.global_transform = Transform(Basis(), Vector3()).looking_at(gunes_yon, Vector3.UP if abs(gunes_yon.y) < 0.99 else Vector3.BACK)
	ay_kure.translation = kl - gunes_yon * 3000.0
	ay_kure.visible = gunes_yon.y < 0.05 and hava < 2
	yildizlar.translation = kl
	yildiz_mat.albedo_color = Color(1, 1, 1, clamp((0.35 - gun) * 3.0, 0.0, 1.0) * (1.0 if hava < 1 else 0.0))
	yildizlar.visible = yildiz_mat.albedo_color.a > 0.01
	yagmur.translation = kl + Vector3(0, 10, 0)
	kum.translation = kl + Vector3(-25, 2, 0)
	zehir.translation = kl
	yagmur.emitting = hava == 2 and not dustu
	kum.emitting = hava == 4 and not dustu
	zehir.emitting = dustu


# ---------------------------------------------------------------- efektler
func iz(bas: Vector3, son: Vector3, renk: Color = Color(1.0, 0.85, 0.4)):
	var u = bas.distance_to(son)
	if u < 0.5:
		return
	var m = MeshInstance.new()
	var cm = CubeMesh.new()
	cm.size = Vector3(0.025, 0.025, u)
	var mt = mat_iz.duplicate()
	mt.albedo_color = renk * 1.5
	cm.material = mt
	m.mesh = cm
	m.cast_shadow = GeometryInstance.SHADOW_CASTING_SETTING_OFF
	add_child(m)
	m.add_to_group("kaydir")
	m.global_transform = Transform(Basis(), (bas + son) * 0.5).looking_at(son, Vector3.UP if abs((son - bas).normalized().y) < 0.99 else Vector3.BACK)
	get_tree().create_timer(0.07).connect("timeout", m, "queue_free")


func toz(l: Vector3, renk: Color):
	var p = CPUParticles.new()
	var cm = CubeMesh.new()
	cm.size = Vector3(0.1, 0.1, 0.1)
	var mt = SpatialMaterial.new()
	mt.albedo_color = renk
	cm.material = mt
	p.mesh = cm
	p.one_shot = true
	p.amount = 14 if kalite >= 2 else 8
	p.lifetime = 0.6
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 60.0
	p.initial_velocity = 3.0
	p.gravity = Vector3(0, -9.8, 0)
	p.scale_amount_random = 0.6
	p.local_coords = false
	add_child(p)
	p.add_to_group("kaydir")
	p.translation = l
	p.emitting = true
	get_tree().create_timer(1.0).connect("timeout", p, "queue_free")


func parlama(l: Vector3):
	var isik = OmniLight.new()
	isik.light_color = Color(1.0, 0.75, 0.4)
	isik.light_energy = 4.0
	isik.omni_range = 7.0
	add_child(isik)
	isik.add_to_group("kaydir")
	isik.translation = l
	get_tree().create_timer(0.05).connect("timeout", isik, "queue_free")


func ses3d(akis: AudioStream, l: Vector3, db: float = 0.0):
	var s = AudioStreamPlayer3D.new()
	s.stream = akis
	s.unit_db = db
	s.max_distance = 1800.0
	s.unit_size = 25.0
	add_child(s)
	s.add_to_group("kaydir")
	s.translation = l
	s.play()
	s.connect("finished", s, "queue_free")


func _uzak_atis(bas_g: Vector3, son_g: Vector3, silah: int, atan_id: int, adet: int = 1):
	if atan_id == Ag.benim_id:
		return
	silah = int(clamp(silah, 0, 4))
	var w = V.SILAHLAR[silah]
	# bir gerçek atış, hızlı silahlarda ekranda birkaç mermi gibi çizilir
	for i in int(clamp(adet, 1, 4)):
		var son = son_g
		if i > 0:
			var u = bas_g.distance_to(son_g)
			son += Vector3(rand_range(-1, 1), rand_range(-1, 1), rand_range(-1, 1)) * u * max(w.sapma, 0.004)
		if i == 0:
			_uzak_tek_atis(bas_g, son, silah)
		else:
			get_tree().create_timer(w.aralik * i).connect("timeout", self, "_uzak_tek_atis", [bas_g, son, silah])


func _uzak_tek_atis(bas_g: Vector3, son_g: Vector3, silah: int):
	var b = yerel(bas_g)
	iz(b, yerel(son_g), Color(1.0, 0.75, 0.35))
	parlama(b)
	ses3d(atis_sesleri[silah], b, 4.0)
